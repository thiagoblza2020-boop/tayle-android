package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.screens.ai.TayleAiScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterCompanyScreen
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.materials.MaterialsStockScreen
import com.example.ui.screens.orders.ServiceOrdersScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.services.ServicesCatalogScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.store.VirtualStoreScreen
import com.example.ui.screens.vehicles.VehiclesScreen
import com.example.ui.theme.TayleNavy950
import com.example.ui.theme.TayleTheme
import com.example.viewmodel.TayleMainViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TayleTheme {
                TayleApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TayleApp(
    viewModel: TayleMainViewModel = viewModel()
) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentCompany by viewModel.currentCompany.collectAsStateWithLifecycle()
    val allCompanies by viewModel.allCompanies.collectAsStateWithLifecycle()

    val vehicles by viewModel.companyVehicles.collectAsStateWithLifecycle()
    val orders by viewModel.companyOrders.collectAsStateWithLifecycle()
    val employees by viewModel.companyEmployees.collectAsStateWithLifecycle()
    val goal by viewModel.companyGoal.collectAsStateWithLifecycle()
    val notifications by viewModel.companyNotifications.collectAsStateWithLifecycle()

    // Materials Stock
    val materials by viewModel.companyMaterials.collectAsStateWithLifecycle()
    val materialOrders by viewModel.companyMaterialOrders.collectAsStateWithLifecycle()
    val materialWastes by viewModel.companyMaterialWastes.collectAsStateWithLifecycle()
    val materialMovements by viewModel.companyMaterialMovements.collectAsStateWithLifecycle()

    // Commercial System (Sales, Funnel, Stock, Agenda, Losses)
    val commercialProducts by viewModel.companyCommercialProducts.collectAsStateWithLifecycle()
    val commercialSales by viewModel.companyCommercialSales.collectAsStateWithLifecycle()
    val salesOpportunities by viewModel.companySalesOpportunities.collectAsStateWithLifecycle()
    val lostSales by viewModel.companyLostSales.collectAsStateWithLifecycle()
    val dailyAgendaTasks by viewModel.companyDailyAgendaTasks.collectAsStateWithLifecycle()

    // Branches & Units Structure (Matriz / Filiais)
    val branches by viewModel.companyBranches.collectAsStateWithLifecycle()
    val selectedBranch by viewModel.selectedBranch.collectAsStateWithLifecycle()
    val isConsolidatedView by viewModel.isConsolidatedView.collectAsStateWithLifecycle()
    val allCompanyCommercialSales by viewModel.allCompanyCommercialSales.collectAsStateWithLifecycle()

    // Services Catalog & Virtual Store (Cadastros & E-commerce)
    val catalogServices by viewModel.companyCatalogServices.collectAsStateWithLifecycle()
    val virtualStoreOrders by viewModel.companyVirtualStoreOrders.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var currentRoute by remember { mutableStateOf(TayleNavDestination.DASHBOARD.route) }
    var showLoginScreen by remember { mutableStateOf(false) }
    var showRegisterScreen by remember { mutableStateOf(false) }

    var showCompanySelector by remember { mutableStateOf(false) }
    var showBranchSelector by remember { mutableStateOf(false) }
    var showAddBranchDialog by remember { mutableStateOf(false) }
    var showRoleSelector by remember { mutableStateOf(false) }
    var showNotificationSheet by remember { mutableStateOf(false) }
    var showNewOrderSheet by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    if (showRegisterScreen) {
        RegisterCompanyScreen(
            onRegister = { company, adminUser ->
                viewModel.registerCompanyAndLogin(company, adminUser)
                showRegisterScreen = false
                showLoginScreen = false
            },
            onNavigateToLogin = {
                showRegisterScreen = false
                showLoginScreen = true
            }
        )
        return
    }

    if (showLoginScreen && currentUser == null) {
        LoginScreen(
            onLogin = { email, role ->
                viewModel.login(email, role)
                showLoginScreen = false
            },
            onNavigateToRegister = {
                showLoginScreen = false
                showRegisterScreen = true
            }
        )
        return
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            TayleSidebarDrawerContent(
                currentRoute = currentRoute,
                currentUser = currentUser,
                currentCompany = currentCompany,
                onNavigate = { dest ->
                    currentRoute = dest.route
                    scope.launch { drawerState.close() }
                },
                onCompanySwitchClick = {
                    showCompanySelector = true
                    scope.launch { drawerState.close() }
                },
                onLogoutClick = {
                    viewModel.logout()
                    showLoginScreen = true
                    scope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TayleTopBar(
                    currentUser = currentUser,
                    currentCompany = currentCompany,
                    selectedBranch = selectedBranch,
                    unreadNotificationsCount = notifications.count { !it.isRead },
                    onCompanyClick = { showCompanySelector = true },
                    onBranchClick = { showBranchSelector = true },
                    onRoleBadgeClick = { showRoleSelector = true },
                    onNotificationsClick = { showNotificationSheet = true },
                    onProfileClick = { currentRoute = TayleNavDestination.PROFILE.route },
                    onMenuToggle = { scope.launch { drawerState.open() } }
                )
            },
            bottomBar = {
                TayleBottomNavigation(
                    currentRoute = currentRoute,
                    currentUser = currentUser,
                    onNavigate = { dest -> currentRoute = dest.route }
                )
            },
            containerColor = TayleNavy950,
            contentWindowInsets = WindowInsets.safeDrawing
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(TayleNavy950)
            ) {
                if (currentRoute != TayleNavDestination.DASHBOARD.route) {
                    BackHandler {
                        currentRoute = TayleNavDestination.DASHBOARD.route
                    }
                }
                when (currentRoute) {
                    TayleNavDestination.DASHBOARD.route -> {
                        DashboardScreen(
                            currentUser = currentUser,
                            currentCompany = currentCompany,
                            vehicles = vehicles,
                            orders = orders,
                            employees = employees,
                            goal = goal,
                            materials = materials,
                            materialOrders = materialOrders,
                            materialWastes = materialWastes,
                            commercialProducts = commercialProducts,
                            commercialSales = commercialSales,
                            salesOpportunities = salesOpportunities,
                            lostSales = lostSales,
                            dailyAgendaTasks = dailyAgendaTasks,
                            selectedBranch = selectedBranch,
                            branches = branches,
                            allCompanySales = allCompanyCommercialSales,
                            onSelectBranch = { b -> viewModel.selectBranch(b) },
                            onOpenBranchModal = { showBranchSelector = true },
                            onAddNewBranchClick = { showAddBranchDialog = true },
                            onNavigateToVehicles = { currentRoute = TayleNavDestination.VEHICLES.route },
                            onNavigateToOrders = { currentRoute = TayleNavDestination.SERVICE_ORDERS.route },
                            onNewOrderClick = { showNewOrderSheet = true },
                            onNavigateToStock = { currentRoute = TayleNavDestination.MATERIALS_STOCK.route },
                            onNavigateToAi = { currentRoute = TayleNavDestination.TAYLE_AI.route },
                            onNavigateToCatalog = { currentRoute = TayleNavDestination.SERVICES_CATALOG.route },
                            onNavigateToVirtualStore = { currentRoute = TayleNavDestination.VIRTUAL_STORE.route },
                            onUpdateOrderStatus = { order, status ->
                                viewModel.updateOrderStatus(order, status)
                            },
                            onRegisterCommercialSale = { sale, product ->
                                viewModel.registerCommercialSale(sale, product)
                            },
                            onSaveSalesOpportunity = { opp ->
                                viewModel.saveSalesOpportunity(opp)
                            },
                            onUpdateOpportunityStage = { opp, newStage ->
                                viewModel.updateOpportunityStage(opp, newStage)
                            },
                            onToggleDailyTask = { task ->
                                viewModel.toggleDailyAgendaTask(task)
                            },
                            onSaveDailyTask = { task ->
                                viewModel.saveDailyAgendaTask(task)
                            },
                            onRecoverLostSale = { lostSale ->
                                viewModel.updateLostSale(lostSale.copy(isRecovered = true))
                            },
                            onSaveCommercialProduct = { product ->
                                viewModel.saveCommercialProduct(product)
                            },
                            onStockMovement = { product, isEntry, qty, reason, resp, date ->
                                viewModel.registerStockMovement(product, isEntry, qty, reason, resp, date)
                            }
                        )
                    }
                    TayleNavDestination.MATERIALS_STOCK.route, "estoque", "materials_stock" -> {
                        MaterialsStockScreen(
                            materials = materials,
                            movements = materialMovements,
                            orders = materialOrders,
                            wastes = materialWastes,
                            currentUserRole = currentUser?.role ?: UserRole.ADMINISTRADOR,
                            currentUserName = currentUser?.name ?: "Admin",
                            currentCompanyId = currentCompany?.id ?: "comp_matriz",
                            onAddMaterial = { mat -> viewModel.addMaterial(mat) },
                            onUpdateMaterial = { mat -> viewModel.updateMaterial(mat) },
                            onDeleteMaterial = { id -> viewModel.deleteMaterial(id) },
                            onRegisterEntry = { mat, qty, cost, supp, invoice, user ->
                                viewModel.registerMaterialEntry(
                                    mat,
                                    qty,
                                    cost,
                                    supp,
                                    invoice,
                                    user
                                )
                            },
                            onRegisterExit = { mat, qty, reason, user ->
                                viewModel.registerMaterialExit(
                                    mat,
                                    qty,
                                    reason,
                                    user
                                )
                            },
                            onCreateOrder = { order ->
                                viewModel.createMaterialOrder(order)
                            },
                            onUpdateOrderStatus = { order, status ->
                                viewModel.updateMaterialOrderStatus(
                                    order,
                                    status,
                                    currentUser?.name ?: "Admin"
                                )
                            },
                            onDeleteOrder = { id -> viewModel.deleteMaterialOrder(id) },
                            onRegisterWaste = { waste ->
                                viewModel.registerMaterialWaste(waste)
                            },
                            onDeleteWaste = { id -> viewModel.deleteMaterialWaste(id) }
                        )
                    }
                    TayleNavDestination.SERVICE_ORDERS.route, "service_orders", "os", "orders" -> {
                        ServiceOrdersScreen(
                            orders = orders,
                            catalogServices = catalogServices,
                            currentUser = currentUser,
                            selectedBranch = selectedBranch,
                            onUpdateOrderStatus = { order, status ->
                                viewModel.updateOrderStatus(order, status)
                            },
                            onDeleteOrder = { id ->
                                viewModel.deleteServiceOrder(id)
                            },
                            onNewOrderClick = { showNewOrderSheet = true }
                        )
                    }
                    TayleNavDestination.SERVICES_CATALOG.route, "services_catalog", "servicos", "catalogo" -> {
                        ServicesCatalogScreen(
                            services = catalogServices,
                            branches = branches,
                            currentUser = currentUser,
                            selectedBranch = selectedBranch,
                            onSaveService = { srv -> viewModel.saveCatalogService(srv) },
                            onUpdateService = { srv -> viewModel.updateCatalogService(srv) },
                            onToggleServiceStatus = { srv -> viewModel.toggleServiceActive(srv) },
                            onDeleteService = { id -> viewModel.deleteCatalogService(id) },
                            onRequestServiceBooking = { _ ->
                                currentRoute = TayleNavDestination.VIRTUAL_STORE.route
                            }
                        )
                    }
                    TayleNavDestination.VIRTUAL_STORE.route, "virtual_store", "loja", "ecommerce" -> {
                        VirtualStoreScreen(
                            products = commercialProducts,
                            services = catalogServices,
                            orders = virtualStoreOrders,
                            branches = branches,
                            currentUser = currentUser,
                            selectedBranch = selectedBranch,
                            onSaveProduct = { p -> viewModel.saveCommercialProduct(p) },
                            onDeleteProduct = { id -> viewModel.deleteCommercialProduct(id) },
                            onSubmitStoreOrder = { ord, cb -> viewModel.saveVirtualStoreOrder(ord, cb) },
                            onUpdateOrderStatus = { ord, st -> viewModel.updateVirtualStoreOrderStatus(ord, st) }
                        )
                    }
                    TayleNavDestination.VEHICLES.route -> {
                        VehiclesScreen(
                            vehicles = vehicles,
                            userRole = currentUser?.role ?: UserRole.ADMINISTRADOR,
                            onAddVehicle = { v -> viewModel.addVehicle(v) },
                            onUpdateVehicleStatus = { v, s -> viewModel.updateVehicleStatus(v, s) },
                            selectedBranch = selectedBranch
                        )
                    }
                    TayleNavDestination.TAYLE_AI.route -> {
                        TayleAiScreen()
                    }
                    TayleNavDestination.PROFILE.route -> {
                        ProfileScreen(
                            currentUser = currentUser,
                            currentCompany = currentCompany,
                            onLogout = {
                                viewModel.logout()
                                showLoginScreen = true
                            },
                            onSwitchCompany = { showCompanySelector = true }
                        )
                    }
                    TayleNavDestination.SETTINGS.route -> {
                        SettingsScreen(
                            company = currentCompany,
                            userRole = currentUser?.role ?: UserRole.ADMINISTRADOR,
                            onSwitchCompany = { showCompanySelector = true }
                        )
                    }
                    else -> {
                        // Fallback to Dashboard
                        DashboardScreen(
                            currentUser = currentUser,
                            currentCompany = currentCompany,
                            vehicles = vehicles,
                            orders = orders,
                            employees = employees,
                            goal = goal,
                            materials = materials,
                            materialOrders = materialOrders,
                            materialWastes = materialWastes,
                            commercialProducts = commercialProducts,
                            commercialSales = commercialSales,
                            salesOpportunities = salesOpportunities,
                            lostSales = lostSales,
                            dailyAgendaTasks = dailyAgendaTasks,
                            selectedBranch = selectedBranch,
                            branches = branches,
                            allCompanySales = allCompanyCommercialSales,
                            onSelectBranch = { b -> viewModel.selectBranch(b) },
                            onOpenBranchModal = { showBranchSelector = true },
                            onAddNewBranchClick = { showAddBranchDialog = true },
                            onNavigateToVehicles = { currentRoute = TayleNavDestination.VEHICLES.route },
                            onNavigateToOrders = { currentRoute = TayleNavDestination.SERVICE_ORDERS.route },
                            onNewOrderClick = { showNewOrderSheet = true },
                            onNavigateToStock = { currentRoute = TayleNavDestination.MATERIALS_STOCK.route },
                            onNavigateToAi = { currentRoute = TayleNavDestination.TAYLE_AI.route },
                            onNavigateToCatalog = { currentRoute = TayleNavDestination.SERVICES_CATALOG.route },
                            onNavigateToVirtualStore = { currentRoute = TayleNavDestination.VIRTUAL_STORE.route },
                            onUpdateOrderStatus = { order, status ->
                                viewModel.updateOrderStatus(order, status)
                            },
                            onRegisterCommercialSale = { sale, product ->
                                viewModel.registerCommercialSale(sale, product)
                            },
                            onSaveSalesOpportunity = { opp ->
                                viewModel.saveSalesOpportunity(opp)
                            },
                            onUpdateOpportunityStage = { opp, newStage ->
                                viewModel.updateOpportunityStage(opp, newStage)
                            },
                            onToggleDailyTask = { task ->
                                viewModel.toggleDailyAgendaTask(task)
                            },
                            onSaveDailyTask = { task ->
                                viewModel.saveDailyAgendaTask(task)
                            },
                            onRecoverLostSale = { lostSale ->
                                viewModel.updateLostSale(lostSale.copy(isRecovered = true))
                            },
                            onSaveCommercialProduct = { product ->
                                viewModel.saveCommercialProduct(product)
                            },
                            onStockMovement = { product, isEntry, qty, reason, resp, date ->
                                viewModel.registerStockMovement(product, isEntry, qty, reason, resp, date)
                            }
                        )
                    }
                }
            }
        }
    }

    // Company Switcher Modal
    if (showCompanySelector) {
        CompanySwitcherSheet(
            companies = allCompanies,
            currentCompany = currentCompany,
            onCompanySelected = { comp ->
                viewModel.switchCompanyForDemo(comp)
                showCompanySelector = false
            },
            onDismiss = { showCompanySelector = false }
        )
    }

    // Role Permission Switcher
    if (showRoleSelector) {
        RolePermissionSheet(
            currentRole = currentUser?.role ?: UserRole.ADMINISTRADOR,
            onRoleSelected = { role ->
                viewModel.switchRoleForDemo(role)
                showRoleSelector = false
            },
            onDismiss = { showRoleSelector = false }
        )
    }

    // Branch Selector Modal
    if (showBranchSelector) {
        BranchSelectorSheet(
            branches = branches,
            selectedBranch = selectedBranch,
            currentUser = currentUser,
            company = currentCompany,
            onSelectBranch = { branch ->
                viewModel.selectBranch(branch)
                showBranchSelector = false
            },
            onAddNewBranchClick = {
                showBranchSelector = false
                showAddBranchDialog = true
            },
            onDismiss = { showBranchSelector = false }
        )
    }

    // Add Branch Dialog
    if (showAddBranchDialog) {
        AddBranchDialog(
            currentBranchesCount = branches.size,
            planName = currentCompany?.plan ?: "Básico",
            onDismiss = { showAddBranchDialog = false },
            onConfirm = { name, code, address, phone, manager, authorizedUsers ->
                viewModel.addBranch(name, code, address, phone, manager, authorizedUsers) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
                showAddBranchDialog = false
            }
        )
    }

    // Notifications Modal
    if (showNotificationSheet) {
        NotificationsSheet(
            notifications = notifications,
            onClearAll = { viewModel.clearAllNotifications() },
            onDismiss = { showNotificationSheet = false }
        )
    }

    // New Service Order Modal
    if (showNewOrderSheet) {
        NewServiceOrderSheet(
            companyId = currentCompany?.id ?: "comp_matriz",
            catalogServices = catalogServices,
            onSave = { os ->
                viewModel.createServiceOrder(os)
                showNewOrderSheet = false
            },
            onDismiss = { showNewOrderSheet = false }
        )
    }
}
