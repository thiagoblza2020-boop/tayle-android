package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.Branch
import com.example.data.model.Company
import com.example.data.model.Employee
import com.example.data.model.Goal
import com.example.data.model.Material
import com.example.data.model.MaterialMovement
import com.example.data.model.MaterialOrder
import com.example.data.model.MaterialWaste
import com.example.data.model.ServiceOrder
import com.example.data.model.TayleNotification
import com.example.data.model.User
import com.example.data.model.Vehicle

import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        Company::class,
        Branch::class,
        User::class,
        Vehicle::class,
        ServiceOrder::class,
        Employee::class,
        Goal::class,
        TayleNotification::class,
        Material::class,
        MaterialMovement::class,
        MaterialOrder::class,
        MaterialWaste::class,
        CommercialProduct::class,
        StockMovement::class,
        CommercialSale::class,
        SalesOpportunity::class,
        LostSale::class,
        DailyAgendaTask::class,
        ServiceCatalogItem::class,
        VirtualStoreOrder::class
    ],
    version = 7,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class TayleDatabase : RoomDatabase() {
    abstract fun companyDao(): CompanyDao
    abstract fun branchDao(): BranchDao
    abstract fun userDao(): UserDao
    abstract fun vehicleDao(): VehicleDao
    abstract fun serviceOrderDao(): ServiceOrderDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun goalDao(): GoalDao
    abstract fun notificationDao(): NotificationDao
    abstract fun materialDao(): MaterialDao
    abstract fun materialMovementDao(): MaterialMovementDao
    abstract fun materialOrderDao(): MaterialOrderDao
    abstract fun materialWasteDao(): MaterialWasteDao
    abstract fun commercialProductDao(): CommercialProductDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun commercialSaleDao(): CommercialSaleDao
    abstract fun salesOpportunityDao(): SalesOpportunityDao
    abstract fun lostSaleDao(): LostSaleDao
    abstract fun dailyAgendaTaskDao(): DailyAgendaTaskDao
    abstract fun serviceCatalogItemDao(): ServiceCatalogItemDao
    abstract fun virtualStoreOrderDao(): VirtualStoreOrderDao

    companion object {
        @Volatile
        private var INSTANCE: TayleDatabase? = null

        fun getDatabase(context: Context): TayleDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TayleDatabase::class.java,
                    "tayle_saas_database_v4.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(TayleDatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class TayleDatabaseCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    seedDatabase(database)
                }
            }
        }

        override fun onOpen(db: SupportSQLiteDatabase) {
            super.onOpen(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val count = database.userDao().getUserCount()
                        if (count == 0) {
                            seedDatabase(database)
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }
}

suspend fun seedDatabase(database: TayleDatabase) {
    val compMatriz = Company(
        id = "comp_matriz",
        name = "TAYLE Concessionária Matriz",
        document = "12.345.678/0001-90",
        segment = "Concessionária & Serviços Automotivos",
        plan = "Master R$ 99,90",
        branchesCount = 3,
        matrixAddress = "Av. das Nações Unidas, 12900 - Brooklin, São Paulo - SP",
        phone = "(11) 98844-2200",
        email = "contato@tayle.com.br",
        address = "Av. das Nações Unidas, 12900 - SP"
    )

    val compSul = Company(
        id = "comp_sul",
        name = "TAYLE Unidade Sul - Pátio & O.S.",
        document = "12.345.678/0002-71",
        segment = "Oficina & Centro Automotivo",
        plan = "Master R$ 99,90",
        branchesCount = 1,
        matrixAddress = "Av. Washington Luís, 4500 - Santo Amaro, São Paulo - SP",
        phone = "(11) 97711-3344",
        email = "sul@tayle.com.br",
        address = "Av. Washington Luís, 4500 - SP"
    )

    database.companyDao().insertCompany(compMatriz)
    database.companyDao().insertCompany(compSul)

    // Seed Branches (Estrutura Matriz e Filiais)
    val branches = listOf(
        Branch(
            id = "branch_sp_matriz",
            companyId = "comp_matriz",
            name = "Matriz São Paulo",
            code = "SP-01",
            address = "Av. das Nações Unidas, 12900 - Brooklin, São Paulo - SP",
            phone = "(11) 98844-2200",
            managerName = "Administrador TAYLE",
            status = "Ativa",
            isHeadquarters = true,
            authorizedUsersCount = 12
        ),
        Branch(
            id = "branch_go_02",
            companyId = "comp_matriz",
            name = "Filial Goiânia",
            code = "GO-02",
            address = "Av. T-63, 1420 - St. Bueno, Goiânia - GO",
            phone = "(62) 98122-4455",
            managerName = "Ricardo Mendes",
            status = "Ativa",
            isHeadquarters = false,
            authorizedUsersCount = 6
        ),
        Branch(
            id = "branch_df_03",
            companyId = "comp_matriz",
            name = "Filial Brasília",
            code = "DF-03",
            address = "SIA Trecho 3, Lote 620 - Guará, Brasília - DF",
            phone = "(61) 99344-7788",
            managerName = "Camila Guimarães",
            status = "Ativa",
            isHeadquarters = false,
            authorizedUsersCount = 5
        ),
        Branch(
            id = "branch_bh_04",
            companyId = "comp_matriz",
            name = "Filial Belo Horizonte",
            code = "BH-04",
            address = "Av. Raja Gabaglia, 3200 - Estoril, Belo Horizonte - MG",
            phone = "(31) 98455-6677",
            managerName = "Thiago Vasconcelos",
            status = "Ativa",
            isHeadquarters = false,
            authorizedUsersCount = 4
        )
    )
    database.branchDao().insertBranches(branches)

    val admin = User(
        id = "usr_admin",
        companyId = "comp_matriz",
        branchId = "branch_sp_matriz",
        branchName = "Matriz São Paulo",
        isHeadquartersUser = true,
        name = "Administrador TAYLE",
        email = "admin@tayle.com",
        role = UserRole.ADMINISTRADOR,
        roleTitle = "Administrador Geral (Matriz)",
        department = Department.ADMINISTRACAO,
        phone = "(11) 98844-2200"
    )

    val gerenteSP = User(
        id = "usr_gerente",
        companyId = "comp_matriz",
        branchId = "branch_sp_matriz",
        branchName = "Matriz São Paulo",
        isHeadquartersUser = true,
        name = "Carlos Santana",
        email = "carlos@tayle.com",
        role = UserRole.GERENTE,
        roleTitle = "Gerente Geral (Matriz)",
        department = Department.OFICINA,
        phone = "(11) 97700-1122"
    )

    val gerenteGoiania = User(
        id = "usr_gerente_go",
        companyId = "comp_matriz",
        branchId = "branch_go_02",
        branchName = "Filial Goiânia",
        isHeadquartersUser = false,
        name = "Ricardo Mendes",
        email = "ricardo.go@tayle.com",
        role = UserRole.GERENTE,
        roleTitle = "Gerente de Filial (Goiânia)",
        department = Department.ADMINISTRACAO,
        phone = "(62) 98122-4455"
    )

    val gerenteBrasilia = User(
        id = "usr_gerente_df",
        companyId = "comp_matriz",
        branchId = "branch_df_03",
        branchName = "Filial Brasília",
        isHeadquartersUser = false,
        name = "Camila Guimarães",
        email = "camila.df@tayle.com",
        role = UserRole.GERENTE,
        roleTitle = "Gerente de Filial (Brasília)",
        department = Department.ADMINISTRACAO,
        phone = "(61) 99344-7788"
    )

    val operadorBH = User(
        id = "usr_operador_bh",
        companyId = "comp_matriz",
        branchId = "branch_bh_04",
        branchName = "Filial Belo Horizonte",
        isHeadquartersUser = false,
        name = "Thiago Vasconcelos",
        email = "thiago.bh@tayle.com",
        role = UserRole.OPERADOR,
        roleTitle = "Consultor de Vendas (BH)",
        department = Department.OFICINA,
        phone = "(31) 98455-6677"
    )

    database.userDao().insertUser(admin)
    database.userDao().insertUser(gerenteSP)
    database.userDao().insertUser(gerenteGoiania)
    database.userDao().insertUser(gerenteBrasilia)
    database.userDao().insertUser(operadorBH)

    // Initial Materials (Estoque)
    val matOleo = Material(
        id = "mat_oleo_5w30",
        companyId = "comp_matriz",
        name = "Óleo Sintético 5W30 Dexos",
        category = "Lubrificantes",
        unit = "L",
        currentQuantity = 45.0,
        minQuantity = 20.0,
        unitCost = 38.50,
        location = "Prateleira A1",
        supplier = "Petrobras Distribuidora"
    )

    val matFiltroOleo = Material(
        id = "mat_filtro_oleo",
        companyId = "comp_matriz",
        name = "Filtro de Óleo Blindado PSL55",
        category = "Filtros",
        unit = "UN",
        currentQuantity = 8.0,
        minQuantity = 15.0,
        unitCost = 28.00,
        location = "Prateleira B2",
        supplier = "Tecfil Indústria"
    )

    val matPastilhaFreio = Material(
        id = "mat_pastilha_freio",
        companyId = "comp_matriz",
        name = "Jogo Pastilhas Freio Dianteiro",
        category = "Freios",
        unit = "JG",
        currentQuantity = 12.0,
        minQuantity = 6.0,
        unitCost = 145.00,
        location = "Prateleira C1",
        supplier = "Fras-le Peças"
    )

    val matFluidoFreio = Material(
        id = "mat_fluido_freio",
        companyId = "comp_matriz",
        name = "Fluido de Freio DOT4 500ml",
        category = "Fluidos",
        unit = "FR",
        currentQuantity = 5.0,
        minQuantity = 10.0,
        unitCost = 32.00,
        location = "Prateleira A3",
        supplier = "Bosch Brasil"
    )

    val matLampadaH7 = Material(
        id = "mat_lampada_h7",
        companyId = "comp_matriz",
        name = "Lâmpada Halógena H7 12V 55W",
        category = "Elétrica",
        unit = "UN",
        currentQuantity = 24.0,
        minQuantity = 10.0,
        unitCost = 18.90,
        location = "Gaveta E1",
        supplier = "Osram do Brasil"
    )

    val matAditivo = Material(
        id = "mat_aditivo_rad",
        companyId = "comp_matriz",
        name = "Aditivo Radiador Concentrado Rosa",
        category = "Arrefecimento",
        unit = "L",
        currentQuantity = 18.0,
        minQuantity = 12.0,
        unitCost = 26.50,
        location = "Prateleira D2",
        supplier = "Paraflu Química"
    )

    database.materialDao().insertMaterial(matOleo)
    database.materialDao().insertMaterial(matFiltroOleo)
    database.materialDao().insertMaterial(matPastilhaFreio)
    database.materialDao().insertMaterial(matFluidoFreio)
    database.materialDao().insertMaterial(matLampadaH7)
    database.materialDao().insertMaterial(matAditivo)

    // Material Order
    val order1 = MaterialOrder(
        id = "ord_001",
        companyId = "comp_matriz",
        materialId = matFiltroOleo.id,
        materialName = matFiltroOleo.name,
        quantity = 30.0,
        unit = "UN",
        unitCost = 28.00,
        totalCost = 840.00,
        supplier = "Tecfil Indústria",
        status = MaterialOrderStatus.ENVIADO,
        orderedByName = "Carlos Santana"
    )
    database.materialOrderDao().insertOrder(order1)

    // Material Waste
    val waste1 = MaterialWaste(
        id = "wst_001",
        companyId = "comp_matriz",
        materialId = matLampadaH7.id,
        materialName = matLampadaH7.name,
        quantity = 2.0,
        unit = "UN",
        unitCost = 18.90,
        totalCost = 37.80,
        reason = "Avaria física",
        details = "Vidro quebrado durante manuseio na bancada",
        responsibleName = "Lucas Meireles"
    )
    database.materialWasteDao().insertWaste(waste1)

    // Vehicles
    val v1 = Vehicle(
        id = "veh_001",
        companyId = "comp_matriz",
        branchId = "branch_sp_matriz",
        branchName = "Matriz São Paulo",
        plate = "BRA2E19",
        brand = "Toyota",
        model = "Corolla XEi 2.0",
        year = 2023,
        color = "Prata Lunar",
        customerName = "Roberto Silveira",
        customerPhone = "(11) 98111-2233",
        status = VehicleStatus.EM_SERVICO,
        location = "Box 02 - Elevador",
        fuelLevel = "3/4",
        mileage = "42.350 km"
    )

    val v2 = Vehicle(
        id = "veh_002",
        companyId = "comp_matriz",
        branchId = "branch_sp_matriz",
        branchName = "Matriz São Paulo",
        plate = "RJK4A22",
        brand = "Honda",
        model = "Civic Touring 1.5 Turbo",
        year = 2022,
        color = "Preto Cristal",
        customerName = "Mariana Souza",
        customerPhone = "(11) 99444-5566",
        status = VehicleStatus.AGUARDANDO_INSPECAO,
        location = "Pátio Entrada - Vaga 04",
        fuelLevel = "1/2",
        mileage = "31.200 km"
    )

    val v3 = Vehicle(
        id = "veh_003",
        companyId = "comp_matriz",
        branchId = "branch_go_02",
        branchName = "Filial Goiânia",
        plate = "GOI8F90",
        brand = "Jeep",
        model = "Compass Longitude 1.3T",
        year = 2024,
        color = "Branco Polar",
        customerName = "Fernando Lima (GO)",
        customerPhone = "(62) 97333-8899",
        status = VehicleStatus.PRONTO,
        location = "Pátio Saída Goiânia",
        fuelLevel = "Cheio",
        mileage = "18.900 km"
    )

    val v4 = Vehicle(
        id = "veh_004",
        companyId = "comp_matriz",
        branchId = "branch_df_03",
        branchName = "Filial Brasília",
        plate = "BSB1D23",
        brand = "Volkswagen",
        model = "T-Cross Highline 250 TSI",
        year = 2023,
        color = "Cinza Platinum",
        customerName = "Juliana Ramos (DF)",
        customerPhone = "(61) 98777-6655",
        status = VehicleStatus.EM_SERVICO,
        location = "Pátio Guará - Box 01",
        fuelLevel = "3/4",
        mileage = "29.500 km"
    )

    database.vehicleDao().insertVehicle(v1)
    database.vehicleDao().insertVehicle(v2)
    database.vehicleDao().insertVehicle(v3)
    database.vehicleDao().insertVehicle(v4)

    // Service Orders
    val os1 = ServiceOrder(
        id = "os_001",
        companyId = "comp_matriz",
        branchId = "branch_sp_matriz",
        branchName = "Matriz São Paulo",
        osNumber = "1001",
        plate = "BRA2E19",
        brand = "Toyota",
        model = "Corolla XEi 2.0",
        customerName = "Roberto Silveira",
        customerPhone = "(11) 98111-2233",
        description = "Revisão periódica de 40.000 km, troca de óleo, todos os filtros e inspeção geral de suspensão.",
        servicesList = listOf(
            "Troca de óleo de motor 5W30",
            "Substituição filtro de óleo",
            "Substituição filtro de ar e combustível",
            "Check-up eletrônico scanner"
        ),
        technicianName = "Lucas Meireles",
        status = OsStatus.EM_ANDAMENTO,
        priority = OsPriority.ALTA,
        totalAmount = 850.00,
        checklist = listOf(
            ChecklistItem("Nível do óleo verificado", true),
            ChecklistItem("Filtros substituídos", true),
            ChecklistItem("Pressão dos pneus calibrada", true),
            ChecklistItem("Teste de rodagem final", false)
        )
    )

    val os2 = ServiceOrder(
        id = "os_002",
        companyId = "comp_matriz",
        branchId = "branch_go_02",
        branchName = "Filial Goiânia",
        osNumber = "1002",
        plate = "RJK4A22",
        brand = "Honda",
        model = "Civic Touring 1.5 Turbo",
        customerName = "Mariana Souza",
        customerPhone = "(62) 99444-5566",
        description = "Substituição jogo pastilhas dianteiras e sangria com fluido de freio DOT4.",
        servicesList = listOf(
            "Troca de pastilhas de freio",
            "Sangria de fluido de freio DOT4",
            "Retífica de discos dianteiros"
        ),
        technicianName = "Carlos Santana",
        status = OsStatus.PENDENTE,
        priority = OsPriority.NORMAL,
        totalAmount = 620.00,
        checklist = listOf(
            ChecklistItem("Inspeção espessura dos discos", false),
            ChecklistItem("Sangria do sistema hidráulico", false)
        )
    )

    val os3 = ServiceOrder(
        id = "os_003",
        companyId = "comp_matriz",
        branchId = "branch_sp_matriz",
        branchName = "Matriz São Paulo",
        osNumber = "1003",
        plate = "QWE8F90",
        brand = "Jeep",
        model = "Compass Longitude 1.3T",
        customerName = "Fernando Lima",
        customerPhone = "(11) 97333-8899",
        description = "Alinhamento 3D computadorizado, balanceamento das 4 rodas e rodízio de pneus.",
        servicesList = listOf(
            "Alinhamento 3D",
            "Balanceamento 4 rodas",
            "Higienização ar condicionado"
        ),
        technicianName = "Lucas Meireles",
        status = OsStatus.REVISAO,
        priority = OsPriority.NORMAL,
        totalAmount = 340.00,
        checklist = listOf(
            ChecklistItem("Conferência de cáster e cambagem", true),
            ChecklistItem("Balanceamento estático e dinâmico", true),
            ChecklistItem("Higienização com ozônio", true)
        )
    )

    val os4 = ServiceOrder(
        id = "os_004",
        companyId = "comp_matriz",
        branchId = "branch_df_03",
        branchName = "Filial Brasília",
        osNumber = "1004",
        plate = "ABC1D23",
        brand = "Volkswagen",
        model = "T-Cross Highline 250 TSI",
        customerName = "Juliana Ramos",
        customerPhone = "(61) 98777-6655",
        description = "Troca de óleo rápida preventiva e lâmpada farol baixo H7.",
        servicesList = listOf(
            "Troca rápida de lubrificante",
            "Substituição de lâmpada H7"
        ),
        technicianName = "Lucas Meireles",
        status = OsStatus.CONCLUIDA,
        priority = OsPriority.NORMAL,
        totalAmount = 480.00,
        completedAt = System.currentTimeMillis() - 86400000L
    )

    val os5 = ServiceOrder(
        id = "os_005",
        companyId = "comp_matriz",
        branchId = "branch_bh_04",
        branchName = "Filial Belo Horizonte",
        osNumber = "1005",
        plate = "MGH9K11",
        brand = "Fiat",
        model = "Pulse Impetus Turbo 200",
        customerName = "Rodrigo Matos (BH)",
        customerPhone = "(31) 99122-3344",
        description = "Revisão dos 20.000 km e rodízio com alinhamento dianteiro.",
        servicesList = listOf(
            "Troca de óleo 0W20",
            "Alinhamento e Balanceamento",
            "Filtro de cabine antibacteriano"
        ),
        technicianName = "Thiago Vasconcelos",
        status = OsStatus.EM_ANDAMENTO,
        priority = OsPriority.NORMAL,
        totalAmount = 590.00
    )

    database.serviceOrderDao().insertOrder(os1)
    database.serviceOrderDao().insertOrder(os2)
    database.serviceOrderDao().insertOrder(os3)
    database.serviceOrderDao().insertOrder(os4)
    database.serviceOrderDao().insertOrder(os5)

    // Seed Service Catalog (Cadastro e Catálogo Digital de Serviços)
    val catalogServices = listOf(
        ServiceCatalogItem(
            id = "srv_001",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            code = "SRV-001",
            name = "Lavagem Técnica & Chassi",
            description = "Descontaminação ferrosa de pintura, limpeza detalhada de caixas de roda, chassi e motor com aplicação de verniz protetor.",
            benefits = "• Remoção de piche e impurezas sem riscar o verniz\n• Limpeza detalhada das caixas de roda e chassi\n• Proteção hidrofóbica rápida de pintura",
            category = "Lavagem automotiva",
            salePrice = 180.00,
            costPrice = 45.00,
            isActive = true,
            estimatedDurationMinutes = 90
        ),
        ServiceCatalogItem(
            id = "srv_002",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            code = "SRV-002",
            name = "Higienização Interna com Oxi-Sanitização",
            description = "Limpeza profunda e extrativa de bancos, carpetes, portas e teto, finalizando com tratamento de choque de ozônio purificador.",
            benefits = "• Eliminação de 99,9% de fungos, ácaros e bactérias\n• Remoção completa de odores desagradáveis\n• Hidratação e proteção para bancos de couro",
            category = "Higienização interna",
            salePrice = 380.00,
            costPrice = 80.00,
            isActive = true,
            estimatedDurationMinutes = 180
        ),
        ServiceCatalogItem(
            id = "srv_003",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            code = "SRV-003",
            name = "Polimento Técnico Comercial",
            description = "Processo em 2 etapas com compostos de corte e refino com nivelamento óptico de verniz e remoção de swirls (marcas de pano).",
            benefits = "• Elimina até 90% dos micro-riscos e hologramas\n• Restaura a profundidade da cor original\n• Brilho espelhado cristalino e uniforme",
            category = "Polimento",
            salePrice = 650.00,
            costPrice = 120.00,
            isActive = true,
            estimatedDurationMinutes = 300
        ),
        ServiceCatalogItem(
            id = "srv_004",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            code = "SRV-004",
            name = "Enceramento Técnico Carnaúba Premium",
            description = "Aplicação manual de cera nobre pura de carnaúba com alto teor de sólidos e pré-desengraxe da superfície pintada.",
            benefits = "• Brilho quente com efeito espelho profundo\n• Alta repelência a água e poeira por até 4 meses\n• Proteção contra resíduos de pássaros e seiva de árvore",
            category = "Enceramento",
            salePrice = 220.00,
            costPrice = 35.00,
            isActive = true,
            estimatedDurationMinutes = 60
        ),
        ServiceCatalogItem(
            id = "srv_005",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            code = "SRV-005",
            name = "Proteção de Pintura / Vitrificação Cerâmica 9H",
            description = "Aplicação de nano-revestimento cerâmico de sílica de alta densidade (9H) curado por luz infravermelha com certificado e garantia.",
            benefits = "• Dureza extrema contra intempéries e raios solares\n• Camada vítrea super-hidrofóbica por até 3 anos\n• Facilidade incomparável de lavagem e manutenção",
            category = "Proteção de pintura",
            salePrice = 1490.00,
            costPrice = 280.00,
            isActive = true,
            estimatedDurationMinutes = 480,
            requiresVehicleInspection = true
        ),
        ServiceCatalogItem(
            id = "srv_006",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            code = "SRV-006",
            name = "Cristalização de Pintura & Para-brisas",
            description = "Selamento polimérico protetor de poros do verniz acompanhado de cristalização hidrofóbica nos vidros automotivos.",
            benefits = "• Melhora imediata da visibilidade em chuvas intensas\n• Protege o verniz por até 6 meses com barreira selante\n• Reduz a aderência de sujeiras e insetos na estrada",
            category = "Cristalização",
            salePrice = 450.00,
            costPrice = 70.00,
            isActive = true,
            estimatedDurationMinutes = 120
        ),
        // Serviços cadastrados especificamente para Filial Goiânia (demonstrando preços por unidade)
        ServiceCatalogItem(
            id = "srv_007",
            companyId = "comp_matriz",
            branchId = "branch_go_02",
            branchName = "Filial Goiânia",
            code = "SRV-GO-01",
            name = "Lavagem Técnica & Chassi (Goiânia)",
            description = "Lavagem ecológica e descontaminação de pintura adaptada para poeira de terra vermelha.",
            benefits = "• Desengraxe especializado para terra e poeira pesada\n• Proteção de plásticos externos contra sol intenso\n• Secagem completa",
            category = "Lavagem automotiva",
            salePrice = 160.00,
            costPrice = 40.00,
            isActive = true,
            estimatedDurationMinutes = 90
        ),
        ServiceCatalogItem(
            id = "srv_008",
            companyId = "comp_matriz",
            branchId = "branch_go_02",
            branchName = "Filial Goiânia",
            code = "SRV-GO-02",
            name = "Vitrificação Cerâmica Regional (Goiânia)",
            description = "Proteção cerâmica com nano-sílica com garantia de 2 anos para o clima do Centro-Oeste.",
            benefits = "• Resistência a altas temperaturas e UV forte\n• Brilho espelhado prolongado\n• Manutenção simplificada",
            category = "Proteção de pintura",
            salePrice = 1350.00,
            costPrice = 260.00,
            isActive = true,
            estimatedDurationMinutes = 420
        )
    )
    database.serviceCatalogItemDao().insertServices(catalogServices)

    // Seed Sample Virtual Store Orders
    val sampleStoreOrders = listOf(
        VirtualStoreOrder(
            id = "order_vs_001",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            orderNumber = "PED-2041",
            customerName = "Guilherme Alencar",
            customerPhone = "(11) 98765-1122",
            customerEmail = "guilherme@gmail.com",
            customerVehiclePlate = "BRA2E19",
            customerVehicleModel = "Toyota Corolla",
            itemsSummary = "1x Vitrificação Cerâmica 9H + 1x Toalha Microfibra 1200 GSM",
            itemsList = listOf(
                VirtualStoreOrderItem("srv_005", "Vitrificação Cerâmica 9H", true, 1, 1490.0),
                VirtualStoreOrderItem("prod_004", "Toalha de Microfibra 1200 GSM", false, 1, 65.0)
            ),
            subtotal = 1555.00,
            discount = 55.00,
            total = 1500.00,
            status = "Confirmado",
            isQuoteRequest = false,
            paymentMethod = "PIX",
            paymentStatus = "Aguardando Pagamento",
            notes = "Cliente agendou a aplicação para sábado às 09:00 na matriz.",
            dateFormatted = "18/10/2026"
        ),
        VirtualStoreOrder(
            id = "order_vs_002",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            orderNumber = "PED-2042",
            customerName = "Dra. Patrícia Fontes",
            customerPhone = "(11) 99123-4567",
            customerEmail = "patricia.fontes@med.com",
            customerVehiclePlate = "FDX9J00",
            customerVehicleModel = "Jeep Compass Longitude",
            itemsSummary = "1x Higienização Interna com Oxi-Sanitização",
            itemsList = listOf(
                VirtualStoreOrderItem("srv_002", "Higienização Interna com Oxi-Sanitização", true, 1, 380.0)
            ),
            subtotal = 380.00,
            discount = 0.00,
            total = 380.00,
            status = "Em Andamento",
            isQuoteRequest = false,
            paymentMethod = "Cartão de Crédito",
            paymentStatus = "A Faturar",
            notes = "Carro entregue pela manhã para execução do serviço.",
            dateFormatted = "18/10/2026"
        )
    )
    database.virtualStoreOrderDao().insertOrders(sampleStoreOrders)

    // Employees
    val emp1 = Employee(
        id = "emp_001",
        companyId = "comp_matriz",
        name = "Carlos Santana",
        role = "Chefe de Oficina Mecânica",
        department = "Oficina & Manutenção",
        phone = "(11) 97700-1122"
    )

    val emp2 = Employee(
        id = "emp_002",
        companyId = "comp_matriz",
        name = "Lucas Meireles",
        role = "Técnico Especialista Automotivo",
        department = "Oficina & Manutenção",
        phone = "(11) 96655-4433"
    )

    database.employeeDao().insertEmployee(emp1)
    database.employeeDao().insertEmployee(emp2)

    // Goal
    val goal = Goal(
        id = "goal_001",
        companyId = "comp_matriz",
        title = "Meta Faturamento Mensal - Pós-Vendas",
        targetAmount = 150000.0,
        currentAmount = 98500.0,
        month = "Setembro/2026"
    )
    database.goalDao().insertGoal(goal)

    // Notifications
    val n1 = TayleNotification(
        id = "notif_001",
        companyId = "comp_matriz",
        title = "⚠️ Alerta de Estoque Baixo",
        description = "Filtro de Óleo PSL55 com apenas 8 UN em estoque (Mínimo: 15 UN).",
        type = NotificationType.WARNING
    )

    val n2 = TayleNotification(
        id = "notif_002",
        companyId = "comp_matriz",
        title = "⚠️ Alerta de Estoque Baixo",
        description = "Fluido de Freio DOT4 com apenas 5 FR em estoque (Mínimo: 10 FR).",
        type = NotificationType.WARNING
    )

    val n3 = TayleNotification(
        id = "notif_003",
        companyId = "comp_matriz",
        title = "📋 Nova O.S. Aberta",
        description = "O.S. #1001 criada para Roberto Silveira (Toyota Corolla).",
        type = NotificationType.INFO
    )

    database.notificationDao().insertNotification(n1)
    database.notificationDao().insertNotification(n2)
    database.notificationDao().insertNotification(n3)

    // Seed Commercial Products & Services (Item 6, 7, 8)
    val products = listOf(
        // PÓS-VENDAS (🔵)
        CommercialProduct(
            id = "prod_001",
            companyId = "comp_matriz",
            name = "Pastilha de Freio Cerâmica Bosch",
            itemType = ItemType.PRODUTO,
            category = "Freios",
            sku = "FR-BSH-01",
            salePrice = 320.0,
            costPrice = 160.0,
            stockCurrent = 18,
            stockMin = 6,
            stockIdeal = 20,
            stockMax = 40,
            department = CommercialDepartment.POS_VENDAS,
            supplier = "Bosch Brasil",
            salesCount = 42,
            revenueGenerated = 13440.0,
            description = "Jogo de pastilhas de alta durabilidade e frenagem silenciosa."
        ),
        CommercialProduct(
            id = "prod_002",
            companyId = "comp_matriz",
            name = "Revisão e Troca de Óleo Completa",
            itemType = ItemType.SERVICO,
            category = "Manutenção Preventiva",
            sku = "SRV-REV-01",
            salePrice = 450.0,
            costPrice = 180.0,
            stockCurrent = 999,
            stockMin = 0,
            stockIdeal = 0,
            stockMax = 0,
            department = CommercialDepartment.POS_VENDAS,
            supplier = "Serviço Próprio",
            salesCount = 68,
            revenueGenerated = 30600.0,
            description = "Inclui óleo sintético 5W30, filtro de óleo, ar e verificação de 25 itens."
        ),
        CommercialProduct(
            id = "prod_003",
            companyId = "comp_matriz",
            name = "Vitrificação Cerâmica de Pintura 9H",
            itemType = ItemType.SERVICO,
            category = "Estética Automotiva",
            sku = "SRV-VIT-01",
            salePrice = 1800.0,
            costPrice = 450.0,
            stockCurrent = 999,
            stockMin = 0,
            stockIdeal = 0,
            stockMax = 0,
            department = CommercialDepartment.POS_VENDAS,
            supplier = "Serviço Próprio",
            salesCount = 15,
            revenueGenerated = 27000.0,
            isPromotional = true,
            promoPrice = 1590.0,
            description = "Proteção de verniz com garantia de 3 anos e repelência extrema."
        ),
        CommercialProduct(
            id = "prod_004",
            companyId = "comp_matriz",
            name = "Amortecedor Dianteiro Monroe Pressurizado",
            itemType = ItemType.PRODUTO,
            category = "Suspensão",
            sku = "SUS-MON-44",
            salePrice = 580.0,
            costPrice = 330.0,
            stockCurrent = 3, // 🔴 Limite / Reposição
            stockMin = 4,
            stockIdeal = 12,
            stockMax = 24,
            department = CommercialDepartment.POS_VENDAS,
            supplier = "Monroe Amortecedores",
            salesCount = 28,
            revenueGenerated = 16240.0,
            description = "Amortecedor a gás de máxima estabilidade para SUVs e sedans."
        ),
        CommercialProduct(
            id = "prod_005",
            companyId = "comp_matriz",
            name = "Filtro de Ar de Cabine Anti-Pólen",
            itemType = ItemType.PRODUTO,
            category = "Filtros",
            sku = "FLT-CAB-12",
            salePrice = 95.0,
            costPrice = 35.0,
            stockCurrent = 0, // 🔴 Esgotado / Reposição Necessária
            stockMin = 8,
            stockIdeal = 25,
            stockMax = 50,
            department = CommercialDepartment.POS_VENDAS,
            supplier = "Tecfil",
            salesCount = 55,
            revenueGenerated = 5225.0,
            description = "Filtragem de 99% das impurezas do ar-condicionado."
        ),
        // NOVOS (🟢)
        CommercialProduct(
            id = "prod_006",
            companyId = "comp_matriz",
            name = "Toyota Corolla XEi 2.0 Dynamic Force 2026",
            itemType = ItemType.PRODUTO,
            category = "Sedan Médio",
            sku = "AUT-COR-26",
            salePrice = 162900.0,
            costPrice = 149500.0,
            stockCurrent = 6,
            stockMin = 2,
            stockIdeal = 8,
            stockMax = 15,
            department = CommercialDepartment.NOVOS,
            supplier = "Toyota do Brasil",
            salesCount = 7,
            revenueGenerated = 1140300.0,
            description = "Sedan líder de mercado com 7 airbags, Toyota Safety Sense e multimídia 10 pol."
        ),
        CommercialProduct(
            id = "prod_007",
            companyId = "comp_matriz",
            name = "Volkswagen Polo Track 1.0 MPI Flex 2026",
            itemType = ItemType.PRODUTO,
            category = "Hatch Compacto",
            sku = "AUT-POL-26",
            salePrice = 91900.0,
            costPrice = 84200.0,
            stockCurrent = 4, // 🟡 Atenção
            stockMin = 3,
            stockIdeal = 10,
            stockMax = 20,
            department = CommercialDepartment.NOVOS,
            supplier = "Volkswagen do Brasil",
            salesCount = 12,
            revenueGenerated = 1102800.0,
            description = "Robustez mecânica incomparável, baixo custo de manutenção e consumo nota A."
        ),
        CommercialProduct(
            id = "prod_008",
            companyId = "comp_matriz",
            name = "Hyundai Creta Comfort Plus 1.0 Turbo 2026",
            itemType = ItemType.PRODUTO,
            category = "SUV Compacto",
            sku = "AUT-CRT-26",
            salePrice = 143900.0,
            costPrice = 132000.0,
            stockCurrent = 5,
            stockMin = 2,
            stockIdeal = 6,
            stockMax = 12,
            department = CommercialDepartment.NOVOS,
            supplier = "Hyundai Motor Brasil",
            salesCount = 9,
            revenueGenerated = 1295100.0,
            isPromotional = true,
            promoPrice = 139900.0,
            description = "Motor turbo com injeção direta, faróis em LED e amplo espaço interno familiar."
        ),
        // SEMINOVOS (🟠)
        CommercialProduct(
            id = "prod_009",
            companyId = "comp_matriz",
            name = "Jeep Compass Longitude T270 Turbo 2023",
            itemType = ItemType.PRODUTO,
            category = "SUV Médio",
            sku = "SEM-JEP-23",
            salePrice = 138500.0,
            costPrice = 122000.0,
            stockCurrent = 2, // 🟡 Médio
            stockMin = 1,
            stockIdeal = 4,
            stockMax = 8,
            department = CommercialDepartment.SEMINOVOS,
            supplier = "Trade-In Concessionária",
            salesCount = 5,
            revenueGenerated = 692500.0,
            description = "Único dono, 32.000 km rodados, todas as revisões feitas na concessionária."
        ),
        CommercialProduct(
            id = "prod_010",
            companyId = "comp_matriz",
            name = "Honda Civic Touring 1.5 Turbo 2021",
            itemType = ItemType.PRODUTO,
            category = "Sedan Premium",
            sku = "SEM-CIV-21",
            salePrice = 128900.0,
            costPrice = 114000.0,
            stockCurrent = 1, // 🔴 Limite
            stockMin = 1,
            stockIdeal = 3,
            stockMax = 6,
            department = CommercialDepartment.SEMINOVOS,
            supplier = "Trade-In Concessionária",
            salesCount = 4,
            revenueGenerated = 515600.0,
            description = "Teto solar, faróis Full LED, som premium e laudo cautelar 100% aprovado."
        )
    )
    database.commercialProductDao().insertProducts(products)

    // Seed Commercial Sales (Item 1, 2, 3, 4, 10, 11, 12)
    val sales = listOf(
        // MATRIZ SÃO PAULO (branch_sp_matriz)
        CommercialSale(
            id = "sale_001",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            userId = "usr_admin",
            departmentId = "NOVOS",
            dateFormatted = "05/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Marcelo Alcantara",
            sellerName = "Carlos Rocha",
            department = CommercialDepartment.NOVOS,
            productName = "Toyota Corolla XEi 2.0 2026",
            quantity = 1,
            salePrice = 162900.0,
            costPrice = 149500.0,
            branch = "Matriz São Paulo"
        ),
        CommercialSale(
            id = "sale_002",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            userId = "usr_gerente",
            departmentId = "POS_VENDAS",
            dateFormatted = "05/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Fernanda Costa",
            sellerName = "Mariana Lopes",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Revisão e Troca de Óleo Completa",
            quantity = 1,
            salePrice = 450.0,
            costPrice = 180.0,
            branch = "Matriz São Paulo"
        ),
        CommercialSale(
            id = "sale_003",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            userId = "usr_gerente",
            departmentId = "POS_VENDAS",
            dateFormatted = "05/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Rodrigo Viana",
            sellerName = "Eduardo Farias",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Pastilha de Freio Cerâmica Bosch",
            quantity = 2,
            salePrice = 320.0,
            costPrice = 160.0,
            branch = "Matriz São Paulo"
        ),
        CommercialSale(
            id = "sale_004",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            userId = "usr_admin",
            departmentId = "SEMINOVOS",
            dateFormatted = "04/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Renata Guimarães",
            sellerName = "Carlos Rocha",
            department = CommercialDepartment.SEMINOVOS,
            productName = "Jeep Compass Longitude 2023",
            quantity = 1,
            salePrice = 138500.0,
            costPrice = 122000.0,
            branch = "Matriz São Paulo"
        ),
        CommercialSale(
            id = "sale_005",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            userId = "usr_admin",
            departmentId = "NOVOS",
            dateFormatted = "03/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Claudio Nogueira",
            sellerName = "Mariana Lopes",
            department = CommercialDepartment.NOVOS,
            productName = "Volkswagen Polo Track 2026",
            quantity = 1,
            salePrice = 91900.0,
            costPrice = 84200.0,
            branch = "Matriz São Paulo"
        ),
        CommercialSale(
            id = "sale_006",
            companyId = "comp_matriz",
            branchId = "branch_sp_matriz",
            branchName = "Matriz São Paulo",
            userId = "usr_gerente",
            departmentId = "POS_VENDAS",
            dateFormatted = "02/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Juliana Prado",
            sellerName = "Eduardo Farias",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Vitrificação Cerâmica de Pintura 9H",
            quantity = 1,
            salePrice = 1590.0,
            costPrice = 450.0,
            branch = "Matriz São Paulo"
        ),

        // FILIAL GOIÂNIA (branch_go_02)
        // 120 vendas acumuladas no período totalizando R$ 50.000 (Ticket médio R$ 416,67)
        CommercialSale(
            id = "sale_go_001",
            companyId = "comp_matriz",
            branchId = "branch_go_02",
            branchName = "Filial Goiânia",
            userId = "usr_gerente_go",
            departmentId = "POS_VENDAS",
            dateFormatted = "05/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Arthur Vasconcelos",
            sellerName = "Ricardo Mendes",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Pacote de Revisão e Troca de Óleo GO",
            quantity = 50,
            salePrice = 400.0,
            costPrice = 180.0,
            branch = "Filial Goiânia"
        ),
        CommercialSale(
            id = "sale_go_002",
            companyId = "comp_matriz",
            branchId = "branch_go_02",
            branchName = "Filial Goiânia",
            userId = "usr_gerente_go",
            departmentId = "POS_VENDAS",
            dateFormatted = "04/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Marcos Vinicius",
            sellerName = "Ricardo Mendes",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Higienização e Filtros de Ar-Condicionado",
            quantity = 40,
            salePrice = 350.0,
            costPrice = 120.0,
            branch = "Filial Goiânia"
        ),
        CommercialSale(
            id = "sale_go_003",
            companyId = "comp_matriz",
            branchId = "branch_go_02",
            branchName = "Filial Goiânia",
            userId = "usr_gerente_go",
            departmentId = "POS_VENDAS",
            dateFormatted = "03/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Luciana Resende",
            sellerName = "Ricardo Mendes",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Alinhamento 3D e Balanceamento Goiânia",
            quantity = 30,
            salePrice = 533.33,
            costPrice = 160.0,
            branch = "Filial Goiânia"
        ),

        // FILIAL BRASÍLIA (branch_df_03)
        // Vendas: 18, Faturamento: R$ 380.000, Ticket médio: R$ 21.111,11
        CommercialSale(
            id = "sale_df_001",
            companyId = "comp_matriz",
            branchId = "branch_df_03",
            branchName = "Filial Brasília",
            userId = "usr_gerente_df",
            departmentId = "NOVOS",
            dateFormatted = "05/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Dep. Fábio Silveira",
            sellerName = "Camila Guimarães",
            department = CommercialDepartment.NOVOS,
            productName = "Hyundai Creta Comfort Plus 1.0T",
            quantity = 2,
            salePrice = 143900.0,
            costPrice = 132000.0,
            branch = "Filial Brasília"
        ),
        CommercialSale(
            id = "sale_df_002",
            companyId = "comp_matriz",
            branchId = "branch_df_03",
            branchName = "Filial Brasília",
            userId = "usr_gerente_df",
            departmentId = "POS_VENDAS",
            dateFormatted = "04/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Vanessa Lins",
            sellerName = "Camila Guimarães",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Blindagem Nível III-A e Acessórios",
            quantity = 16,
            salePrice = 5762.50,
            costPrice = 3200.0,
            branch = "Filial Brasília"
        ),

        // FILIAL BELO HORIZONTE (branch_bh_04)
        // Vendas: 15, Faturamento: R$ 240.000, Ticket médio: R$ 16.000,00
        CommercialSale(
            id = "sale_bh_001",
            companyId = "comp_matriz",
            branchId = "branch_bh_04",
            branchName = "Filial Belo Horizonte",
            userId = "usr_operador_bh",
            departmentId = "SEMINOVOS",
            dateFormatted = "05/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Bruno Figueiredo",
            sellerName = "Thiago Vasconcelos",
            department = CommercialDepartment.SEMINOVOS,
            productName = "Honda Civic Touring 1.5T BH",
            quantity = 1,
            salePrice = 128900.0,
            costPrice = 114000.0,
            branch = "Filial Belo Horizonte"
        ),
        CommercialSale(
            id = "sale_bh_002",
            companyId = "comp_matriz",
            branchId = "branch_bh_04",
            branchName = "Filial Belo Horizonte",
            userId = "usr_operador_bh",
            departmentId = "POS_VENDAS",
            dateFormatted = "03/09/2026",
            monthPeriod = "Setembro 2026",
            clientName = "Renata Peixoto",
            sellerName = "Thiago Vasconcelos",
            department = CommercialDepartment.POS_VENDAS,
            productName = "Kit Acessórios Originais e Revisão BH",
            quantity = 14,
            salePrice = 7935.71,
            costPrice = 4100.0,
            branch = "Filial Belo Horizonte"
        )
    )
    database.commercialSaleDao().insertSales(sales)

    // Seed Sales Opportunities (Funil de Vendas - Item 5)
    val opportunities = listOf(
        SalesOpportunity(
            id = "opp_001",
            companyId = "comp_matriz",
            clientName = "Dra. Beatriz Menezes",
            clientPhone = "(11) 99887-1122",
            title = "Creta 1.0 Turbo 2026 - Avaliação de Usado",
            potentialValue = 139900.0,
            stage = FunnelStage.NEGOCIACAO,
            temperature = OpportunityTemperature.QUENTE,
            daysInStage = 2,
            department = CommercialDepartment.NOVOS,
            sellerName = "Carlos Rocha",
            notes = "Cliente gostou da taxa de 0% e quer fechar até sexta-feira."
        ),
        SalesOpportunity(
            id = "opp_002",
            companyId = "comp_matriz",
            clientName = "Eng. Gustavo Pires",
            clientPhone = "(11) 98765-2233",
            title = "Corolla XEi 2026 - Financiamento 50%",
            potentialValue = 162900.0,
            stage = FunnelStage.PROPOSTA,
            temperature = OpportunityTemperature.NEGOCIANDO,
            daysInStage = 4,
            department = CommercialDepartment.NOVOS,
            sellerName = "Mariana Lopes",
            notes = "Proposta enviada pelo WhatsApp. Aguardando retorno da análise de crédito."
        ),
        SalesOpportunity(
            id = "opp_003",
            companyId = "comp_matriz",
            clientName = "Thiago Silveira",
            clientPhone = "(11) 97654-8899",
            title = "Civic Touring 2021 Seminovo",
            potentialValue = 128900.0,
            stage = FunnelStage.PROPOSTA,
            temperature = OpportunityTemperature.PARADA,
            daysInStage = 8,
            department = CommercialDepartment.SEMINOVOS,
            sellerName = "Eduardo Farias",
            notes = "Cliente visualizou a proposta mas parou de responder há 4 dias."
        ),
        SalesOpportunity(
            id = "opp_004",
            companyId = "comp_matriz",
            clientName = "Patrícia Antunes",
            clientPhone = "(11) 96543-3322",
            title = "Revisão 40.000 km + Discos de Freio",
            potentialValue = 2450.0,
            stage = FunnelStage.CONTATO,
            temperature = OpportunityTemperature.QUENTE,
            daysInStage = 1,
            department = CommercialDepartment.POS_VENDAS,
            sellerName = "Lucas Meireles",
            notes = "Agendamento para conferência presencial amanhã às 09:00."
        ),
        SalesOpportunity(
            id = "opp_005",
            companyId = "comp_matriz",
            clientName = "Marcos Vinicius",
            clientPhone = "(11) 95432-1100",
            title = "Lead do Instagram - Polo Track",
            potentialValue = 91900.0,
            stage = FunnelStage.LEAD,
            temperature = OpportunityTemperature.NEGOCIANDO,
            daysInStage = 1,
            department = CommercialDepartment.NOVOS,
            sellerName = "Mariana Lopes",
            notes = "Perguntou sobre entrada e prazo de entrega."
        ),
        SalesOpportunity(
            id = "opp_006",
            companyId = "comp_matriz",
            clientName = "Fábio Drummond",
            clientPhone = "(11) 94321-7788",
            title = "Jeep Compass 2023 - Fechamento de Contrato",
            potentialValue = 138500.0,
            stage = FunnelStage.FECHAMENTO,
            temperature = OpportunityTemperature.QUENTE,
            daysInStage = 1,
            department = CommercialDepartment.SEMINOVOS,
            sellerName = "Carlos Rocha",
            notes = "Sinal pago, aguardando compensação para faturar."
        )
    )
    database.salesOpportunityDao().insertOpportunities(opportunities)

    // Seed Lost Sales (Item 19)
    val lostSales = listOf(
        LostSale(
            id = "lost_001",
            companyId = "comp_matriz",
            clientName = "Jorge Mendonça",
            clientPhone = "(11) 98877-6655",
            productOrService = "Toyota Corolla XEi 2.0",
            value = 162900.0,
            reason = LossReason.PRECO,
            sellerName = "Carlos Rocha",
            dateFormatted = "02/09/2026",
            observations = "Cliente achou a taxa de financiamento elevada em relação ao banco dele.",
            isRecovered = false
        ),
        LostSale(
            id = "lost_002",
            companyId = "comp_matriz",
            clientName = "Amanda Duarte",
            clientPhone = "(11) 97766-5544",
            productOrService = "Vitrificação 9H + Higienização",
            value = 2100.0,
            reason = LossReason.SEM_RETORNO,
            sellerName = "Lucas Meireles",
            dateFormatted = "28/08/2026",
            observations = "Orçamento enviado no WhatsApp, não respondeu mais após 5 dias.",
            isRecovered = false
        ),
        LostSale(
            id = "lost_003",
            companyId = "comp_matriz",
            clientName = "Ricardo Lemos",
            clientPhone = "(11) 96655-4433",
            productOrService = "Jeep Compass 2023",
            value = 138500.0,
            reason = LossReason.CONCORRENCIA,
            sellerName = "Eduardo Farias",
            dateFormatted = "25/08/2026",
            observations = "Concorrente ofereceu IPVA 2026 grátis e tanque cheio.",
            isRecovered = false
        )
    )
    database.lostSaleDao().insertLostSales(lostSales)

    // Seed Daily Agenda Tasks (Item 17 & 18)
    val agendaTasks = listOf(
        // Início do dia
        DailyAgendaTask(
            id = "task_001",
            companyId = "comp_matriz",
            sellerName = "Carlos Rocha",
            period = AgendaDayPeriod.INICIO_DO_DIA,
            title = "Contatar cliente quente - Dra. Beatriz",
            clientName = "Dra. Beatriz Menezes",
            clientPhone = "(11) 99887-1122",
            targetAction = "Apresentar aprovação da taxa 0% no Creta Turbo",
            isCompleted = false,
            isHotOpportunity = true
        ),
        DailyAgendaTask(
            id = "task_002",
            companyId = "comp_matriz",
            sellerName = "Mariana Lopes",
            period = AgendaDayPeriod.INICIO_DO_DIA,
            title = "Retorno de proposta pendente",
            clientName = "Eng. Gustavo Pires",
            clientPhone = "(11) 98765-2233",
            targetAction = "Confirmar recebimento do cálculo de financiamento do Corolla",
            isCompleted = false,
            isHotOpportunity = false
        ),
        // Durante o dia
        DailyAgendaTask(
            id = "task_003",
            companyId = "comp_matriz",
            sellerName = "Eduardo Farias",
            period = AgendaDayPeriod.DURANTE_O_DIA,
            title = "Follow-up de proposta parada há 8 dias",
            clientName = "Thiago Silveira",
            clientPhone = "(11) 97654-8899",
            targetAction = "Enviar condição especial de bônus na troca pelo Civic",
            isCompleted = false,
            isHotOpportunity = false
        ),
        DailyAgendaTask(
            id = "task_004",
            companyId = "comp_matriz",
            sellerName = "Lucas Meireles",
            period = AgendaDayPeriod.DURANTE_O_DIA,
            title = "Recepção para checklist de serviços",
            clientName = "Patrícia Antunes",
            clientPhone = "(11) 96543-3322",
            targetAction = "Realizar inspeção visual e confirmar revisão de 40k km",
            isCompleted = false,
            isHotOpportunity = true
        ),
        // Final do dia
        DailyAgendaTask(
            id = "task_005",
            companyId = "comp_matriz",
            sellerName = "Carlos Rocha",
            period = AgendaDayPeriod.FINAL_DO_DIA,
            title = "Conferência de fechamento de contrato",
            clientName = "Fábio Drummond",
            clientPhone = "(11) 94321-7788",
            targetAction = "Validar faturamento e entrega do Jeep Compass",
            isCompleted = false,
            isHotOpportunity = true
        ),
        DailyAgendaTask(
            id = "task_006",
            companyId = "comp_matriz",
            sellerName = "Equipe Geral",
            period = AgendaDayPeriod.FINAL_DO_DIA,
            title = "Planejamento de contatos para amanhã",
            clientName = "Leads novos do dia",
            clientPhone = "-",
            targetAction = "Revisar funil e organizar prioridades de vendas",
            isCompleted = false,
            isHotOpportunity = false
        )
    )
    database.dailyAgendaTaskDao().insertAgendaTasks(agendaTasks)
}

