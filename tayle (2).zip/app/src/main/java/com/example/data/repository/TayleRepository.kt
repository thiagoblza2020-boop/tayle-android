package com.example.data.repository

import com.example.data.local.TayleDatabase
import com.example.data.model.Branch
import com.example.data.model.Company
import com.example.data.model.Employee
import com.example.data.model.Goal
import com.example.data.model.Material
import com.example.data.model.MaterialMovement
import com.example.data.model.MaterialOrder
import com.example.data.model.MaterialWaste
import com.example.data.model.ServiceOrder
import com.example.data.model.TayleNotification
import com.example.data.model.User
import com.example.data.model.Vehicle
import com.example.data.model.CommercialProduct
import com.example.data.model.CommercialSale
import com.example.data.model.DailyAgendaTask
import com.example.data.model.LostSale
import com.example.data.model.SalesOpportunity
import com.example.data.model.StockMovement
import kotlinx.coroutines.flow.Flow

class TayleRepository(private val db: TayleDatabase) {

    fun getAllCompanies(): Flow<List<Company>> = db.companyDao().getAllCompanies()

    suspend fun getCompanyById(id: String): Company? = db.companyDao().getCompanyById(id)

    suspend fun insertCompany(company: Company) = db.companyDao().insertCompany(company)

    suspend fun updateCompany(company: Company) = db.companyDao().updateCompany(company)

    fun getUsersByCompany(companyId: String): Flow<List<User>> = db.userDao().getUsersByCompany(companyId)

    suspend fun getUserByEmail(email: String): User? = db.userDao().getUserByEmail(email)

    suspend fun getUserById(id: String): User? = db.userDao().getUserById(id)

    suspend fun insertUser(user: User) = db.userDao().insertUser(user)

    suspend fun updateUser(user: User) = db.userDao().updateUser(user)

    fun getVehicles(companyId: String): Flow<List<Vehicle>> = db.vehicleDao().getVehiclesByCompany(companyId)

    suspend fun insertVehicle(vehicle: Vehicle) = db.vehicleDao().insertVehicle(vehicle)

    suspend fun updateVehicle(vehicle: Vehicle) = db.vehicleDao().updateVehicle(vehicle)

    suspend fun deleteVehicle(id: String) = db.vehicleDao().deleteVehicleById(id)

    fun getOrders(companyId: String): Flow<List<ServiceOrder>> = db.serviceOrderDao().getOrdersByCompany(companyId)

    suspend fun insertOrder(order: ServiceOrder) = db.serviceOrderDao().insertOrder(order)

    suspend fun updateOrder(order: ServiceOrder) = db.serviceOrderDao().updateOrder(order)

    suspend fun deleteOrder(id: String) = db.serviceOrderDao().deleteOrderById(id)

    fun getEmployees(companyId: String): Flow<List<Employee>> = db.employeeDao().getEmployeesByCompany(companyId)

    suspend fun insertEmployee(employee: Employee) = db.employeeDao().insertEmployee(employee)

    suspend fun updateEmployee(employee: Employee) = db.employeeDao().updateEmployee(employee)

    fun getGoal(companyId: String): Flow<Goal?> = db.goalDao().getGoalByCompany(companyId)

    suspend fun insertGoal(goal: Goal) = db.goalDao().insertGoal(goal)

    suspend fun updateGoal(goal: Goal) = db.goalDao().updateGoal(goal)

    fun getNotifications(companyId: String): Flow<List<TayleNotification>> = db.notificationDao().getNotificationsByCompany(companyId)

    suspend fun insertNotification(notification: TayleNotification) = db.notificationDao().insertNotification(notification)

    suspend fun markAllNotificationsAsRead(companyId: String) = db.notificationDao().markAllAsRead(companyId)

    fun getMaterials(companyId: String): Flow<List<Material>> = db.materialDao().getMaterialsByCompany(companyId)

    fun getLowStockMaterials(companyId: String): Flow<List<Material>> = db.materialDao().getLowStockMaterials(companyId)

    suspend fun getMaterialById(id: String): Material? = db.materialDao().getMaterialById(id)

    suspend fun insertMaterial(material: Material) = db.materialDao().insertMaterial(material)

    suspend fun updateMaterial(material: Material) = db.materialDao().updateMaterial(material)

    suspend fun deleteMaterial(id: String) = db.materialDao().deleteMaterialById(id)

    fun getMaterialMovements(companyId: String): Flow<List<MaterialMovement>> = db.materialMovementDao().getMovementsByCompany(companyId)

    fun getMovementsByMaterial(materialId: String): Flow<List<MaterialMovement>> = db.materialMovementDao().getMovementsByMaterial(materialId)

    suspend fun insertMovement(movement: MaterialMovement) = db.materialMovementDao().insertMovement(movement)

    fun getMaterialOrders(companyId: String): Flow<List<MaterialOrder>> = db.materialOrderDao().getOrdersByCompany(companyId)

    suspend fun getMaterialOrderById(id: String): MaterialOrder? = db.materialOrderDao().getOrderById(id)

    suspend fun insertMaterialOrder(order: MaterialOrder) = db.materialOrderDao().insertOrder(order)

    suspend fun updateMaterialOrder(order: MaterialOrder) = db.materialOrderDao().updateOrder(order)

    suspend fun deleteMaterialOrder(id: String) = db.materialOrderDao().deleteOrderById(id)

    fun getMaterialWastes(companyId: String): Flow<List<MaterialWaste>> = db.materialWasteDao().getWastesByCompany(companyId)

    suspend fun insertMaterialWaste(waste: MaterialWaste) = db.materialWasteDao().insertWaste(waste)

    suspend fun deleteMaterialWaste(id: String) = db.materialWasteDao().deleteWasteById(id)

    // Commercial Products & Services
    fun getCommercialProducts(companyId: String): Flow<List<CommercialProduct>> =
        db.commercialProductDao().getProductsByCompany(companyId)

    suspend fun insertCommercialProduct(product: CommercialProduct) =
        db.commercialProductDao().insertProduct(product)

    suspend fun updateCommercialProduct(product: CommercialProduct) =
        db.commercialProductDao().updateProduct(product)

    suspend fun deleteCommercialProduct(id: String) =
        db.commercialProductDao().deleteProductById(id)

    // Stock Movements
    fun getStockMovements(companyId: String): Flow<List<StockMovement>> =
        db.stockMovementDao().getMovementsByCompany(companyId)

    suspend fun insertStockMovement(movement: StockMovement) =
        db.stockMovementDao().insertMovement(movement)

    // Commercial Sales
    fun getCommercialSales(companyId: String): Flow<List<CommercialSale>> =
        db.commercialSaleDao().getSalesByCompany(companyId)

    suspend fun insertCommercialSale(sale: CommercialSale) =
        db.commercialSaleDao().insertSale(sale)

    // Sales Funnel Opportunities
    fun getSalesOpportunities(companyId: String): Flow<List<SalesOpportunity>> =
        db.salesOpportunityDao().getOpportunitiesByCompany(companyId)

    suspend fun insertSalesOpportunity(opp: SalesOpportunity) =
        db.salesOpportunityDao().insertOpportunity(opp)

    suspend fun updateSalesOpportunity(opp: SalesOpportunity) =
        db.salesOpportunityDao().updateOpportunity(opp)

    suspend fun deleteSalesOpportunity(id: String) =
        db.salesOpportunityDao().deleteOpportunityById(id)

    // Lost Sales
    fun getLostSales(companyId: String): Flow<List<LostSale>> =
        db.lostSaleDao().getLostSalesByCompany(companyId)

    suspend fun insertLostSale(lostSale: LostSale) =
        db.lostSaleDao().insertLostSale(lostSale)

    suspend fun updateLostSale(lostSale: LostSale) =
        db.lostSaleDao().updateLostSale(lostSale)

    // Daily Agenda Tasks
    fun getDailyAgendaTasks(companyId: String): Flow<List<DailyAgendaTask>> =
        db.dailyAgendaTaskDao().getAgendaTasksByCompany(companyId)

    suspend fun insertDailyAgendaTask(task: DailyAgendaTask) =
        db.dailyAgendaTaskDao().insertAgendaTask(task)

    suspend fun updateDailyAgendaTask(task: DailyAgendaTask) =
        db.dailyAgendaTaskDao().updateAgendaTask(task)

    suspend fun deleteDailyAgendaTask(id: String) =
        db.dailyAgendaTaskDao().deleteAgendaTaskById(id)

    // Branches (Matriz e Filiais)
    fun getBranches(companyId: String): Flow<List<Branch>> =
        db.branchDao().getBranchesByCompany(companyId)

    suspend fun getBranchById(id: String): Branch? =
        db.branchDao().getBranchById(id)

    suspend fun insertBranch(branch: Branch) =
        db.branchDao().insertBranch(branch)

    suspend fun updateBranch(branch: Branch) =
        db.branchDao().updateBranch(branch)

    suspend fun deleteBranch(id: String) =
        db.branchDao().deleteBranch(id)

    // Service Catalog Items (Serviços e Catálogo)
    fun getCatalogServices(companyId: String): Flow<List<com.example.data.model.ServiceCatalogItem>> =
        db.serviceCatalogItemDao().getServicesByCompany(companyId)

    suspend fun getCatalogServiceById(id: String): com.example.data.model.ServiceCatalogItem? =
        db.serviceCatalogItemDao().getServiceById(id)

    suspend fun insertCatalogService(service: com.example.data.model.ServiceCatalogItem) =
        db.serviceCatalogItemDao().insertService(service)

    suspend fun updateCatalogService(service: com.example.data.model.ServiceCatalogItem) =
        db.serviceCatalogItemDao().updateService(service)

    suspend fun deleteCatalogService(id: String) =
        db.serviceCatalogItemDao().deleteServiceById(id)

    // Virtual Store Orders (Loja Virtual)
    fun getVirtualStoreOrders(companyId: String): Flow<List<com.example.data.model.VirtualStoreOrder>> =
        db.virtualStoreOrderDao().getOrdersByCompany(companyId)

    suspend fun getVirtualStoreOrderById(id: String): com.example.data.model.VirtualStoreOrder? =
        db.virtualStoreOrderDao().getOrderById(id)

    suspend fun insertVirtualStoreOrder(order: com.example.data.model.VirtualStoreOrder) =
        db.virtualStoreOrderDao().insertOrder(order)

    suspend fun updateVirtualStoreOrder(order: com.example.data.model.VirtualStoreOrder) =
        db.virtualStoreOrderDao().updateOrder(order)

    suspend fun deleteVirtualStoreOrder(id: String) =
        db.virtualStoreOrderDao().deleteOrderById(id)
}
