package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "branches")
data class Branch(
    @PrimaryKey val id: String,
    val companyId: String,
    val name: String,                    // ex: "Matriz São Paulo", "Filial Goiânia", "Filial Brasília"
    val code: String,                    // ex: "SP-01", "GO-02", "DF-03"
    val address: String,                 // Endereço completo
    val phone: String,                   // Telefone de contato
    val managerName: String,             // Responsável pela unidade
    val status: String = "Ativa",        // Status: "Ativa", "Inativa", "Em Implantação"
    val isHeadquarters: Boolean = false, // 🏢 true para MATRIZ, 🏪 false para FILIAL
    val authorizedUsersCount: Int = 5,   // Quantidade de usuários autorizados
    val createdAt: Long = System.currentTimeMillis()
) {
    val displayTypeBadge: String get() = if (isHeadquarters) "🏢 MATRIZ" else "🏪 FILIAL"
}
