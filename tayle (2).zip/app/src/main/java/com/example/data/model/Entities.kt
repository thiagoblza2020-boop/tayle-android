package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val isHeadquartersUser: Boolean = true,
    val name: String,
    val email: String,
    val password: String = "",
    val role: UserRole = UserRole.ADMINISTRADOR,
    val roleTitle: String = "Administrador Geral",
    val department: Department = Department.ADMINISTRACAO,
    val phone: String = "(11) 98844-2200",
    val avatarInitials: String = "AD",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

enum class Department(
    val title: String,
    val shortLabel: String,
    val description: String,
    val badgeColor: Long
) {
    ADMINISTRACAO("Administração Geral", "Admin", "Gestão geral da concessionária", 0xFF3B82F6),
    OFICINA("Oficina & Serviços", "Oficina", "Manutenção mecânica e serviços técnicos", 0xFFF59E0B),
    ENTRADA("Recepção e Triagem", "Entrada", "Checklist inicial, vistoria e abertura da O.S.", 0xFF6B7280),
    LAVAGEM("Lavagem Técnica", "Lavagem", "Descontaminação, lavagem detalhada de chassi e motor", 0xFF0284C7),
    POLIMENTO("Polimento e Correção", "Polimento", "Corte, refino e lustro com nivelamento de verniz", 0xFFD97706),
    VITRIFICACAO("Proteção Cerâmica", "Vitrificação", "Aplicação de nano-revestimentos cerâmicos e cura UV", 0xFF7C3AED),
    ENTREGA("Entrega Técnica", "Entrega", "Inspeção final de qualidade e liberação ao cliente", 0xFF059669);

    val label: String get() = shortLabel
}

enum class VehicleStatus(val label: String) {
    AGUARDANDO("Aguardando Início"),
    AGUARDANDO_INSPECAO("Aguardando Inspeção"),
    AGUARDANDO_PECAS("Aguardando Peças"),
    EM_LAVAGEM("Em Lavagem"),
    EM_POLIMENTO("Em Polimento"),
    EM_VITRIFICACAO("Em Vitrificação"),
    EM_SERVICO("Em Serviço"),
    EM_REVISAO("Em Revisão Final"),
    PRONTO("Pronto para Entrega"),
    ENTREGUE("Entregue")
}

@Entity(tableName = "vehicles")
data class Vehicle(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val plate: String,
    val brand: String,
    val model: String,
    val year: Int = 2024,
    val color: String = "Preto",
    val clientName: String = "",
    val clientPhone: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val status: VehicleStatus = VehicleStatus.AGUARDANDO,
    val department: Department = Department.ENTRADA,
    val entryDate: Long = System.currentTimeMillis(),
    val stockNumber: String = "",
    val notes: String = "",
    val location: String = "Pátio Principal",
    val fuelLevel: String = "3/4",
    val mileage: String = "15.000 km"
) {
    val displayClientName: String get() = if (clientName.isNotBlank()) clientName else customerName
    val displayClientPhone: String get() = if (clientPhone.isNotBlank()) clientPhone else customerPhone
}

enum class OsStatus(val label: String, val hexColor: Long) {
    ORCAMENTO("Orçamento", 0xFF64748B),
    PENDENTE("Pendente", 0xFFD97706),
    ABERTA("Aberta", 0xFF3B82F6),
    APROVADA("Aprovada", 0xFF0284C7),
    EM_ANDAMENTO("Em Andamento", 0xFF00D4FF),
    EM_EXECUCAO("Em Execução", 0xFFD97706),
    AGUARDANDO("Aguardando", 0xFFF59E0B),
    REVISAO("Em Revisão", 0xFF6366F1),
    CONTROLE_QUALIDADE("Controle Qualidade", 0xFF7C3AED),
    CONCLUIDA("Concluída", 0xFF10B981),
    ENTREGUE("Entregue", 0xFF059669),
    CANCELADA("Cancelada", 0xFFEF4444)
}

enum class OsPriority(val label: String) {
    BAIXA("Baixa"),
    NORMAL("Normal"),
    ALTA("Alta"),
    URGENTE("Urgente")
}

data class ChecklistItem(
    val title: String = "",
    var isDone: Boolean = false
)

data class ServiceOrderItem(
    val serviceId: String = "",
    val serviceName: String = "",
    val description: String = "",
    val quantity: Int = 1,
    val unitPrice: Double = 0.0,
    val discount: Double = 0.0
) {
    val subtotal: Double get() = quantity * unitPrice
    val total: Double get() = (quantity * unitPrice) - discount
}

@Entity(tableName = "service_orders")
data class ServiceOrder(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val osNumber: String,
    val vehiclePlate: String = "",
    val vehicleModel: String = "",
    val clientName: String = "",
    val clientPhone: String = "",
    val serviceType: String = "Serviço Geral",
    val totalAmount: Double = 0.0,
    val status: OsStatus = OsStatus.EM_EXECUCAO,
    val priority: OsPriority = OsPriority.NORMAL,
    val department: Department = Department.POLIMENTO,
    val assignedEmployeeName: String = "Carlos Rocha",
    val estimatedDeliveryDate: String = "Hoje, 18:00",
    val checklistCompleted: Boolean = true,
    val photosCount: Int = 4,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val plate: String = "",
    val brand: String = "",
    val model: String = "",
    val year: Int = 2024,
    val color: String = "",
    val chassis: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val description: String = "",
    val technicianName: String = "",
    val discount: Double = 0.0,
    val notes: String = "",
    val servicesList: List<String> = emptyList(),
    val itemsList: List<ServiceOrderItem> = emptyList(),
    val checklist: List<ChecklistItem> = emptyList()
) {
    val displayPlate: String get() = if (vehiclePlate.isNotBlank()) vehiclePlate else plate
    val displayModel: String get() = if (vehicleModel.isNotBlank()) vehicleModel else if (brand.isNotBlank()) "$brand $model" else model
    val displayClientName: String get() = if (clientName.isNotBlank()) clientName else customerName
    val displayClientPhone: String get() = if (clientPhone.isNotBlank()) clientPhone else customerPhone
    val displayTechnician: String get() = if (assignedEmployeeName.isNotBlank()) assignedEmployeeName else technicianName
}

@Entity(tableName = "service_catalog_items")
data class ServiceCatalogItem(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val code: String, // ex: "SRV-001"
    val name: String,
    val description: String,
    val benefits: String = "",
    val category: String, // Lavagem automotiva, Higienização interna, Polimento, Enceramento, Proteção de pintura, Cristalização, Outros
    val salePrice: Double,
    val costPrice: Double = 0.0,
    val isActive: Boolean = true,
    val imageUrl: String = "",
    val estimatedDurationMinutes: Int = 60,
    val requiresVehicleInspection: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class VirtualStoreOrderItem(
    val itemId: String = "",
    val itemName: String = "",
    val isService: Boolean = false,
    val quantity: Int = 1,
    val unitPrice: Double = 0.0,
    val imageUrl: String = ""
) {
    val total: Double get() = quantity * unitPrice
}

@Entity(tableName = "virtual_store_orders")
data class VirtualStoreOrder(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val orderNumber: String,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String = "",
    val customerVehiclePlate: String = "",
    val customerVehicleModel: String = "",
    val itemsSummary: String = "",
    val itemsList: List<VirtualStoreOrderItem> = emptyList(),
    val subtotal: Double = 0.0,
    val discount: Double = 0.0,
    val total: Double = 0.0,
    val status: String = "Pendente", // Pendente, Em Andamento, Concluído, Cancelado
    val isQuoteRequest: Boolean = false,
    val paymentMethod: String = "PIX",
    val paymentStatus: String = "Aguardando Pagamento", // Aguardando Pagamento, Pago, A Faturar
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val dateFormatted: String = ""
)

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey val id: String,
    val companyId: String,
    val name: String,
    val roleTitle: String = "Consultor Comercial",
    val specialty: String = "Vendas & Negociação",
    val phone: String = "(11) 98765-4321",
    val efficiencyRating: Float = 4.8f,
    val activeOrdersCount: Int = 2,
    val isAvailable: Boolean = true,
    val role: String = "Comercial",
    val department: String = "Novos"
)

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey val id: String,
    val companyId: String,
    val monthPeriod: String = "Setembro 2026",
    val targetRevenue: Double = 100000.0,
    val currentRevenue: Double = 78500.0,
    val targetServices: Int = 50,
    val currentServices: Int = 38,
    val averageTicket: Double = 2065.0,
    val title: String = "Meta Mensal Comercial",
    val targetAmount: Double = 100000.0,
    val currentAmount: Double = 78500.0,
    val month: String = "Setembro 2026"
)

enum class NotificationType {
    ALERTA, INFORMATIVO, SISTEMA, SUCESSO, ATENCAO, WARNING, INFO, ERROR, SUCCESS
}

@Entity(tableName = "notifications")
data class TayleNotification(
    @PrimaryKey val id: String,
    val companyId: String,
    val title: String,
    val message: String = "",
    val description: String = "",
    val type: NotificationType = NotificationType.ALERTA,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val category: String = "alerta"
)

enum class MaterialCategory(val label: String, val hexColor: Long) {
    VITRIFICADORES("Vitrificadores / Cerâmicos", 0xFF7C3AED),
    COMPOSTOS_POLIMENTO("Compostos Polidores", 0xFFD97706),
    QUIMICOS_LAVAGEM("Shampoos e Químicos", 0xFF0284C7),
    BOINAS_E_DISCOS("Boinas e Abrasivos", 0xFFEA580C),
    ACESSORIOS_E_MICROS("Microfibras e Pincéis", 0xFF059669),
    PROTECAO_E_EPI("EPIs e Proteção", 0xFF475569)
}

enum class UnitOfMeasure(val label: String, val symbol: String) {
    FRASCO("Frasco(s)", "fr"),
    UNIDADE("Unidade(s)", "un"),
    LITRO("Litro(s)", "L"),
    MILILITRO("Mililitro(s)", "mL"),
    QUILOGRAMA("Quilo(s)", "kg"),
    PACOTE("Pacote(s)", "pct")
}

enum class StockLevelStatus(val label: String, val hexColor: Long, val emoji: String) {
    CRITICO("Crítico", 0xFFDC2626, "🚨"),
    BAIXO("Estoque Baixo", 0xFFD97706, "⚠️"),
    NORMAL("Normal", 0xFF059669, "✅"),
    EXCESSO("Excesso", 0xFF2563EB, "📦")
}

enum class MovementType(val label: String, val isEntry: Boolean) {
    ENTRADA_COMPRA("Entrada / Compra", true),
    SAIDA_CONSUMO_OS("Saída / Uso em O.S.", false),
    AJUSTE_INVENTARIO("Ajuste de Balanço", true),
    PERDA_AVARIA("Perda ou Descarte", false),
    ENTRADA("Entrada", true),
    SAIDA("Saída", false),
    AJUSTE("Ajuste", true),
    PERDA("Perda", false)
}

enum class MaterialOrderStatus(val label: String, val hexColor: Long) {
    RASCUNHO("Rascunho", 0xFF64748B),
    SOLICITADO("Solicitado", 0xFFF59E0B),
    PENDENTE("Aguardando Cotação", 0xFFD97706),
    ENVIADO("Enviado ao Fornecedor", 0xFF00D4FF),
    APROVADO("Aprovado / Comprado", 0xFF2563EB),
    ENTREGUE("Entregue e Estocado", 0xFF059669),
    CANCELADO("Cancelado", 0xFFDC2626)
}

@Entity(tableName = "materials")
data class Material(
    @PrimaryKey val id: String,
    val companyId: String,
    val sku: String = "",
    val name: String,
    val category: String = "Geral",
    val unitOfMeasure: String = "UN",
    val currentQuantity: Double = 0.0,
    val minStock: Double = 5.0,
    val maxStock: Double = 50.0,
    val idealStock: Double = 25.0,
    val unitCost: Double = 0.0,
    val supplier: String = "",
    val location: String = "",
    val notes: String = "",
    val lastEntryDate: String = "",
    val lastExitDate: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val unit: String = "UN",
    val minQuantity: Double = 5.0
) {
    val stockLevel: StockLevelStatus
        get() = when {
            currentQuantity <= 0 -> StockLevelStatus.CRITICO
            currentQuantity <= minStock -> StockLevelStatus.BAIXO
            currentQuantity > maxStock -> StockLevelStatus.EXCESSO
            else -> StockLevelStatus.NORMAL
        }

    val totalCost: Double
        get() = currentQuantity * unitCost
}

@Entity(tableName = "material_movements")
data class MaterialMovement(
    @PrimaryKey val id: String,
    val companyId: String,
    val materialId: String,
    val materialName: String,
    val type: MovementType,
    val quantity: Double = 0.0,
    val previousQuantity: Double = 0.0,
    val newQuantity: Double = 0.0,
    val unitSymbol: String = "UN",
    val unit: String = "UN",
    val unitCost: Double = 0.0,
    val totalCost: Double = 0.0,
    val reasonOrOs: String = "",
    val reason: String = "",
    val registeredBy: String = "",
    val registeredByName: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val dateFormatted: String = ""
)

@Entity(tableName = "material_orders")
data class MaterialOrder(
    @PrimaryKey val id: String,
    val companyId: String,
    val orderNumber: String = "",
    val materialId: String,
    val materialName: String,
    val requestedQuantity: Double = 0.0,
    val quantity: Double = 0.0,
    val unitSymbol: String = "UN",
    val unit: String = "UN",
    val unitCost: Double = 0.0,
    val totalCost: Double = 0.0,
    val supplier: String = "",
    val status: MaterialOrderStatus = MaterialOrderStatus.PENDENTE,
    val requestedBy: String = "Gerência",
    val orderedByName: String = "Gerência",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val dateFormatted: String = "",
    val receivedAt: Long? = null
)

@Entity(tableName = "material_wastes")
data class MaterialWaste(
    @PrimaryKey val id: String,
    val companyId: String,
    val materialId: String,
    val materialName: String,
    val lostQuantity: Double = 0.0,
    val quantity: Double = 0.0,
    val unitSymbol: String = "UN",
    val unit: String = "UN",
    val unitCost: Double = 0.0,
    val totalCost: Double = 0.0,
    val estimatedLossCost: Double = 0.0,
    val reason: String = "Avaria",
    val responsibleEmployee: String = "Equipe",
    val responsibleName: String = "Equipe",
    val details: String = "",
    val relatedVehicle: String = "",
    val relatedService: String = "",
    val observations: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val dateFormatted: String = ""
)

// =========================================================================
// MÓDULOS COMERCIAIS OFICIAIS DA TAYLE (Conforme Especificação de Atualização)
// =========================================================================

// ITEM 10: DEPARTAMENTOS OBRIGATÓRIOS (Azul, Verde, Laranja/Âmbar)
enum class CommercialDepartment(
    val label: String,
    val colorHex: Long,
    val iconEmoji: String
) {
    POS_VENDAS("Pós-Vendas", 0xFF0284C7, "🔵"),
    NOVOS("Novos", 0xFF10B981, "🟢"),
    SEMINOVOS("Seminovos", 0xFFF59E0B, "🟠");

    companion object {
        fun fromString(value: String): CommercialDepartment = when (value.trim().uppercase()) {
            "POS_VENDAS", "PÓS-VENDAS", "POS VENDAS", "PÓS VENDAS", "POS-VENDAS", "OFICINA", "SERVICOS" -> POS_VENDAS
            "SEMINOVOS", "USADOS", "SEMI-NOVOS" -> SEMINOVOS
            else -> NOVOS
        }
    }
}

// ITEM 5: FUNIL DE VENDAS (1. Lead, 2. Contato, 3. Proposta, 4. Negociação, 5. Fechamento)
enum class FunnelStage(val step: Int, val title: String) {
    LEAD(1, "Lead"),
    CONTATO(2, "Contato"),
    PROPOSTA(3, "Proposta"),
    NEGOCIACAO(4, "Negociação"),
    FECHAMENTO(5, "Fechamento")
}

// Destaque para Oportunidades: 🔥 Quentes, 🟡 Negociação, 🔴 Paradas
enum class OpportunityTemperature(val label: String, val emoji: String, val colorHex: Long) {
    QUENTE("Oportunidade Quente", "🔥", 0xFFEF4444),
    NEGOCIANDO("Em Negociação", "🟡", 0xFFF59E0B),
    PARADA("Oportunidade Parada", "🔴", 0xFFDC2626)
}

@Entity(tableName = "sales_opportunities")
data class SalesOpportunity(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val clientName: String,
    val clientPhone: String,
    val title: String,
    val potentialValue: Double,
    val stage: FunnelStage,
    val temperature: OpportunityTemperature,
    val daysInStage: Int = 1,
    val department: CommercialDepartment = CommercialDepartment.NOVOS,
    val sellerName: String = "Carlos Vendas",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

// ITEM 6, 7, 8: PRODUTOS E SERVIÇOS & NOVO DESIGN DE ESTOQUE
enum class ItemType(val label: String) {
    PRODUTO("Produto"),
    SERVICO("Serviço")
}

// ITEM 7 e 8: Bolinha de status 🟢🟡🔴 + texto + Reposição Necessária
enum class StockHealth(val label: String, val symbol: String, val colorHex: Long) {
    NORMAL("Estoque Cheio / Normal", "🟢", 0xFF10B981),
    MEDIO("Estoque Médio / Atenção", "🟡", 0xFFF59E0B),
    LIMITE("Estoque no Limite / Reposição", "🔴", 0xFFEF4444),
    ESGOTADO("Esgotado / Reposição Necessária", "🔴", 0xFFDC2626)
}

@Entity(tableName = "commercial_products")
data class CommercialProduct(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val name: String,
    val itemType: ItemType = ItemType.PRODUTO,
    val category: String,
    val sku: String,
    val salePrice: Double,
    val costPrice: Double,
    val stockCurrent: Int,
    val stockMin: Int,
    val stockIdeal: Int,
    val stockMax: Int,
    val department: CommercialDepartment,
    val supplier: String = "",
    val salesCount: Int = 0,
    val revenueGenerated: Double = 0.0,
    val photoUrl: String = "",
    val description: String = "",
    val isPromotional: Boolean = false,
    val promoPrice: Double = 0.0,
    val code: String = "",
    val isActive: Boolean = true,
    val isAvailableForVirtualStore: Boolean = true
) {
    // Lucro = Faturamento/Preço - Custo (NUNCA misturar custo com lucro)
    val activePrice: Double get() = if (isPromotional && promoPrice > 0) promoPrice else salePrice
    val profit: Double get() = activePrice - costPrice
    val profitMarginPercent: Double get() = if (activePrice > 0) (profit / activePrice) * 100.0 else 0.0

    // Regras de Estoque:
    // 🟢 NORMAL: acima do nível de atenção (> stockMin e >= stockIdeal)
    // 🟡 MÉDIO: próximo do mínimo (entre stockMin e stockIdeal)
    // 🔴 LIMITE: igual ou abaixo do mínimo (<= stockMin)
    // Se estoque = 0: 🔴 ESGOTADO ("Reposição necessária")
    val stockHealth: StockHealth
        get() {
            if (itemType == ItemType.SERVICO) return StockHealth.NORMAL
            return when {
                stockCurrent <= 0 -> StockHealth.ESGOTADO
                stockCurrent <= stockMin -> StockHealth.LIMITE
                stockCurrent < stockIdeal -> StockHealth.MEDIO
                else -> StockHealth.NORMAL
            }
        }
}

// ITEM 9: ENTRADA E SAÍDA DE ESTOQUE (➕ Entrada / ➖ Saída)
@Entity(tableName = "stock_movements")
data class StockMovement(
    @PrimaryKey val id: String,
    val companyId: String,
    val productId: String,
    val productName: String,
    val isEntry: Boolean, // true = Entrada (+), false = Saída (-)
    val quantity: Int,
    val dateFormatted: String,
    val timeFormatted: String,
    val responsibleName: String,
    val department: CommercialDepartment,
    val reason: String,
    val previousStock: Int,
    val newStock: Int,
    val timestamp: Long = System.currentTimeMillis()
)

// ITEM 1, 2, 3, 4, 10, 11: VENDAS REAIS (Diárias, Mensais, Deptos, Custo vs Lucro)
@Entity(tableName = "commercial_sales")
data class CommercialSale(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val branchName: String = "Matriz São Paulo",
    val userId: String = "usr_admin",
    val departmentId: String = "POS_VENDAS",
    val dateFormatted: String, // ex: "05/09/2026"
    val monthPeriod: String,   // ex: "09/2026" ou "Setembro 2026"
    val clientName: String,
    val sellerName: String,
    val department: CommercialDepartment,
    val productName: String,
    val quantity: Int = 1,
    val salePrice: Double,
    val costPrice: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val branch: String = "Matriz Principal"
) {
    val revenue: Double get() = salePrice * quantity
    val totalCost: Double get() = costPrice * quantity
    val profit: Double get() = revenue - totalCost
    val profitMarginPercent: Double get() = if (revenue > 0) (profit / revenue) * 100.0 else 0.0
}

// ITEM 19: RECUPERAÇÃO DE VENDA PERDIDA
enum class LossReason(val label: String) {
    PRECO("Preço"),
    PRAZO("Prazo"),
    CONCORRENCIA("Concorrência"),
    CLIENTE_DESISTIU("Cliente desistiu"),
    SEM_RETORNO("Sem retorno"),
    ORCAMENTO("Orçamento"),
    CONDICAO_PAGAMENTO("Condição de pagamento"),
    OUTRO("Outro")
}

@Entity(tableName = "lost_sales")
data class LostSale(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val clientName: String,
    val clientPhone: String,
    val productOrService: String,
    val value: Double,
    val reason: LossReason,
    val sellerName: String,
    val dateFormatted: String,
    val observations: String = "",
    val isRecovered: Boolean = false,
    val recoveryStrategy: String = "",
    val recoveryMessage: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

// ITEM 17 & 18: AGENDA DIÁRIA DE VENDAS (🌅 Início, ☀️ Durante, 🌆 Final)
enum class AgendaDayPeriod(val title: String, val emoji: String) {
    INICIO_DO_DIA("Início do Dia", "🌅"),
    DURANTE_O_DIA("Durante o Dia", "☀️"),
    FINAL_DO_DIA("Final do Dia", "🌆")
}

@Entity(tableName = "daily_agenda")
data class DailyAgendaTask(
    @PrimaryKey val id: String,
    val companyId: String,
    val branchId: String = "branch_sp_matriz",
    val sellerName: String,
    val period: AgendaDayPeriod,
    val title: String,
    val clientName: String,
    val clientPhone: String,
    val targetAction: String,
    val isCompleted: Boolean = false,
    val isHotOpportunity: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

enum class ModuleAccess(val displayName: String) {
    DASHBOARD("Dashboard"),
    CLIENTES("Clientes"),
    VENDAS("Vendas"),
    FATURAMENTO("Faturamento"),
    ESTOQUE("Estoque"),
    VEICULOS("Veículos e Pátio"),
    ORDENS_SERVICO("Ordens de Serviço"),
    RELATORIOS("Relatórios"),
    MARKETING("Marketing"),
    TAYLE_IA("TAYLE IA"),
    METAS("Metas"),
    AGENDA("Agenda"),
    CONFIGURACOES("Configurações")
}

