package com.example.data.version

import android.content.Context
import android.content.Intent
import android.net.Uri

data class ReleaseInfo(
    val versionName: String,
    val versionCode: Int,
    val releaseDate: String,
    val highlights: List<String>,
    val isCurrentInstalled: Boolean = false
)

data class AppUpdateCheckResult(
    val currentVersionName: String = AppVersionManager.CURRENT_VERSION_NAME,
    val currentVersionCode: Int = AppVersionManager.CURRENT_VERSION_CODE,
    val latestVersionName: String = "1.1.0",
    val latestVersionCode: Int = 2,
    val releaseNotes: List<String> = listOf(
        "Novo controle de estoque",
        "Melhorias no faturamento",
        "Novos filtros",
        "Correções de desempenho"
    ),
    val isUpdateAvailable: Boolean = false,
    val isMandatory: Boolean = false,
    val storeUrl: String = "https://play.google.com/store/apps/details?id=com.aistudio.tayle.auto"
)

object AppVersionManager {
    const val APPLICATION_ID = "com.aistudio.tayle.auto"
    const val APP_NAME = "TAYLE"
    const val CURRENT_VERSION_CODE = 1
    const val CURRENT_VERSION_NAME = "1.0.0"

    val VERSION_HISTORY: List<ReleaseInfo> = listOf(
        ReleaseInfo(
            versionName = CURRENT_VERSION_NAME,
            versionCode = 1,
            releaseDate = "Agosto 2026",
            highlights = listOf(
                "Lançamento inicial do TAYLE na Google Play Store",
                "Gestão Multi-Tenant de Estética Automotiva",
                "Departamentos: Pós-Vendas, Novos (0km) e Seminovos",
                "Ordens de Serviço, Pátio e Checklist",
                "Assistente TAYLE IA para orçamentos e follow-up",
                "Banco de dados local seguro Room v4"
            ),
            isCurrentInstalled = true
        ),
        ReleaseInfo(
            versionName = "1.1.0",
            versionCode = 2,
            releaseDate = "Planejada (Próxima)",
            highlights = listOf(
                "Novo controle de estoque de insumos e produtos",
                "Melhorias no faturamento e conciliação financeira",
                "Novos filtros por departamento e data",
                "Otimizações de desempenho e carregamento offline"
            ),
            isCurrentInstalled = false
        )
    )

    fun getAvailableUpdatePreview(): AppUpdateCheckResult {
        return AppUpdateCheckResult(
            currentVersionName = CURRENT_VERSION_NAME,
            currentVersionCode = 1,
            latestVersionName = "1.1.0",
            latestVersionCode = 2,
            releaseNotes = listOf(
                "Novo controle de estoque",
                "Melhorias no faturamento",
                "Novos filtros",
                "Correções de desempenho"
            ),
            isUpdateAvailable = true,
            isMandatory = false,
            storeUrl = "https://play.google.com/store/apps/details?id=com.aistudio.tayle.auto"
        )
    }

    fun openPlayStore(context: Context) {
        val playStoreUri = Uri.parse("market://details?id=com.aistudio.tayle.auto")
        val webUri = Uri.parse("https://play.google.com/store/apps/details?id=com.aistudio.tayle.auto")
        val playStoreIntent = Intent(Intent.ACTION_VIEW, playStoreUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(playStoreIntent)
        } catch (_: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(webIntent)
            } catch (_: Exception) {
            }
        }
    }
}
