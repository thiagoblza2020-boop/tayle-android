package com.example.data.model

enum class UserRole(
    val title: String,
    val description: String,
    val level: Int
) {
    ADMINISTRADOR("Administrador", "Acesso total à empresa, configurações e faturamento", 4),
    GERENTE("Gerente", "Gestão de equipe, metas, relatórios e CRM", 3),
    SUPERVISOR("Supervisor", "Supervisão do pátio, O.S., checklist e produção", 2),
    OPERADOR("Operador", "Execução de serviços e atualização de status de O.S.", 1);

    val label: String get() = title

    fun canManageCompany(): Boolean = this == ADMINISTRADOR
    fun canViewFinancials(): Boolean = this == ADMINISTRADOR || this == GERENTE
    fun canManageTeam(): Boolean = this == ADMINISTRADOR || this == GERENTE
    fun canCreateAndEditOS(): Boolean = this != OPERADOR
    fun canUpdateOSStatus(): Boolean = true
    fun canAccessAIStudio(): Boolean = true
    fun canManageSettings(): Boolean = this == ADMINISTRADOR
}
