package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.Department
import com.example.data.model.MaterialCategory
import com.example.data.model.MaterialOrderStatus
import com.example.data.model.MovementType
import com.example.data.model.OsPriority
import com.example.data.model.OsStatus
import com.example.data.model.UnitOfMeasure
import com.example.data.model.UserRole
import com.example.data.model.VehicleStatus

class Converters {
    @TypeConverter
    fun fromDepartment(department: Department): String = department.name

    @TypeConverter
    fun toDepartment(value: String): Department = runCatching { Department.valueOf(value) }.getOrDefault(Department.ENTRADA)

    @TypeConverter
    fun fromUserRole(role: UserRole): String = role.name

    @TypeConverter
    fun toUserRole(value: String): UserRole = runCatching { UserRole.valueOf(value) }.getOrDefault(UserRole.ADMINISTRADOR)

    @TypeConverter
    fun fromVehicleStatus(status: VehicleStatus): String = status.name

    @TypeConverter
    fun toVehicleStatus(value: String): VehicleStatus = runCatching { VehicleStatus.valueOf(value) }.getOrDefault(VehicleStatus.AGUARDANDO)

    @TypeConverter
    fun fromOsStatus(status: OsStatus): String = status.name

    @TypeConverter
    fun toOsStatus(value: String): OsStatus = runCatching { OsStatus.valueOf(value) }.getOrDefault(OsStatus.EM_EXECUCAO)

    @TypeConverter
    fun fromOsPriority(priority: OsPriority): String = priority.name

    @TypeConverter
    fun toOsPriority(value: String): OsPriority = runCatching { OsPriority.valueOf(value) }.getOrDefault(OsPriority.NORMAL)

    @TypeConverter
    fun fromMaterialCategory(category: MaterialCategory): String = category.name

    @TypeConverter
    fun toMaterialCategory(value: String): MaterialCategory = runCatching { MaterialCategory.valueOf(value) }.getOrDefault(MaterialCategory.COMPOSTOS_POLIMENTO)

    @TypeConverter
    fun fromUnitOfMeasure(unit: UnitOfMeasure): String = unit.name

    @TypeConverter
    fun toUnitOfMeasure(value: String): UnitOfMeasure = runCatching { UnitOfMeasure.valueOf(value) }.getOrDefault(UnitOfMeasure.UNIDADE)

    @TypeConverter
    fun fromMovementType(type: MovementType): String = type.name

    @TypeConverter
    fun toMovementType(value: String): MovementType = runCatching { MovementType.valueOf(value) }.getOrDefault(MovementType.ENTRADA_COMPRA)

    @TypeConverter
    fun fromMaterialOrderStatus(status: MaterialOrderStatus): String = status.name

    @TypeConverter
    fun toMaterialOrderStatus(value: String): MaterialOrderStatus = runCatching { MaterialOrderStatus.valueOf(value) }.getOrDefault(MaterialOrderStatus.PENDENTE)

    @TypeConverter
    fun fromCommercialDepartment(dept: com.example.data.model.CommercialDepartment): String = dept.name

    @TypeConverter
    fun toCommercialDepartment(value: String): com.example.data.model.CommercialDepartment = runCatching { com.example.data.model.CommercialDepartment.valueOf(value) }.getOrDefault(com.example.data.model.CommercialDepartment.NOVOS)

    @TypeConverter
    fun fromFunnelStage(stage: com.example.data.model.FunnelStage): String = stage.name

    @TypeConverter
    fun toFunnelStage(value: String): com.example.data.model.FunnelStage = runCatching { com.example.data.model.FunnelStage.valueOf(value) }.getOrDefault(com.example.data.model.FunnelStage.LEAD)

    @TypeConverter
    fun fromOpportunityTemperature(temp: com.example.data.model.OpportunityTemperature): String = temp.name

    @TypeConverter
    fun toOpportunityTemperature(value: String): com.example.data.model.OpportunityTemperature = runCatching { com.example.data.model.OpportunityTemperature.valueOf(value) }.getOrDefault(com.example.data.model.OpportunityTemperature.NEGOCIANDO)

    @TypeConverter
    fun fromItemType(type: com.example.data.model.ItemType): String = type.name

    @TypeConverter
    fun toItemType(value: String): com.example.data.model.ItemType = runCatching { com.example.data.model.ItemType.valueOf(value) }.getOrDefault(com.example.data.model.ItemType.PRODUTO)

    @TypeConverter
    fun fromLossReason(reason: com.example.data.model.LossReason): String = reason.name

    @TypeConverter
    fun toLossReason(value: String): com.example.data.model.LossReason = runCatching { com.example.data.model.LossReason.valueOf(value) }.getOrDefault(com.example.data.model.LossReason.OUTRO)

    @TypeConverter
    fun fromAgendaDayPeriod(period: com.example.data.model.AgendaDayPeriod): String = period.name

    @TypeConverter
    fun toAgendaDayPeriod(value: String): com.example.data.model.AgendaDayPeriod = runCatching { com.example.data.model.AgendaDayPeriod.valueOf(value) }.getOrDefault(com.example.data.model.AgendaDayPeriod.INICIO_DO_DIA)

    @TypeConverter
    fun fromNotificationType(type: com.example.data.model.NotificationType): String = type.name

    @TypeConverter
    fun toNotificationType(value: String): com.example.data.model.NotificationType = runCatching { com.example.data.model.NotificationType.valueOf(value) }.getOrDefault(com.example.data.model.NotificationType.ALERTA)

    @TypeConverter
    fun fromStringList(list: List<String>): String = list.joinToString("|||")

    @TypeConverter
    fun toStringList(value: String): List<String> = if (value.isBlank()) emptyList() else value.split("|||")

    @TypeConverter
    fun fromChecklist(list: List<com.example.data.model.ChecklistItem>): String =
        list.joinToString(";;;") { "${it.title}:::${it.isDone}" }

    @TypeConverter
    fun toChecklist(value: String): List<com.example.data.model.ChecklistItem> =
        if (value.isBlank()) emptyList()
        else value.split(";;;").mapNotNull { itemStr ->
            val parts = itemStr.split(":::")
            if (parts.isNotEmpty()) com.example.data.model.ChecklistItem(parts[0], parts.getOrNull(1)?.toBooleanStrictOrNull() ?: false) else null
        }

    @TypeConverter
    fun fromServiceOrderItems(items: List<com.example.data.model.ServiceOrderItem>): String =
        items.joinToString(";;;") { "${it.serviceId}:::${it.serviceName}:::${it.description}:::${it.quantity}:::${it.unitPrice}:::${it.discount}" }

    @TypeConverter
    fun toServiceOrderItems(value: String): List<com.example.data.model.ServiceOrderItem> =
        if (value.isBlank()) emptyList()
        else value.split(";;;").mapNotNull { itemStr ->
            val parts = itemStr.split(":::")
            if (parts.size >= 5) {
                com.example.data.model.ServiceOrderItem(
                    serviceId = parts[0],
                    serviceName = parts[1],
                    description = parts.getOrElse(2) { "" },
                    quantity = parts.getOrNull(3)?.toIntOrNull() ?: 1,
                    unitPrice = parts.getOrNull(4)?.toDoubleOrNull() ?: 0.0,
                    discount = parts.getOrNull(5)?.toDoubleOrNull() ?: 0.0
                )
            } else null
        }

    @TypeConverter
    fun fromVirtualStoreOrderItems(items: List<com.example.data.model.VirtualStoreOrderItem>): String =
        items.joinToString(";;;") { "${it.itemId}:::${it.itemName}:::${it.isService}:::${it.quantity}:::${it.unitPrice}:::${it.imageUrl}" }

    @TypeConverter
    fun toVirtualStoreOrderItems(value: String): List<com.example.data.model.VirtualStoreOrderItem> =
        if (value.isBlank()) emptyList()
        else value.split(";;;").mapNotNull { itemStr ->
            val parts = itemStr.split(":::")
            if (parts.size >= 5) {
                com.example.data.model.VirtualStoreOrderItem(
                    itemId = parts[0],
                    itemName = parts[1],
                    isService = parts.getOrNull(2)?.toBooleanStrictOrNull() ?: false,
                    quantity = parts.getOrNull(3)?.toIntOrNull() ?: 1,
                    unitPrice = parts.getOrNull(4)?.toDoubleOrNull() ?: 0.0,
                    imageUrl = parts.getOrElse(5) { "" }
                )
            } else null
        }
}
