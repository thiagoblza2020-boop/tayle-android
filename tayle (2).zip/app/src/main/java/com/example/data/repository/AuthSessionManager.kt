package com.example.data.repository

import com.example.data.model.Company
import com.example.data.model.User
import com.example.data.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class AuthSessionManager(private val repository: TayleRepository) {

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _currentCompany = MutableStateFlow<Company?>(null)
    val currentCompany: StateFlow<Company?> = _currentCompany.asStateFlow()

    suspend fun login(email: String, password: String): Result<User> {
        val cleanEmail = email.trim().lowercase(Locale.ROOT)
        val user = repository.getUserByEmail(cleanEmail)
        return if (user != null && (password.isEmpty() || user.password == password)) {
            _currentUser.value = user
            val company = repository.getCompanyById(user.companyId)
            _currentCompany.value = company
            Result.success(user)
        } else {
            Result.failure(Exception("Credenciais inválidas. Verifique seu e-mail e senha."))
        }
    }

    suspend fun login(email: String, desiredRole: UserRole = UserRole.ADMINISTRADOR): Result<User> {
        val cleanEmail = email.trim().lowercase(Locale.ROOT)
        var user = repository.getUserByEmail(cleanEmail)
        if (user == null) {
            user = User(
                id = "usr_${System.currentTimeMillis()}",
                companyId = "comp_matriz",
                name = email.substringBefore("@").replaceFirstChar { it.uppercase() },
                email = cleanEmail,
                password = "",
                role = desiredRole,
                roleTitle = desiredRole.title
            )
            repository.insertUser(user)
        } else if (user.role != desiredRole) {
            user = user.copy(role = desiredRole, roleTitle = desiredRole.title)
        }
        _currentUser.value = user
        val company = repository.getCompanyById(user.companyId)
        _currentCompany.value = company
        return Result.success(user)
    }

    fun setLoggedInUserDirectly(user: User, company: Company?) {
        _currentUser.value = user
        _currentCompany.value = company
    }

    fun switchRoleForDemo(newRole: UserRole) {
        val current = _currentUser.value ?: return
        val updated = current.copy(
            role = newRole,
            roleTitle = newRole.title
        )
        _currentUser.value = updated
    }

    fun switchCompanyForDemo(newCompany: Company, usersInCompany: List<User> = emptyList()) {
        _currentCompany.value = newCompany
        val userInCompany = usersInCompany.firstOrNull { it.companyId == newCompany.id }
            ?: User(
                id = "usr_${System.currentTimeMillis()}",
                companyId = newCompany.id,
                name = "Gestor ${newCompany.tradeName}",
                email = "gestor@${newCompany.name.take(5).lowercase(Locale.ROOT)}.com",
                password = "",
                role = UserRole.ADMINISTRADOR,
                roleTitle = "Administrador Master"
            )
        _currentUser.value = userInCompany
    }

    fun logout() {
        _currentUser.value = null
        _currentCompany.value = null
    }
}
