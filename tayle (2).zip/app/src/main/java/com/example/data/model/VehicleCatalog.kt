package com.example.data.model

data class VehicleBrand(
    val id: String,
    val name: String,
    val origin: String,
    val popularModels: List<String>
) {
    val models: List<String> get() = popularModels
}

object VehicleCatalog {
    val brands: List<VehicleBrand> get() = BRANDS
    val BRANDS: List<VehicleBrand> = listOf(
        VehicleBrand(
            "toyota", "Toyota", "Japão",
            listOf("Corolla", "Corolla Cross", "Hilux", "SW4", "Yaris Hatch", "Yaris Sedan", "RAV4", "Etios", "Etios Sedan", "Camry", "Prius", "Land Cruiser Prado")
        ),
        VehicleBrand(
            "volkswagen", "Volkswagen", "Alemanha",
            listOf("Polo", "Polo Track", "Nivus", "T-Cross", "Taos", "Tiguan Allspace", "Virtus", "Saveiro", "Amarok", "Gol", "Voyage", "Fox", "Jetta", "Passat", "Golf", "Up!")
        ),
        VehicleBrand(
            "chevrolet", "Chevrolet", "EUA",
            listOf("Onix", "Onix Plus", "Tracker", "S10", "Montana", "Spin", "Cruze", "Cruze Sport6", "Equinox", "Trailblazer", "Silverado", "Camaro", "Cobalt", "Prisma", "Celta", "Astra", "Vectra")
        ),
        VehicleBrand(
            "fiat", "Fiat", "Itália",
            listOf("Strada", "Toro", "Argo", "Cronos", "Mobi", "Pulse", "Pulse Abarth", "Fastback", "Fastback Abarth", "Fiorino", "Titano", "500", "500e", "Ducato", "Uno", "Palio", "Siena", "Grand Siena", "Punto", "Bravo")
        ),
        VehicleBrand(
            "honda", "Honda", "Japão",
            listOf("Civic", "Civic Type R", "City Hatch", "City Sedan", "HR-V", "ZR-V", "CR-V", "Accord Hybrid", "Fit", "WR-V")
        ),
        VehicleBrand(
            "hyundai", "Hyundai", "Coreia do Sul",
            listOf("HB20", "HB20S", "Creta", "Creta N Line", "Tucson", "Santa Fe", "Palisade", "Ioniq 5", "Kona", "Kona EV", "Elantra", "Azera", "i30", "IX35", "HR")
        ),
        VehicleBrand(
            "jeep", "Jeep", "EUA",
            listOf("Renegade", "Compass", "Commander", "Wrangler Rubicon", "Gladiator", "Grand Cherokee 4xe", "Cherokee")
        ),
        VehicleBrand(
            "byd", "BYD", "China",
            listOf("Dolphin", "Dolphin Mini", "Dolphin Plus", "Song Plus DM-i", "Seal", "Yuan Plus EV", "Yuan Pro", "Han EV", "Tan EV", "King DM-i", "Shark")
        ),
        VehicleBrand(
            "gwm", "GWM", "China",
            listOf("Haval H6 HEV", "Haval H6 PHEV", "Haval H6 GT", "Ora 03 Skin", "Ora 03 GT", "Tank 300", "Poer")
        ),
        VehicleBrand(
            "bmw", "BMW", "Alemanha",
            listOf("Série 3 (320i)", "330e M Sport", "M3 Competition", "Série 1 (118i)", "Série 2 Gran Coupé", "Série 4 (420i / M4)", "Série 5 (530e / M5)", "X1", "X2", "X3", "X4", "X5", "X6", "X7", "iX1", "iX3", "iX", "i4", "i7", "Z4 Roadster")
        ),
        VehicleBrand(
            "mercedes", "Mercedes-Benz", "Alemanha",
            listOf("Classe A 200", "Classe C (C 200 / C 300)", "Classe E (E 300)", "Classe S", "GLA 200", "GLB 200", "GLC 300", "GLE 450", "GLS", "CLA 250", "Mercedes-AMG C 63", "Mercedes-AMG A 45", "Mercedes-AMG G 63", "EQA", "EQB", "EQE", "EQS")
        ),
        VehicleBrand(
            "audi", "Audi", "Alemanha",
            listOf("A3 Sedan", "A3 Sportback", "A4 Sedan", "A5 Sportback", "A6", "A7", "A8", "Q3", "Q3 Sportback", "Q5", "Q5 Sportback", "Q7", "Q8", "Q8 e-tron", "e-tron GT", "RS3", "RS5", "RS6 Avant", "RS Q8", "TT")
        ),
        VehicleBrand(
            "porsche", "Porsche", "Alemanha",
            listOf("911 Carrera", "911 Carrera S", "911 GTS", "911 Turbo S", "911 GT3", "Cayenne", "Cayenne Coupé", "Cayenne E-Hybrid", "Macan", "Macan EV", "Panamera", "Panamera 4 E-Hybrid", "Taycan", "Taycan Cross Turismo", "718 Cayman", "718 Boxster")
        ),
        VehicleBrand(
            "volvo", "Volvo", "Suécia",
            listOf("XC40 Recharge", "C40 Recharge", "XC60 Recharge", "XC90 Recharge", "EX30", "EX90", "S60", "V60")
        ),
        VehicleBrand(
            "ford", "Ford", "EUA",
            listOf("Ranger", "Ranger Raptor", "Maverick Hybrid", "Maverick FX4", "Bronco Sport", "Territory", "Mustang GT", "Mustang Mach-E", "F-150", "Transit", "Ka", "EcoSport", "Fusion", "Focus")
        ),
        VehicleBrand(
            "renault", "Renault", "França",
            listOf("Kwid", "Kwid E-Tech", "Kardian", "Duster", "Duster Oroch", "Oroch", "Megane E-Tech", "Master", "Sandero", "Logan", "Captur", "Fluence", "Clio")
        ),
        VehicleBrand(
            "nissan", "Nissan", "Japão",
            listOf("Kicks", "Versa", "Sentra", "Frontier", "Leaf", "March", "Tiida", "Livina", "GT-R")
        ),
        VehicleBrand(
            "land_rover", "Land Rover", "Reino Unido",
            listOf("Range Rover Evoque", "Range Rover Velar", "Range Rover Sport", "Range Rover Vogue", "Defender 90", "Defender 110", "Defender 130", "Discovery", "Discovery Sport")
        ),
        VehicleBrand(
            "ram", "RAM", "EUA",
            listOf("Rampage Rebel", "Rampage Laramie", "Rampage R/T", "1500 Rebel", "1500 Limited", "2500 Laramie", "3500 Longhorn", "Classic")
        ),
        VehicleBrand(
            "mitsubishi", "Mitsubishi", "Japão",
            listOf("L200 Triton Sport", "L200 Triton Savana", "Pajero Sport", "Eclipse Cross", "Outlander", "ASX", "Lancer")
        ),
        VehicleBrand(
            "peugeot", "Peugeot", "França",
            listOf("208", "e-208 GT", "2008", "e-2008", "3008", "Expert", "Partner", "207", "308", "408")
        ),
        VehicleBrand(
            "citroen", "Citroën", "França",
            listOf("C3", "C3 Aircross", "C4 Cactus", "Basalt", "Jumpy", "C4 Lounge", "C3 Picasso", "Aircross")
        ),
        VehicleBrand(
            "caoa_chery", "Caoa Chery", "China",
            listOf("Tiggo 5X Sport", "Tiggo 5X Pro Hybrid", "Tiggo 7 Pro Max Drive", "Tiggo 8 Pro Plug-in Hybrid", "Arrizo 6 Pro Hybrid", "iCar", "Tiggo 2", "Tiggo 3X")
        ),
        VehicleBrand(
            "kia", "Kia", "Coreia do Sul",
            listOf("Sportage Hybrid", "Seltos", "Niro Hybrid", "Carnival", "Stonic Hybrid", "EV6", "Cerato", "Sorento", "Soul", "Picanto", "Bongo")
        ),
        VehicleBrand(
            "mini", "Mini", "Reino Unido",
            listOf("Cooper 3 Portas", "Cooper 5 Portas", "Cooper S", "Countryman", "Countryman SE ALL4", "Aceman", "John Cooper Works (JCW)")
        ),
        VehicleBrand(
            "lexus", "Lexus", "Japão",
            listOf("NX 350h", "RX 500h", "UX 250h", "ES 300h", "LS 500h", "LC 500")
        ),
        VehicleBrand(
            "subaru", "Subaru", "Japão",
            listOf("Forester e-Boxer", "Outback", "XV / Crosstrek", "WRX", "WRX STI", "Impreza")
        ),
        VehicleBrand(
            "suzuki", "Suzuki", "Japão",
            listOf("Jimny Sierra", "Jimny", "Vitara", "S-Cross", "Grand Vitara", "Swift")
        ),
        VehicleBrand(
            "ferrari", "Ferrari", "Itália",
            listOf("296 GTB", "296 GTS", "SF90 Stradale", "Roma", "Roma Spider", "Purosangue", "F8 Tributo", "F8 Spider", "812 Superfast", "488 GTB", "458 Italia")
        ),
        VehicleBrand(
            "lamborghini", "Lamborghini", "Itália",
            listOf("Urus", "Urus Performante", "Huracán EVO", "Huracán Tecnica", "Huracán STO", "Revuelto", "Aventador SVJ")
        ),
        VehicleBrand(
            "outra", "Outra Marca", "Diversos",
            listOf("Personalizado / Outro Modelo")
        )
    )

    fun getBrandByName(brandName: String): VehicleBrand? {
        val clean = brandName.trim()
        return BRANDS.firstOrNull { it.name.equals(clean, ignoreCase = true) }
    }

    fun getModelsForBrand(brandName: String): List<String> {
        return getBrandByName(brandName)?.popularModels ?: emptyList()
    }

    fun isModelValidForBrand(brandName: String, modelName: String): Boolean {
        if (brandName.isBlank() || modelName.isBlank()) return false
        val brand = getBrandByName(brandName) ?: return true
        if (brand.id == "outra") return true
        return brand.popularModels.any { it.equals(modelName.trim(), ignoreCase = true) }
    }
}
