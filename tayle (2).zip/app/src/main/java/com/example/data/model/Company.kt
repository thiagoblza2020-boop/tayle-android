package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "companies")
data class Company(
    @PrimaryKey val id: String,
    val name: String,
    val tradeName: String = "",
    val cnpj: String = "",
    val plan: String = "Master R$ 99,90",
    val maxUsers: Int = 20,
    val activeDealershipBranch: String = "Matriz Principal",
    val phone: String = "(11) 98844-2200",
    val email: String = "contato@tayle.com.br",
    val address: String = "Av. das Nações Unidas, 12900 - SP",
    val document: String = "",
    val segment: String = "Concessionária & Serviços Automotivos",
    val branchesCount: Int = 3,
    val matrixAddress: String = "Av. das Nações Unidas, 12900 - SP",
    val createdAt: Long = System.currentTimeMillis()
)
