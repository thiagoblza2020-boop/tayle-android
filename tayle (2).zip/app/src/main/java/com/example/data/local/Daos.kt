package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Branch
import com.example.data.model.Company
import com.example.data.model.Employee
import com.example.data.model.Goal
import com.example.data.model.Material
import com.example.data.model.MaterialMovement
import com.example.data.model.MaterialOrder
import com.example.data.model.MaterialWaste
import com.example.data.model.ServiceOrder
import com.example.data.model.TayleNotification
import com.example.data.model.User
import com.example.data.model.Vehicle
import com.example.data.model.CommercialProduct
import com.example.data.model.CommercialSale
import com.example.data.model.DailyAgendaTask
import com.example.data.model.LostSale
import com.example.data.model.SalesOpportunity
import com.example.data.model.StockMovement
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM companies ORDER BY name ASC")
    fun getAllCompanies(): Flow<List<Company>>

    @Query("SELECT * FROM companies WHERE id = :id LIMIT 1")
    suspend fun getCompanyById(id: String): Company?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompany(company: Company)

    @Update
    suspend fun updateCompany(company: Company)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE companyId = :companyId")
    fun getUsersByCompany(companyId: String): Flow<List<User>>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): User?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUserCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Update
    suspend fun updateUser(user: User)
}

@Dao
interface VehicleDao {
    @Query("SELECT * FROM vehicles WHERE companyId = :companyId ORDER BY entryDate DESC")
    fun getVehiclesByCompany(companyId: String): Flow<List<Vehicle>>

    @Query("SELECT * FROM vehicles WHERE id = :id LIMIT 1")
    suspend fun getVehicleById(id: String): Vehicle?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVehicle(vehicle: Vehicle)

    @Update
    suspend fun updateVehicle(vehicle: Vehicle)

    @Query("DELETE FROM vehicles WHERE id = :id")
    suspend fun deleteVehicleById(id: String)
}

@Dao
interface ServiceOrderDao {
    @Query("SELECT * FROM service_orders WHERE companyId = :companyId ORDER BY createdAt DESC")
    fun getOrdersByCompany(companyId: String): Flow<List<ServiceOrder>>

    @Query("SELECT * FROM service_orders WHERE id = :id LIMIT 1")
    suspend fun getOrderById(id: String): ServiceOrder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: ServiceOrder)

    @Update
    suspend fun updateOrder(order: ServiceOrder)

    @Query("DELETE FROM service_orders WHERE id = :id")
    suspend fun deleteOrderById(id: String)
}

@Dao
interface EmployeeDao {
    @Query("SELECT * FROM employees WHERE companyId = :companyId")
    fun getEmployeesByCompany(companyId: String): Flow<List<Employee>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: Employee)

    @Update
    suspend fun updateEmployee(employee: Employee)
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals WHERE companyId = :companyId LIMIT 1")
    fun getGoalByCompany(companyId: String): Flow<Goal?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: Goal)

    @Update
    suspend fun updateGoal(goal: Goal)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getNotificationsByCompany(companyId: String): Flow<List<TayleNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: TayleNotification)

    @Query("UPDATE notifications SET isRead = 1 WHERE companyId = :companyId")
    suspend fun markAllAsRead(companyId: String)
}

@Dao
interface MaterialDao {
    @Query("SELECT * FROM materials WHERE companyId = :companyId ORDER BY name ASC")
    fun getMaterialsByCompany(companyId: String): Flow<List<Material>>

    @Query("SELECT * FROM materials WHERE id = :id LIMIT 1")
    suspend fun getMaterialById(id: String): Material?

    @Query("SELECT * FROM materials WHERE companyId = :companyId AND currentQuantity <= minStock")
    fun getLowStockMaterials(companyId: String): Flow<List<Material>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMaterial(material: Material)

    @Update
    suspend fun updateMaterial(material: Material)

    @Query("DELETE FROM materials WHERE id = :id")
    suspend fun deleteMaterialById(id: String)
}

@Dao
interface MaterialMovementDao {
    @Query("SELECT * FROM material_movements WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getMovementsByCompany(companyId: String): Flow<List<MaterialMovement>>

    @Query("SELECT * FROM material_movements WHERE materialId = :materialId ORDER BY timestamp DESC")
    fun getMovementsByMaterial(materialId: String): Flow<List<MaterialMovement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovement(movement: MaterialMovement)
}

@Dao
interface MaterialOrderDao {
    @Query("SELECT * FROM material_orders WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getOrdersByCompany(companyId: String): Flow<List<MaterialOrder>>

    @Query("SELECT * FROM material_orders WHERE id = :id LIMIT 1")
    suspend fun getOrderById(id: String): MaterialOrder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: MaterialOrder)

    @Update
    suspend fun updateOrder(order: MaterialOrder)

    @Query("DELETE FROM material_orders WHERE id = :id")
    suspend fun deleteOrderById(id: String)
}

@Dao
interface MaterialWasteDao {
    @Query("SELECT * FROM material_wastes WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getWastesByCompany(companyId: String): Flow<List<MaterialWaste>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWaste(waste: MaterialWaste)

    @Query("DELETE FROM material_wastes WHERE id = :id")
    suspend fun deleteWasteById(id: String)
}

@Dao
interface CommercialProductDao {
    @Query("SELECT * FROM commercial_products WHERE companyId = :companyId ORDER BY name ASC")
    fun getProductsByCompany(companyId: String): Flow<List<CommercialProduct>>

    @Query("SELECT * FROM commercial_products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: String): CommercialProduct?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: CommercialProduct)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<CommercialProduct>)

    @Update
    suspend fun updateProduct(product: CommercialProduct)

    @Query("DELETE FROM commercial_products WHERE id = :id")
    suspend fun deleteProductById(id: String)
}

@Dao
interface StockMovementDao {
    @Query("SELECT * FROM stock_movements WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getMovementsByCompany(companyId: String): Flow<List<StockMovement>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovement(movement: StockMovement)
}

@Dao
interface CommercialSaleDao {
    @Query("SELECT * FROM commercial_sales WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getSalesByCompany(companyId: String): Flow<List<CommercialSale>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: CommercialSale)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSales(sales: List<CommercialSale>)
}

@Dao
interface SalesOpportunityDao {
    @Query("SELECT * FROM sales_opportunities WHERE companyId = :companyId ORDER BY updatedAt DESC")
    fun getOpportunitiesByCompany(companyId: String): Flow<List<SalesOpportunity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOpportunity(opp: SalesOpportunity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOpportunities(opps: List<SalesOpportunity>)

    @Update
    suspend fun updateOpportunity(opp: SalesOpportunity)

    @Query("DELETE FROM sales_opportunities WHERE id = :id")
    suspend fun deleteOpportunityById(id: String)
}

@Dao
interface LostSaleDao {
    @Query("SELECT * FROM lost_sales WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getLostSalesByCompany(companyId: String): Flow<List<LostSale>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLostSale(lostSale: LostSale)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLostSales(lostSales: List<LostSale>)

    @Update
    suspend fun updateLostSale(lostSale: LostSale)
}

@Dao
interface DailyAgendaTaskDao {
    @Query("SELECT * FROM daily_agenda WHERE companyId = :companyId ORDER BY timestamp ASC")
    fun getAgendaTasksByCompany(companyId: String): Flow<List<DailyAgendaTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAgendaTask(task: DailyAgendaTask)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAgendaTasks(tasks: List<DailyAgendaTask>)

    @Update
    suspend fun updateAgendaTask(task: DailyAgendaTask)

    @Query("DELETE FROM daily_agenda WHERE id = :id")
    suspend fun deleteAgendaTaskById(id: String)
}

@Dao
interface BranchDao {
    @Query("SELECT * FROM branches WHERE companyId = :companyId ORDER BY isHeadquarters DESC, name ASC")
    fun getBranchesByCompany(companyId: String): Flow<List<Branch>>

    @Query("SELECT * FROM branches WHERE id = :id LIMIT 1")
    suspend fun getBranchById(id: String): Branch?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBranch(branch: Branch)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBranches(branches: List<Branch>)

    @Update
    suspend fun updateBranch(branch: Branch)

    @Query("DELETE FROM branches WHERE id = :id")
    suspend fun deleteBranch(id: String)
}

@Dao
interface ServiceCatalogItemDao {
    @Query("SELECT * FROM service_catalog_items WHERE companyId = :companyId ORDER BY name ASC")
    fun getServicesByCompany(companyId: String): Flow<List<com.example.data.model.ServiceCatalogItem>>

    @Query("SELECT * FROM service_catalog_items WHERE id = :id LIMIT 1")
    suspend fun getServiceById(id: String): com.example.data.model.ServiceCatalogItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertService(service: com.example.data.model.ServiceCatalogItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServices(services: List<com.example.data.model.ServiceCatalogItem>)

    @Update
    suspend fun updateService(service: com.example.data.model.ServiceCatalogItem)

    @Query("DELETE FROM service_catalog_items WHERE id = :id")
    suspend fun deleteServiceById(id: String)
}

@Dao
interface VirtualStoreOrderDao {
    @Query("SELECT * FROM virtual_store_orders WHERE companyId = :companyId ORDER BY timestamp DESC")
    fun getOrdersByCompany(companyId: String): Flow<List<com.example.data.model.VirtualStoreOrder>>

    @Query("SELECT * FROM virtual_store_orders WHERE id = :id LIMIT 1")
    suspend fun getOrderById(id: String): com.example.data.model.VirtualStoreOrder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: com.example.data.model.VirtualStoreOrder)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<com.example.data.model.VirtualStoreOrder>)

    @Update
    suspend fun updateOrder(order: com.example.data.model.VirtualStoreOrder)

    @Query("DELETE FROM virtual_store_orders WHERE id = :id")
    suspend fun deleteOrderById(id: String)
}



