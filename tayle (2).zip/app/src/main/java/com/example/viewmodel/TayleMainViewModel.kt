package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.TayleDatabase
import com.example.data.local.seedDatabase
import com.example.data.model.*
import com.example.data.repository.AuthSessionManager
import com.example.data.repository.TayleRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

class TayleMainViewModel(application: Application) : AndroidViewModel(application) {

    val db = TayleDatabase.getDatabase(application)
    val repository = TayleRepository(db)
    val authManager = AuthSessionManager(repository)

    val currentUser: StateFlow<User?> = authManager.currentUser
    val currentCompany: StateFlow<Company?> = authManager.currentCompany

    val allCompanies: StateFlow<List<Company>> = repository.getAllCompanies()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Unidade selecionada para filtro (null = Visão Consolidada de todas as unidades para Matriz)
    private val _selectedBranch = MutableStateFlow<Branch?>(null)
    val selectedBranch: StateFlow<Branch?> = _selectedBranch.asStateFlow()

    // Indica se a Visão Consolidada está ativa (somente Matriz)
    val isConsolidatedView: StateFlow<Boolean> = combine(currentUser, _selectedBranch) { user, branch ->
        val isHeadquarters = user?.isHeadquartersUser == true || user?.role == UserRole.ADMINISTRADOR
        isHeadquarters && branch == null
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    // Base Unfiltered Company Collections
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allCompanyVehicles: StateFlow<List<Vehicle>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getVehicles(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allCompanyOrders: StateFlow<List<ServiceOrder>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getOrders(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allCompanyCommercialSales: StateFlow<List<CommercialSale>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getCommercialSales(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allCompanyCommercialProducts: StateFlow<List<CommercialProduct>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getCommercialProducts(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Branch-Filtered Collections based on user role and active branch selection
    val companyVehicles: StateFlow<List<Vehicle>> = combine(
        allCompanyVehicles,
        currentUser,
        _selectedBranch
    ) { vehs, user, selected ->
        val effectiveBranchId = if (user != null && !user.isHeadquartersUser && user.role != UserRole.ADMINISTRADOR) {
            user.branchId
        } else {
            selected?.id
        }
        if (effectiveBranchId == null) {
            vehs
        } else {
            vehs.filter { it.branchId == effectiveBranchId || (selected != null && it.branchName.contains(selected.name, ignoreCase = true)) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val companyOrders: StateFlow<List<ServiceOrder>> = combine(
        allCompanyOrders,
        currentUser,
        _selectedBranch
    ) { ords, user, selected ->
        val effectiveBranchId = if (user != null && !user.isHeadquartersUser && user.role != UserRole.ADMINISTRADOR) {
            user.branchId
        } else {
            selected?.id
        }
        if (effectiveBranchId == null) {
            ords
        } else {
            ords.filter { it.branchId == effectiveBranchId || (selected != null && it.branchName.contains(selected.name, ignoreCase = true)) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val companyCommercialSales: StateFlow<List<CommercialSale>> = combine(
        allCompanyCommercialSales,
        currentUser,
        _selectedBranch
    ) { sales, user, selected ->
        val effectiveBranchId = if (user != null && !user.isHeadquartersUser && user.role != UserRole.ADMINISTRADOR) {
            user.branchId
        } else {
            selected?.id
        }
        if (effectiveBranchId == null) {
            sales
        } else {
            sales.filter { it.branchId == effectiveBranchId || (selected != null && it.branchName.contains(selected.name, ignoreCase = true)) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyEmployees: StateFlow<List<Employee>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getEmployees(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyGoal: StateFlow<Goal?> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getGoal(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyNotifications: StateFlow<List<TayleNotification>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getNotifications(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyMaterials: StateFlow<List<Material>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getMaterials(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyMaterialMovements: StateFlow<List<MaterialMovement>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getMaterialMovements(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyLowStockMaterials: StateFlow<List<Material>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getLowStockMaterials(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyMaterialOrders: StateFlow<List<MaterialOrder>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getMaterialOrders(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyMaterialWastes: StateFlow<List<MaterialWaste>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getMaterialWastes(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val companyCommercialProducts: StateFlow<List<CommercialProduct>> = allCompanyCommercialProducts

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyStockMovements: StateFlow<List<StockMovement>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getStockMovements(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companySalesOpportunities: StateFlow<List<SalesOpportunity>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getSalesOpportunities(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyLostSales: StateFlow<List<LostSale>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getLostSales(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyDailyAgendaTasks: StateFlow<List<DailyAgendaTask>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getDailyAgendaTasks(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyBranches: StateFlow<List<Branch>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getBranches(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val companyUsers: StateFlow<List<User>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getUsersByCompany(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allCompanyCatalogServices: StateFlow<List<ServiceCatalogItem>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getCatalogServices(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val companyCatalogServices: StateFlow<List<ServiceCatalogItem>> = combine(
        allCompanyCatalogServices,
        currentUser,
        _selectedBranch
    ) { srvs, user, selected ->
        val effectiveBranchId = if (user != null && !user.isHeadquartersUser && user.role != UserRole.ADMINISTRADOR) {
            user.branchId
        } else {
            selected?.id
        }
        if (effectiveBranchId == null) {
            srvs
        } else {
            srvs.filter { it.branchId == effectiveBranchId || (selected != null && it.branchName.contains(selected.name, ignoreCase = true)) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allCompanyVirtualStoreOrders: StateFlow<List<VirtualStoreOrder>> = currentCompany.filterNotNull()
        .flatMapLatest { comp -> repository.getVirtualStoreOrders(comp.id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val companyVirtualStoreOrders: StateFlow<List<VirtualStoreOrder>> = combine(
        allCompanyVirtualStoreOrders,
        currentUser,
        _selectedBranch
    ) { ords, user, selected ->
        val effectiveBranchId = if (user != null && !user.isHeadquartersUser && user.role != UserRole.ADMINISTRADOR) {
            user.branchId
        } else {
            selected?.id
        }
        if (effectiveBranchId == null) {
            ords
        } else {
            ords.filter { it.branchId == effectiveBranchId || (selected != null && it.branchName.contains(selected.name, ignoreCase = true)) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            allCompanies.first { it.isNotEmpty() }
            val admin = repository.getUserByEmail("admin@tayle.com")
            if (admin != null) {
                val comp = repository.getCompanyById(admin.companyId)
                if (comp != null) {
                    authManager.setLoggedInUserDirectly(admin, comp)
                }
            }
        }
    }

    fun login(email: String, desiredRole: UserRole = UserRole.ADMINISTRADOR) {
        viewModelScope.launch {
            authManager.login(email, desiredRole)
        }
    }

    fun registerCompanyAndLogin(company: Company, adminUser: User) {
        viewModelScope.launch {
            repository.insertCompany(company)
            repository.insertUser(adminUser)
            authManager.setLoggedInUserDirectly(adminUser, company)
        }
    }

    fun switchRoleForDemo(newRole: UserRole) {
        authManager.switchRoleForDemo(newRole)
    }

    fun switchCompanyForDemo(newCompany: Company) {
        viewModelScope.launch {
            authManager.switchCompanyForDemo(newCompany)
            _selectedBranch.value = null
        }
    }

    fun selectBranch(branch: Branch?) {
        val user = currentUser.value
        // Se for usuário de filial e não for admin matriz, não pode navegar para dados de outra unidade
        if (user != null && !user.isHeadquartersUser && user.role != UserRole.ADMINISTRADOR) {
            return
        }
        _selectedBranch.value = branch
    }

    fun switchActiveUserForDemo(user: User) {
        viewModelScope.launch {
            val comp = repository.getCompanyById(user.companyId) ?: return@launch
            authManager.setLoggedInUserDirectly(user, comp)
            if (!user.isHeadquartersUser && user.role != UserRole.ADMINISTRADOR) {
                val branch = repository.getBranchById(user.branchId)
                _selectedBranch.value = branch
            } else {
                _selectedBranch.value = null
            }
        }
    }

    fun addBranch(
        name: String,
        code: String,
        address: String,
        phone: String,
        managerName: String,
        authorizedUsersCount: Int = 5,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val company = currentCompany.value ?: return@launch
            val branches = companyBranches.value
            val maxAllowed = when {
                company.plan.contains("Básico", ignoreCase = true) -> 1
                company.plan.contains("Médio", ignoreCase = true) -> 3
                else -> 10
            }
            if (branches.size >= maxAllowed) {
                onResult(false, "Limite do plano atingido ($maxAllowed unidades). Faça upgrade para cadastrar mais filiais.")
                return@launch
            }

            val newBranch = Branch(
                id = "branch_${System.currentTimeMillis()}",
                companyId = company.id,
                name = name,
                code = code,
                address = address,
                phone = phone,
                managerName = managerName,
                status = "Ativa",
                isHeadquarters = false,
                authorizedUsersCount = authorizedUsersCount
            )
            repository.insertBranch(newBranch)
            repository.updateCompany(company.copy(branchesCount = branches.size + 1))
            onResult(true, "Filial $name ($code) cadastrada com sucesso!")
        }
    }

    fun logout() {
        authManager.logout()
    }

    fun createServiceOrder(order: ServiceOrder) {
        viewModelScope.launch {
            val user = currentUser.value
            val branch = _selectedBranch.value
            val effectiveBranchId = if (user != null && !user.isHeadquartersUser && !user.branchId.isNullOrBlank()) {
                user.branchId
            } else {
                branch?.id ?: order.branchId
            }
            val effectiveBranchName = if (user != null && !user.isHeadquartersUser && !user.branchName.isNullOrBlank()) {
                user.branchName
            } else {
                branch?.name ?: order.branchName
            }
            val enriched = order.copy(
                branchId = effectiveBranchId,
                branchName = effectiveBranchName
            )
            repository.insertOrder(enriched)
            val notif = TayleNotification(
                id = UUID.randomUUID().toString(),
                companyId = order.companyId,
                title = "Nova O.S. #${order.osNumber}",
                description = "${order.displayPlate} - ${order.displayClientName} • $effectiveBranchName",
                type = NotificationType.INFO
            )
            repository.insertNotification(notif)
        }
    }

    fun updateOrderStatus(order: ServiceOrder, newStatus: OsStatus) {
        viewModelScope.launch {
            val updated = order.copy(
                status = newStatus,
                completedAt = if (newStatus == OsStatus.CONCLUIDA || newStatus == OsStatus.ENTREGUE) System.currentTimeMillis() else order.completedAt
            )
            repository.updateOrder(updated)
            val notif = TayleNotification(
                id = UUID.randomUUID().toString(),
                companyId = order.companyId,
                title = "O.S. #${order.osNumber} atualizada",
                description = "Status alterado para ${newStatus.label}",
                type = if (newStatus == OsStatus.CONCLUIDA) NotificationType.SUCCESS else NotificationType.INFO
            )
            repository.insertNotification(notif)
        }
    }

    fun addVehicle(vehicle: Vehicle) {
        viewModelScope.launch {
            val user = currentUser.value
            val branch = _selectedBranch.value
            val effectiveBranchId = if (user != null && !user.isHeadquartersUser && !user.branchId.isNullOrBlank()) {
                user.branchId
            } else {
                branch?.id ?: vehicle.branchId
            }
            val effectiveBranchName = if (user != null && !user.isHeadquartersUser && !user.branchName.isNullOrBlank()) {
                user.branchName
            } else {
                branch?.name ?: vehicle.branchName
            }
            val enriched = vehicle.copy(
                branchId = effectiveBranchId,
                branchName = effectiveBranchName
            )
            repository.insertVehicle(enriched)
        }
    }

    fun updateVehicleStatus(vehicle: Vehicle, newStatus: VehicleStatus) {
        viewModelScope.launch {
            repository.updateVehicle(vehicle.copy(status = newStatus))
        }
    }

    fun markAllNotificationsAsRead() {
        val compId = currentCompany.value?.id ?: return
        viewModelScope.launch {
            repository.markAllNotificationsAsRead(compId)
        }
    }

    // Material & Stock operations
    fun addMaterial(material: Material) {
        viewModelScope.launch {
            repository.insertMaterial(material)
        }
    }

    fun updateMaterial(material: Material) {
        viewModelScope.launch {
            repository.updateMaterial(material)
        }
    }

    fun deleteMaterial(materialId: String) {
        viewModelScope.launch {
            repository.deleteMaterial(materialId)
        }
    }

    fun registerMaterialEntry(
        material: Material,
        quantityToAdd: Double,
        newUnitCost: Double?,
        updatedSupplier: String?,
        reasonOrInvoice: String,
        registeredByName: String
    ) {
        viewModelScope.launch {
            val updatedCost = newUnitCost ?: material.unitCost
            val updatedSupplierName = if (!updatedSupplier.isNullOrBlank()) updatedSupplier else material.supplier
            val updatedMat = material.copy(
                currentQuantity = material.currentQuantity + quantityToAdd,
                unitCost = updatedCost,
                supplier = updatedSupplierName
            )
            repository.updateMaterial(updatedMat)

            val movement = MaterialMovement(
                id = UUID.randomUUID().toString(),
                companyId = material.companyId,
                materialId = material.id,
                materialName = material.name,
                type = MovementType.ENTRADA,
                quantity = quantityToAdd,
                unit = material.unit,
                unitCost = updatedCost,
                totalCost = updatedCost * quantityToAdd,
                reason = reasonOrInvoice,
                registeredByName = registeredByName
            )
            repository.insertMovement(movement)
        }
    }

    fun registerMaterialExit(
        material: Material,
        quantityToSubtract: Double,
        reasonOrOs: String,
        registeredByName: String
    ) {
        viewModelScope.launch {
            val newQty = (material.currentQuantity - quantityToSubtract).coerceAtLeast(0.0)
            val updatedMat = material.copy(currentQuantity = newQty)
            repository.updateMaterial(updatedMat)

            val movement = MaterialMovement(
                id = UUID.randomUUID().toString(),
                companyId = material.companyId,
                materialId = material.id,
                materialName = material.name,
                type = MovementType.SAIDA,
                quantity = quantityToSubtract,
                unit = material.unit,
                unitCost = material.unitCost,
                totalCost = material.unitCost * quantityToSubtract,
                reason = reasonOrOs,
                registeredByName = registeredByName
            )
            repository.insertMovement(movement)
        }
    }

    fun adjustMaterialStock(
        material: Material,
        newQuantity: Double,
        reason: String,
        registeredByName: String
    ) {
        viewModelScope.launch {
            val diff = newQuantity - material.currentQuantity
            val updatedMat = material.copy(currentQuantity = newQuantity)
            repository.updateMaterial(updatedMat)

            val movement = MaterialMovement(
                id = UUID.randomUUID().toString(),
                companyId = material.companyId,
                materialId = material.id,
                materialName = material.name,
                type = MovementType.AJUSTE,
                quantity = diff,
                unit = material.unit,
                unitCost = material.unitCost,
                totalCost = material.unitCost * kotlin.math.abs(diff),
                reason = reason,
                registeredByName = registeredByName
            )
            repository.insertMovement(movement)
        }
    }

    fun createMaterialOrder(order: MaterialOrder) {
        viewModelScope.launch {
            repository.insertMaterialOrder(order)
            val notif = TayleNotification(
                id = UUID.randomUUID().toString(),
                companyId = order.companyId,
                title = "Novo Pedido de Compra",
                description = "${order.materialName} - ${order.quantity} ${order.unit} (${order.supplier})",
                type = NotificationType.INFO
            )
            repository.insertNotification(notif)
        }
    }

    fun updateMaterialOrderStatus(order: MaterialOrder, newStatus: MaterialOrderStatus, currentUserName: String) {
        viewModelScope.launch {
            val updatedOrder = order.copy(
                status = newStatus,
                receivedAt = if (newStatus == MaterialOrderStatus.ENTREGUE) System.currentTimeMillis() else order.receivedAt
            )
            repository.updateMaterialOrder(updatedOrder)

            // If received, auto add to material stock
            if (newStatus == MaterialOrderStatus.ENTREGUE) {
                val mat = repository.getMaterialById(order.materialId)
                if (mat != null) {
                    registerMaterialEntry(
                        material = mat,
                        quantityToAdd = order.quantity,
                        newUnitCost = order.unitCost,
                        updatedSupplier = order.supplier,
                        reasonOrInvoice = "Recebimento Pedido #${order.id.take(6)}",
                        registeredByName = currentUserName
                    )
                }
            }
        }
    }

    fun deleteMaterialOrder(orderId: String) {
        viewModelScope.launch {
            repository.deleteMaterialOrder(orderId)
        }
    }

    fun registerMaterialWaste(waste: MaterialWaste) {
        viewModelScope.launch {
            repository.insertMaterialWaste(waste)
            // Deduct from stock as loss
            val mat = repository.getMaterialById(waste.materialId)
            if (mat != null) {
                val newQty = (mat.currentQuantity - waste.quantity).coerceAtLeast(0.0)
                repository.updateMaterial(mat.copy(currentQuantity = newQty))

                val movement = MaterialMovement(
                    id = UUID.randomUUID().toString(),
                    companyId = waste.companyId,
                    materialId = waste.materialId,
                    materialName = waste.materialName,
                    type = MovementType.PERDA,
                    quantity = waste.quantity,
                    unit = waste.unit,
                    unitCost = waste.unitCost,
                    totalCost = waste.totalCost,
                    reason = "Perda: ${waste.reason} (${waste.details})",
                    registeredByName = waste.responsibleName
                )
                repository.insertMovement(movement)
            }
        }
    }

    fun deleteMaterialWaste(wasteId: String) {
        viewModelScope.launch {
            repository.deleteMaterialWaste(wasteId)
        }
    }

    fun clearAllNotifications() {
        markAllNotificationsAsRead()
    }

    // Commercial Products & Services
    fun saveCommercialProduct(product: CommercialProduct) {
        viewModelScope.launch {
            repository.insertCommercialProduct(product)
        }
    }

    fun deleteCommercialProduct(id: String) {
        viewModelScope.launch {
            repository.deleteCommercialProduct(id)
        }
    }

    // Sales Funnel
    fun saveSalesOpportunity(opp: SalesOpportunity) {
        viewModelScope.launch {
            repository.insertSalesOpportunity(opp)
        }
    }

    fun updateSalesOpportunity(opp: SalesOpportunity) {
        viewModelScope.launch {
            repository.updateSalesOpportunity(opp)
        }
    }

    fun updateOpportunityStage(opp: SalesOpportunity, newStage: FunnelStage) {
        viewModelScope.launch {
            repository.updateSalesOpportunity(opp.copy(stage = newStage, updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteSalesOpportunity(id: String) {
        viewModelScope.launch {
            repository.deleteSalesOpportunity(id)
        }
    }

    // Lost Sales
    fun registerLostSale(lostSale: LostSale) {
        viewModelScope.launch {
            repository.insertLostSale(lostSale)
        }
    }

    fun updateLostSale(lostSale: LostSale) {
        viewModelScope.launch {
            repository.updateLostSale(lostSale)
        }
    }

    // Daily Agenda Tasks
    fun saveDailyAgendaTask(task: DailyAgendaTask) {
        viewModelScope.launch {
            repository.insertDailyAgendaTask(task)
        }
    }

    fun toggleDailyAgendaTask(task: DailyAgendaTask) {
        viewModelScope.launch {
            repository.updateDailyAgendaTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteDailyAgendaTask(id: String) {
        viewModelScope.launch {
            repository.deleteDailyAgendaTask(id)
        }
    }

    // Commercial Sales
    fun registerCommercialSale(sale: CommercialSale, deductStockProduct: CommercialProduct? = null) {
        viewModelScope.launch {
            val user = currentUser.value
            val branch = _selectedBranch.value
            val effectiveBranchId = if (user != null && !user.isHeadquartersUser && !user.branchId.isNullOrBlank()) {
                user.branchId
            } else {
                branch?.id ?: sale.branchId
            }
            val effectiveBranchName = if (user != null && !user.isHeadquartersUser && !user.branchName.isNullOrBlank()) {
                user.branchName
            } else {
                branch?.name ?: sale.branchName
            }
            val enrichedSale = sale.copy(
                branchId = effectiveBranchId,
                branch = effectiveBranchName,
                branchName = effectiveBranchName
            )
            repository.insertCommercialSale(enrichedSale)

            if (deductStockProduct != null && deductStockProduct.itemType == ItemType.PRODUTO) {
                val newStock = (deductStockProduct.stockCurrent - sale.quantity).coerceAtLeast(0)
                repository.updateCommercialProduct(
                    deductStockProduct.copy(
                        stockCurrent = newStock,
                        salesCount = deductStockProduct.salesCount + sale.quantity,
                        revenueGenerated = deductStockProduct.revenueGenerated + sale.revenue
                    )
                )

                // Record stock movement
                val mov = StockMovement(
                    id = UUID.randomUUID().toString(),
                    companyId = sale.companyId,
                    productId = deductStockProduct.id,
                    productName = deductStockProduct.name,
                    isEntry = false,
                    quantity = sale.quantity,
                    dateFormatted = sale.dateFormatted,
                    timeFormatted = "14:30",
                    responsibleName = sale.sellerName,
                    department = sale.department,
                    reason = "Venda comercial para ${sale.clientName}",
                    previousStock = deductStockProduct.stockCurrent,
                    newStock = newStock
                )
                repository.insertStockMovement(mov)
            }

            // Notification
            val notif = TayleNotification(
                id = UUID.randomUUID().toString(),
                companyId = sale.companyId,
                title = "Venda Realizada! 🎉",
                description = "${sale.productName} • ${sale.sellerName} (R$ ${"%.2f".format(Locale.US, sale.revenue)})",
                type = NotificationType.SUCESSO
            )
            repository.insertNotification(notif)
        }
    }

    fun registerStockMovement(
        product: CommercialProduct,
        isEntry: Boolean,
        quantity: Int,
        reason: String,
        responsibleName: String,
        dateFormatted: String
    ) {
        viewModelScope.launch {
            val previous = product.stockCurrent
            val newQty = if (isEntry) previous + quantity else (previous - quantity).coerceAtLeast(0)
            repository.updateCommercialProduct(product.copy(stockCurrent = newQty))

            val movement = StockMovement(
                id = UUID.randomUUID().toString(),
                companyId = product.companyId,
                productId = product.id,
                productName = product.name,
                isEntry = isEntry,
                quantity = quantity,
                dateFormatted = dateFormatted,
                timeFormatted = "10:00",
                responsibleName = responsibleName,
                department = product.department,
                reason = reason,
                previousStock = previous,
                newStock = newQty
            )
            repository.insertStockMovement(movement)
        }
    }

    // =========================================================================
    // 1. GESTÃO E CADASTRO DE SERVIÇOS (Matriz & Filiais)
    // =========================================================================
    fun saveCatalogService(service: ServiceCatalogItem) {
        viewModelScope.launch {
            val user = currentUser.value
            val branch = _selectedBranch.value
            val effectiveBranchId = if (user != null && !user.isHeadquartersUser && !user.branchId.isNullOrBlank()) {
                user.branchId
            } else {
                branch?.id ?: service.branchId
            }
            val effectiveBranchName = if (user != null && !user.isHeadquartersUser && !user.branchName.isNullOrBlank()) {
                user.branchName
            } else {
                branch?.name ?: service.branchName
            }
            val enriched = service.copy(
                branchId = effectiveBranchId,
                branchName = effectiveBranchName,
                updatedAt = System.currentTimeMillis()
            )
            repository.insertCatalogService(enriched)
            val notif = TayleNotification(
                id = UUID.randomUUID().toString(),
                companyId = service.companyId,
                title = "Serviço Cadastrado/Atualizado",
                description = "${service.code} • ${service.name} (R$ ${"%.2f".format(Locale.US, service.salePrice)})",
                type = NotificationType.INFO
            )
            repository.insertNotification(notif)
        }
    }

    fun updateCatalogService(service: ServiceCatalogItem) {
        viewModelScope.launch {
            repository.updateCatalogService(service.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    fun toggleServiceActive(service: ServiceCatalogItem) {
        viewModelScope.launch {
            val updated = service.copy(
                isActive = !service.isActive,
                updatedAt = System.currentTimeMillis()
            )
            repository.updateCatalogService(updated)
        }
    }

    fun deleteCatalogService(id: String) {
        viewModelScope.launch {
            repository.deleteCatalogService(id)
        }
    }

    // =========================================================================
    // 2. LOJA VIRTUAL TAYLE (Pedidos, Vitrine & Checkout)
    // =========================================================================
    fun saveVirtualStoreOrder(order: VirtualStoreOrder, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val user = currentUser.value
            val branch = _selectedBranch.value
            val effectiveBranchId = if (user != null && !user.isHeadquartersUser && !user.branchId.isNullOrBlank()) {
                user.branchId
            } else {
                branch?.id ?: order.branchId
            }
            val effectiveBranchName = if (user != null && !user.isHeadquartersUser && !user.branchName.isNullOrBlank()) {
                user.branchName
            } else {
                branch?.name ?: order.branchName
            }
            val enrichedOrder = order.copy(
                branchId = effectiveBranchId,
                branchName = effectiveBranchName
            )
            repository.insertVirtualStoreOrder(enrichedOrder)

            // Deduct stock for products included in this store order
            order.itemsList.filter { !it.isService }.forEach { item ->
                val prod = repository.getCommercialProducts(order.companyId).firstOrNull()?.find { it.id == item.itemId || it.name == item.itemName }
                if (prod != null) {
                    val newStock = (prod.stockCurrent - item.quantity).coerceAtLeast(0)
                    repository.updateCommercialProduct(prod.copy(stockCurrent = newStock))
                    val mov = StockMovement(
                        id = UUID.randomUUID().toString(),
                        companyId = order.companyId,
                        productId = prod.id,
                        productName = prod.name,
                        isEntry = false,
                        quantity = item.quantity,
                        dateFormatted = order.dateFormatted,
                        timeFormatted = "15:00",
                        responsibleName = order.customerName,
                        department = prod.department,
                        reason = "Pedido Loja Virtual #${order.orderNumber}",
                        previousStock = prod.stockCurrent,
                        newStock = newStock
                    )
                    repository.insertStockMovement(mov)
                }
            }

            // If order contains services, optionally create an O.S. automatically or register notification
            val notif = TayleNotification(
                id = UUID.randomUUID().toString(),
                companyId = order.companyId,
                title = if (order.isQuoteRequest) "Novo Orçamento Solicitado" else "Novo Pedido Loja Virtual #${order.orderNumber}",
                description = "${order.customerName} • R$ ${"%.2f".format(Locale.US, order.total)} (${enrichedOrder.branchName})",
                type = NotificationType.SUCESSO
            )
            repository.insertNotification(notif)
            onComplete(true, "Pedido #${order.orderNumber} registrado com sucesso!")
        }
    }

    fun updateVirtualStoreOrderStatus(order: VirtualStoreOrder, newStatus: String) {
        viewModelScope.launch {
            repository.updateVirtualStoreOrder(order.copy(status = newStatus))
        }
    }

    fun deleteVirtualStoreOrder(id: String) {
        viewModelScope.launch {
            repository.deleteVirtualStoreOrder(id)
        }
    }

    // =========================================================================
    // 3. O.S. AUXILIARES
    // =========================================================================
    fun deleteServiceOrder(id: String) {
        viewModelScope.launch {
            repository.deleteOrder(id)
        }
    }
}
