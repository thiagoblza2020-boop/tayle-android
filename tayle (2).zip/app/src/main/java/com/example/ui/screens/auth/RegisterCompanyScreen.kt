package com.example.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Company
import com.example.data.model.Department
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun RegisterCompanyScreen(
    onRegister: (Company, User) -> Unit,
    onNavigateToLogin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var companyName by remember { mutableStateOf("") }
    var cnpj by remember { mutableStateOf("") }
    var segment by remember { mutableStateOf("Concessionária & Serviços Automotivos") }
    var branchesText by remember { mutableStateOf("1") }
    var adminName by remember { mutableStateOf("") }
    var adminEmail by remember { mutableStateOf("") }
    var adminPhone by remember { mutableStateOf("") }
    var selectedPlan by remember { mutableStateOf("Master R$ 99,90") }

    val plans = listOf("Básico R$ 29,90", "Médio R$ 59,90", "Master R$ 99,90")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(16.dp)
            .testTag("register_company_screen")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            IconButton(onClick = onNavigateToLogin) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Voltar", tint = TayleCyan)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Cadastrar Empresa",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TayleWhite
            )
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = TayleNavy900,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            LazyColumn(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("DADOS DA EMPRESA", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TayleCyan, letterSpacing = 1.sp)
                }

                item {
                    OutlinedTextField(
                        value = companyName,
                        onValueChange = { companyName = it },
                        label = { Text("Nome Fantasia / Razão Social") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = cnpj,
                            onValueChange = { cnpj = it },
                            label = { Text("CNPJ") },
                            placeholder = { Text("00.000.000/0001-00") },
                            modifier = Modifier.weight(1.2f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = branchesText,
                            onValueChange = { branchesText = it },
                            label = { Text("Filiais") },
                            modifier = Modifier.weight(0.8f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }
                }

                item {
                    Text("PLANO COMERCIAL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TayleCyan, letterSpacing = 1.sp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        plans.forEach { plan ->
                            FilterChip(
                                selected = selectedPlan == plan,
                                onClick = { selectedPlan = plan },
                                label = { Text(plan, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TayleCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = TayleCyan
                                )
                            )
                        }
                    }
                }

                item {
                    HorizontalDivider(color = TayleNavy800, modifier = Modifier.padding(vertical = 4.dp))
                    Text("ADMINISTRADOR PRINCIPAL", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TayleCyan, letterSpacing = 1.sp)
                }

                item {
                    OutlinedTextField(
                        value = adminName,
                        onValueChange = { adminName = it },
                        label = { Text("Nome Completo do Administrador") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = adminEmail,
                        onValueChange = { adminEmail = it },
                        label = { Text("E-mail do Administrador") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = adminPhone,
                        onValueChange = { adminPhone = it },
                        label = { Text("WhatsApp / Telefone") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (companyName.isNotBlank() && adminEmail.isNotBlank()) {
                                val compId = UUID.randomUUID().toString()
                                val newComp = Company(
                                    id = compId,
                                    name = companyName,
                                    document = cnpj.ifBlank { "00.000.000/0001-00" },
                                    segment = segment,
                                    plan = selectedPlan,
                                    branchesCount = branchesText.toIntOrNull() ?: 1,
                                    matrixAddress = "Sede Principal",
                                    phone = adminPhone,
                                    email = adminEmail,
                                    address = "Matriz"
                                )
                                val newAdmin = User(
                                    id = UUID.randomUUID().toString(),
                                    companyId = compId,
                                    name = adminName.ifBlank { "Administrador" },
                                    email = adminEmail,
                                    role = UserRole.ADMINISTRADOR,
                                    department = Department.ADMINISTRACAO,
                                    phone = adminPhone
                                )
                                onRegister(newComp, newAdmin)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_register_company_button")
                    ) {
                        Text("Criar Empresa e Iniciar", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
