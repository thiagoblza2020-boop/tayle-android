package com.example.ui.screens.materials

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.ui.components.MaterialOrderStatusBadge
import com.example.ui.theme.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialsStockScreen(
    materials: List<Material>,
    movements: List<MaterialMovement>,
    orders: List<MaterialOrder>,
    wastes: List<MaterialWaste>,
    currentUserRole: UserRole,
    currentUserName: String,
    currentCompanyId: String,
    onAddMaterial: (Material) -> Unit,
    onUpdateMaterial: (Material) -> Unit,
    onDeleteMaterial: (String) -> Unit,
    onRegisterEntry: (material: Material, qty: Double, cost: Double?, supplier: String?, invoice: String, userName: String) -> Unit,
    onRegisterExit: (material: Material, qty: Double, reason: String, userName: String) -> Unit,
    onCreateOrder: (MaterialOrder) -> Unit,
    onUpdateOrderStatus: (order: MaterialOrder, newStatus: MaterialOrderStatus) -> Unit,
    onDeleteOrder: (String) -> Unit,
    onRegisterWaste: (MaterialWaste) -> Unit,
    onDeleteWaste: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(MaterialSectionTab.STOCK) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Todos") }

    // Dialog state
    var showAddMaterialDialog by remember { mutableStateOf(false) }
    var materialToEdit by remember { mutableStateOf<Material?>(null) }
    var materialForEntry by remember { mutableStateOf<Material?>(null) }
    var materialForExit by remember { mutableStateOf<Material?>(null) }
    var materialForMovements by remember { mutableStateOf<Material?>(null) }
    var showNewOrderDialog by remember { mutableStateOf(false) }
    var showNewWasteDialog by remember { mutableStateOf(false) }

    val currencyFormat = remember {
        NumberFormat.getCurrencyInstance(Locale("pt", "BR"))
    }

    val categories = remember(materials) {
        listOf("Todos") + materials.map { it.category }.distinct()
    }

    val filteredMaterials = remember(materials, searchQuery, selectedCategory) {
        materials.filter { mat ->
            val matchesSearch = mat.name.contains(searchQuery, ignoreCase = true) ||
                    mat.category.contains(searchQuery, ignoreCase = true) ||
                    mat.supplier.contains(searchQuery, ignoreCase = true)
            val matchesCat = selectedCategory == "Todos" || mat.category == selectedCategory
            matchesSearch && matchesCat
        }
    }

    val lowStockCount = remember(materials) {
        materials.count { it.currentQuantity <= it.minQuantity }
    }

    val totalStockValue = remember(materials) {
        materials.sumOf { it.currentQuantity * it.unitCost }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(16.dp)
            .testTag("materials_stock_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "📦 Estoque & Suprimentos",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = TayleAmber.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "OFICIAL",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleAmber,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Text(
                    text = "Controle de peças, lubrificantes, reposição e perdas",
                    style = MaterialTheme.typography.bodySmall,
                    color = TayleSlateLight
                )
            }

            if (currentUserRole.level >= UserRole.SUPERVISOR.level) {
                Button(
                    onClick = {
                        when (selectedTab) {
                            MaterialSectionTab.STOCK, MaterialSectionTab.REPLENISHMENT -> showAddMaterialDialog = true
                            MaterialSectionTab.ORDERS -> showNewOrderDialog = true
                            MaterialSectionTab.WASTE -> showNewWasteDialog = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TayleCyan,
                        contentColor = TayleNavy950
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("add_material_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when (selectedTab) {
                            MaterialSectionTab.ORDERS -> "Novo Pedido"
                            MaterialSectionTab.WASTE -> "Reg. Perda"
                            else -> "Novo Item"
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // KPI Summary Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = TayleNavy900,
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Total Itens", fontSize = 11.sp, color = TayleSlateLight)
                    Text(
                        text = "${materials.size}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = TayleNavy900,
                modifier = Modifier.weight(1.3f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Valor em Estoque", fontSize = 11.sp, color = TayleSlateLight)
                    Text(
                        text = currencyFormat.format(totalStockValue),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (lowStockCount > 0) TayleAmber.copy(alpha = 0.15f) else TayleNavy900,
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Estoque Baixo", fontSize = 11.sp, color = if (lowStockCount > 0) TayleAmber else TayleSlateLight)
                    Text(
                        text = "$lowStockCount",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (lowStockCount > 0) TayleAmber else TayleWhite
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Navigation Tabs
        TabRow(
            selectedTabIndex = selectedTab.ordinal,
            containerColor = TayleNavy900,
            contentColor = TayleCyan,
            divider = { HorizontalDivider(color = TayleNavy800) }
        ) {
            MaterialSectionTab.entries.forEach { tab ->
                Tab(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    text = {
                        Text(
                            text = tab.title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    icon = {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedTab) {
            MaterialSectionTab.STOCK -> {
                // Search & Filter
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Buscar peça, lubrificante ou fornecedor...", color = TayleSlateLight, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Buscar", tint = TayleCyan) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Clear, contentDescription = "Limpar", tint = TayleSlateLight)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stock_search_input"),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy800,
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Category Filter Pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(4).forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TayleCyan.copy(alpha = 0.2f),
                                selectedLabelColor = TayleCyan
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Materials List
                if (filteredMaterials.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Nenhum item encontrado no estoque.", color = TayleSlateLight)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredMaterials) { mat ->
                            MaterialCard(
                                material = mat,
                                currencyFormat = currencyFormat,
                                canManage = currentUserRole.level >= UserRole.SUPERVISOR.level,
                                onEntryClick = { materialForEntry = mat },
                                onExitClick = { materialForExit = mat },
                                onMovementsClick = { materialForMovements = mat },
                                onEditClick = { materialToEdit = mat },
                                onDeleteClick = { onDeleteMaterial(mat.id) }
                            )
                        }
                    }
                }
            }

            MaterialSectionTab.REPLENISHMENT -> {
                val lowStockItems = materials.filter { it.currentQuantity <= it.minQuantity }
                if (lowStockItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = TayleGreen,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Estoque em dia!", color = TayleWhite, fontWeight = FontWeight.Bold)
                            Text("Nenhum item abaixo do nível de segurança.", color = TayleSlateLight, fontSize = 12.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(lowStockItems) { mat ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = TayleNavy900,
                                border = androidx.compose.foundation.BorderStroke(1.dp, TayleAmber.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = mat.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = TayleWhite
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = TayleAmber.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = "REPOR URGENTE",
                                                color = TayleAmber,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Disponível: ${mat.currentQuantity} ${mat.unit} | Mínimo Seguro: ${mat.minQuantity} ${mat.unit}",
                                        color = TayleAmber,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "Fornecedor: ${mat.supplier} • Local: ${mat.location}",
                                        color = TayleSlateLight,
                                        fontSize = 11.sp
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        Button(
                                            onClick = {
                                                val suggestedOrder = MaterialOrder(
                                                    id = UUID.randomUUID().toString(),
                                                    companyId = currentCompanyId,
                                                    materialId = mat.id,
                                                    materialName = mat.name,
                                                    quantity = (mat.minQuantity * 2) - mat.currentQuantity,
                                                    unit = mat.unit,
                                                    unitCost = mat.unitCost,
                                                    totalCost = mat.unitCost * ((mat.minQuantity * 2) - mat.currentQuantity),
                                                    supplier = mat.supplier,
                                                    status = MaterialOrderStatus.SOLICITADO,
                                                    orderedByName = currentUserName
                                                )
                                                onCreateOrder(suggestedOrder)
                                                selectedTab = MaterialSectionTab.ORDERS
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = TayleAmber,
                                                contentColor = TayleNavy950
                                            ),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Filled.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Gerar Pedido de Compra", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            MaterialSectionTab.ORDERS -> {
                if (orders.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Nenhum pedido de compra registrado.", color = TayleSlateLight)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(orders) { order ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = TayleNavy900,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = order.materialName,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = TayleWhite
                                            )
                                            Text(
                                                text = "Fornecedor: ${order.supplier}",
                                                fontSize = 11.sp,
                                                color = TayleSlateLight
                                            )
                                        }
                                        MaterialOrderStatusBadge(status = order.status)
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "Qtd: ${order.quantity} ${order.unit} x ${currencyFormat.format(order.unitCost)}",
                                            fontSize = 12.sp,
                                            color = TayleSlateLight
                                        )
                                        Text(
                                            text = "Total: ${currencyFormat.format(order.totalCost)}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TayleCyan
                                        )
                                    }

                                    if (order.status != MaterialOrderStatus.ENTREGUE && order.status != MaterialOrderStatus.CANCELADO) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    onUpdateOrderStatus(order, MaterialOrderStatus.CANCELADO)
                                                },
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TayleRedLight),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Cancelar", fontSize = 11.sp)
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Button(
                                                onClick = {
                                                    onUpdateOrderStatus(order, MaterialOrderStatus.ENTREGUE)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = TayleGreen, contentColor = TayleNavy950),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Confirmar Entrega", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            MaterialSectionTab.WASTE -> {
                if (wastes.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Nenhum registro de perda ou avaria.", color = TayleSlateLight)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(wastes) { waste ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = TayleNavy900,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = waste.materialName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = TayleWhite
                                        )
                                        Text(
                                            text = "-${waste.quantity} ${waste.unit} (${currencyFormat.format(waste.totalCost)})",
                                            fontWeight = FontWeight.Bold,
                                            color = TayleRedLight,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Motivo: ${waste.reason}",
                                        fontSize = 12.sp,
                                        color = TayleAmber
                                    )
                                    if (waste.details.isNotBlank()) {
                                        Text(
                                            text = "Detalhes: ${waste.details}",
                                            fontSize = 11.sp,
                                            color = TayleSlateLight
                                        )
                                    }
                                    Text(
                                        text = "Apontado por: ${waste.responsibleName}",
                                        fontSize = 10.sp,
                                        color = TayleSlateLight
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Material Entry Dialog
    if (materialForEntry != null) {
        val mat = materialForEntry!!
        var qtyText by remember { mutableStateOf("1") }
        var costText by remember { mutableStateOf(mat.unitCost.toString()) }
        var supplierText by remember { mutableStateOf(mat.supplier) }
        var invoiceText by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { materialForEntry = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Registrar Entrada de Estoque",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Text(
                        text = mat.name,
                        color = TayleCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("Quantidade (${mat.unit})") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = costText,
                        onValueChange = { costText = it },
                        label = { Text("Custo Unitário (R$)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = supplierText,
                        onValueChange = { supplierText = it },
                        label = { Text("Fornecedor") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = invoiceText,
                        onValueChange = { invoiceText = it },
                        label = { Text("Nota Fiscal / Justificativa") },
                        placeholder = { Text("Ex: NF-e 44321") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull() ?: 0.0
                            val cost = costText.toDoubleOrNull()
                            if (qty > 0) {
                                onRegisterEntry(
                                    mat,
                                    qty,
                                    cost,
                                    supplierText.ifBlank { null },
                                    invoiceText.ifBlank { "Entrada manual" },
                                    currentUserName
                                )
                                materialForEntry = null
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TayleGreen, contentColor = TayleNavy950),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Confirmar Entrada", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Material Exit Dialog
    if (materialForExit != null) {
        val mat = materialForExit!!
        var qtyText by remember { mutableStateOf("1") }
        var reasonText by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { materialForExit = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Registrar Saída / Consumo",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Text(
                        text = "${mat.name} (Atual: ${mat.currentQuantity} ${mat.unit})",
                        color = TayleCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("Quantidade a Retirar (${mat.unit})") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it },
                        label = { Text("Destino / Número da O.S.") },
                        placeholder = { Text("Ex: O.S. #1001 - Troca de Óleo") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val qty = qtyText.toDoubleOrNull() ?: 0.0
                            if (qty > 0) {
                                onRegisterExit(
                                    mat,
                                    qty,
                                    reasonText.ifBlank { "Consumo em O.S." },
                                    currentUserName
                                )
                                materialForExit = null
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Confirmar Saída", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Material Movements History Dialog
    if (materialForMovements != null) {
        val mat = materialForMovements!!
        val matMovements = movements.filter { it.materialId == mat.id }
        val df = remember { SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()) }

        Dialog(onDismissRequest = { materialForMovements = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Histórico de Movimentações",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Text(
                        text = mat.name,
                        color = TayleCyan,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    if (matMovements.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Nenhuma movimentação registrada para este item.", color = TayleSlateLight, fontSize = 12.sp)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(matMovements) { mov ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = TayleNavy800,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = when (mov.type) {
                                                        MovementType.ENTRADA, MovementType.ENTRADA_COMPRA -> "+${mov.quantity} ${mov.unit}"
                                                        MovementType.SAIDA, MovementType.SAIDA_CONSUMO_OS -> "-${mov.quantity} ${mov.unit}"
                                                        MovementType.AJUSTE, MovementType.AJUSTE_INVENTARIO -> "${mov.quantity} ${mov.unit}"
                                                        MovementType.PERDA, MovementType.PERDA_AVARIA -> "-${mov.quantity} ${mov.unit}"
                                                        else -> "${mov.quantity} ${mov.unit}"
                                                    },
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp,
                                                    color = when (mov.type) {
                                                        MovementType.ENTRADA, MovementType.ENTRADA_COMPRA -> TayleGreen
                                                        MovementType.SAIDA, MovementType.SAIDA_CONSUMO_OS -> TayleCyan
                                                        MovementType.AJUSTE, MovementType.AJUSTE_INVENTARIO -> TayleAmber
                                                        MovementType.PERDA, MovementType.PERDA_AVARIA -> TayleRedLight
                                                        else -> TayleWhite
                                                    }
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "(${mov.type.label})",
                                                    fontSize = 10.sp,
                                                    color = TayleSlateLight
                                                )
                                            }
                                            Text(
                                                text = mov.reason,
                                                fontSize = 11.sp,
                                                color = TayleWhite
                                            )
                                            Text(
                                                text = "Por: ${mov.registeredByName}",
                                                fontSize = 9.sp,
                                                color = TayleSlateLight
                                            )
                                        }
                                        Text(
                                            text = df.format(Date(mov.timestamp)),
                                            fontSize = 10.sp,
                                            color = TayleSlateLight
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TextButton(
                        onClick = { materialForMovements = null },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Fechar", color = TayleCyan)
                    }
                }
            }
        }
    }

    // Add / Edit Material Dialog
    if (showAddMaterialDialog || materialToEdit != null) {
        val isEditing = materialToEdit != null
        val editItem = materialToEdit

        var name by remember { mutableStateOf(editItem?.name ?: "") }
        var category by remember { mutableStateOf(editItem?.category ?: "Lubrificantes") }
        var unit by remember { mutableStateOf(editItem?.unit ?: "UN") }
        var currentQtyText by remember { mutableStateOf(editItem?.currentQuantity?.toString() ?: "10.0") }
        var minQtyText by remember { mutableStateOf(editItem?.minQuantity?.toString() ?: "5.0") }
        var costText by remember { mutableStateOf(editItem?.unitCost?.toString() ?: "25.00") }
        var location by remember { mutableStateOf(editItem?.location ?: "Prateleira A1") }
        var supplier by remember { mutableStateOf(editItem?.supplier ?: "") }

        Dialog(onDismissRequest = {
            showAddMaterialDialog = false
            materialToEdit = null
        }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isEditing) "Editar Item do Estoque" else "Cadastrar Novo Item",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text("Nome do Item / Peça") },
                                placeholder = { Text("Ex: Filtro de Combustível") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TayleCyan,
                                    unfocusedBorderColor = TayleNavy700,
                                    focusedTextColor = TayleWhite,
                                    unfocusedTextColor = TayleWhite
                                )
                            )
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = category,
                                    onValueChange = { category = it },
                                    label = { Text("Categoria") },
                                    modifier = Modifier.weight(1.2f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                                OutlinedTextField(
                                    value = unit,
                                    onValueChange = { unit = it.uppercase() },
                                    label = { Text("Unid.") },
                                    placeholder = { Text("UN / L") },
                                    modifier = Modifier.weight(0.8f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                            }
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = currentQtyText,
                                    onValueChange = { currentQtyText = it },
                                    label = { Text("Qtd. Atual") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                                OutlinedTextField(
                                    value = minQtyText,
                                    onValueChange = { minQtyText = it },
                                    label = { Text("Qtd. Mínima") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                            }
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = costText,
                                    onValueChange = { costText = it },
                                    label = { Text("Custo Unit. (R$)") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                                OutlinedTextField(
                                    value = location,
                                    onValueChange = { location = it },
                                    label = { Text("Localização") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = supplier,
                                onValueChange = { supplier = it },
                                label = { Text("Fornecedor Padrão") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TayleCyan,
                                    unfocusedBorderColor = TayleNavy700,
                                    focusedTextColor = TayleWhite,
                                    unfocusedTextColor = TayleWhite
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                val item = Material(
                                    id = editItem?.id ?: UUID.randomUUID().toString(),
                                    companyId = currentCompanyId,
                                    name = name,
                                    category = category,
                                    unit = unit,
                                    currentQuantity = currentQtyText.toDoubleOrNull() ?: 0.0,
                                    minQuantity = minQtyText.toDoubleOrNull() ?: 0.0,
                                    unitCost = costText.toDoubleOrNull() ?: 0.0,
                                    location = location,
                                    supplier = supplier
                                )
                                if (isEditing) {
                                    onUpdateMaterial(item)
                                } else {
                                    onAddMaterial(item)
                                }
                                showAddMaterialDialog = false
                                materialToEdit = null
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(if (isEditing) "Salvar Alterações" else "Cadastrar Item", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // New Order Dialog
    if (showNewOrderDialog) {
        var selectedMatId by remember { mutableStateOf(materials.firstOrNull()?.id ?: "") }
        val chosenMat = materials.find { it.id == selectedMatId }
        var qtyText by remember { mutableStateOf("10") }
        var costText by remember { mutableStateOf(chosenMat?.unitCost?.toString() ?: "20.00") }
        var supplierText by remember { mutableStateOf(chosenMat?.supplier ?: "") }

        Dialog(onDismissRequest = { showNewOrderDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Novo Pedido de Compra",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Selecione o Item:", fontSize = 12.sp, color = TayleSlateLight)
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 140.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(materials) { mat ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (mat.id == selectedMatId) TayleCyan.copy(alpha = 0.15f) else TayleNavy800,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedMatId = mat.id
                                        costText = mat.unitCost.toString()
                                        supplierText = mat.supplier
                                    }
                            ) {
                                Text(
                                    text = "${mat.name} (${mat.currentQuantity} em estoque)",
                                    fontSize = 12.sp,
                                    color = if (mat.id == selectedMatId) TayleCyan else TayleWhite,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = qtyText,
                            onValueChange = { qtyText = it },
                            label = { Text("Qtd. Pedida") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = costText,
                            onValueChange = { costText = it },
                            label = { Text("Custo Unit. (R$)") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = supplierText,
                        onValueChange = { supplierText = it },
                        label = { Text("Fornecedor") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val q = qtyText.toDoubleOrNull() ?: 0.0
                            val c = costText.toDoubleOrNull() ?: 0.0
                            if (chosenMat != null && q > 0) {
                                val order = MaterialOrder(
                                    id = UUID.randomUUID().toString(),
                                    companyId = currentCompanyId,
                                    materialId = chosenMat.id,
                                    materialName = chosenMat.name,
                                    quantity = q,
                                    unit = chosenMat.unit,
                                    unitCost = c,
                                    totalCost = q * c,
                                    supplier = supplierText,
                                    status = MaterialOrderStatus.SOLICITADO,
                                    orderedByName = currentUserName
                                )
                                onCreateOrder(order)
                                showNewOrderDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Emitir Pedido", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // New Waste Dialog
    if (showNewWasteDialog) {
        var selectedMatId by remember { mutableStateOf(materials.firstOrNull()?.id ?: "") }
        val chosenMat = materials.find { it.id == selectedMatId }
        var qtyText by remember { mutableStateOf("1") }
        var reasonText by remember { mutableStateOf("Quebra / Avaria física") }
        var detailsText by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showNewWasteDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Registrar Perda de Material",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Selecione o Item Avariado:", fontSize = 12.sp, color = TayleSlateLight)
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 130.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(materials) { mat ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (mat.id == selectedMatId) TayleCyan.copy(alpha = 0.15f) else TayleNavy800,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedMatId = mat.id }
                            ) {
                                Text(
                                    text = "${mat.name} (${mat.currentQuantity} em estoque)",
                                    fontSize = 12.sp,
                                    color = if (mat.id == selectedMatId) TayleCyan else TayleWhite,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("Qtd. Perdida (${chosenMat?.unit ?: "UN"})") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it },
                        label = { Text("Motivo") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = detailsText,
                        onValueChange = { detailsText = it },
                        label = { Text("Detalhes / Ocorrência") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val q = qtyText.toDoubleOrNull() ?: 0.0
                            if (chosenMat != null && q > 0) {
                                val waste = MaterialWaste(
                                    id = UUID.randomUUID().toString(),
                                    companyId = currentCompanyId,
                                    materialId = chosenMat.id,
                                    materialName = chosenMat.name,
                                    quantity = q,
                                    unit = chosenMat.unit,
                                    unitCost = chosenMat.unitCost,
                                    totalCost = q * chosenMat.unitCost,
                                    reason = reasonText,
                                    details = detailsText,
                                    responsibleName = currentUserName
                                )
                                onRegisterWaste(waste)
                                showNewWasteDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TayleRedLight, contentColor = TayleWhite),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Registrar Perda", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun MaterialCard(
    material: Material,
    currencyFormat: NumberFormat,
    canManage: Boolean,
    onEntryClick: () -> Unit,
    onExitClick: () -> Unit,
    onMovementsClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val isLow = material.currentQuantity <= material.minQuantity

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = TayleNavy900,
        border = if (isLow) androidx.compose.foundation.BorderStroke(1.dp, TayleAmber.copy(alpha = 0.6f)) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = material.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TayleWhite
                    )
                    Text(
                        text = "${material.category} • Local: ${material.location}",
                        fontSize = 11.sp,
                        color = TayleSlateLight
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isLow) TayleAmber.copy(alpha = 0.2f) else TayleNavy800
                ) {
                    Text(
                        text = if (isLow) "BAIXO" else "NORMAL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLow) TayleAmber else TayleGreen,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stock Details Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Disponível", fontSize = 10.sp, color = TayleSlateLight)
                    Text(
                        text = "${material.currentQuantity} ${material.unit}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLow) TayleAmber else TayleWhite
                    )
                }

                Column {
                    Text("Mín. Seguro", fontSize = 10.sp, color = TayleSlateLight)
                    Text(
                        text = "${material.minQuantity} ${material.unit}",
                        fontSize = 14.sp,
                        color = TayleSlateLight
                    )
                }

                Column {
                    Text("Custo Unit.", fontSize = 10.sp, color = TayleSlateLight)
                    Text(
                        text = currencyFormat.format(material.unitCost),
                        fontSize = 14.sp,
                        color = TayleWhite
                    )
                }

                Column {
                    Text("Total Item", fontSize = 10.sp, color = TayleSlateLight)
                    Text(
                        text = currencyFormat.format(material.currentQuantity * material.unitCost),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Actions: Entrada (+), Saída (-), Histórico, Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Entrada (+)
                    FilledTonalButton(
                        onClick = onEntryClick,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = TayleGreen.copy(alpha = 0.2f),
                            contentColor = TayleGreen
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "Entrada", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Entrada", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Saída (-)
                    FilledTonalButton(
                        onClick = onExitClick,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = TayleNavy700,
                            contentColor = TayleCyan
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(Icons.Filled.Remove, contentDescription = "Saída", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Saída", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    // Histórico
                    IconButton(
                        onClick = onMovementsClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.History,
                            contentDescription = "Histórico",
                            tint = TayleSlateLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (canManage) {
                    Row {
                        IconButton(onClick = onEditClick, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Edit, contentDescription = "Editar", tint = TayleSlateLight, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Delete, contentDescription = "Excluir", tint = TayleRedLight, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}
