package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Company
import com.example.data.model.User
import com.example.ui.components.RoleBadge
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    currentUser: User?,
    currentCompany: Company?,
    onLogout: () -> Unit,
    onSwitchCompany: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(16.dp)
            .testTag("profile_screen")
    ) {
        Text(
            text = "Meu Perfil",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = TayleWhite
        )
        Text(
            text = "Informações do usuário autenticado e dados corporativos",
            style = MaterialTheme.typography.bodySmall,
            color = TayleSlateLight
        )

        Spacer(modifier = Modifier.height(20.dp))

        // User Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = TayleNavy900,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(TayleCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser?.name?.take(1)?.uppercase() ?: "U",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleCyan
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = currentUser?.name ?: "Usuário",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TayleWhite
                        )
                        Text(
                            text = currentUser?.email ?: "",
                            fontSize = 13.sp,
                            color = TayleSlateLight
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        if (currentUser != null) {
                            RoleBadge(role = currentUser.role)
                        }
                    }
                }

                HorizontalDivider(color = TayleNavy800, modifier = Modifier.padding(vertical = 16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Departamento", color = TayleSlateLight, fontSize = 13.sp)
                    Text(currentUser?.department?.label ?: "Geral", color = TayleWhite, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Telefone / Ramal", color = TayleSlateLight, fontSize = 13.sp)
                    Text(currentUser?.phone ?: "-", color = TayleWhite, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Company Details Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = TayleNavy900,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Business, contentDescription = null, tint = TayleCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Unidade Atual",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TayleWhite
                        )
                    }
                    TextButton(onClick = onSwitchCompany) {
                        Text("Alternar", color = TayleCyan, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = currentCompany?.name ?: "TAYLE Matriz",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = TayleWhite
                )
                Text(
                    text = "CNPJ: ${currentCompany?.document ?: "12.345.678/0001-90"}",
                    fontSize = 12.sp,
                    color = TayleSlateLight
                )
                Text(
                    text = "Endereço: ${currentCompany?.address ?: "Av. das Nações Unidas, 12900"}",
                    fontSize = 12.sp,
                    color = TayleSlateLight
                )

                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleNavy800
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Plano Contratado", color = TayleSlateLight, fontSize = 12.sp)
                        Text(currentCompany?.plan ?: "Master R$ 99,90", color = TayleCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Logout Button
        Button(
            onClick = onLogout,
            colors = ButtonDefaults.buttonColors(
                containerColor = TayleRedLight.copy(alpha = 0.2f),
                contentColor = TayleRedLight
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("logout_button")
        ) {
            Icon(Icons.Filled.ExitToApp, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Encerrar Sessão", fontWeight = FontWeight.Bold)
        }
    }
}
