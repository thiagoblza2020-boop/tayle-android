package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.VehicleCatalog
import com.example.ui.theme.*

@Composable
fun BrandModelSelector(
    selectedBrand: String,
    selectedModel: String,
    onBrandSelected: (String) -> Unit,
    onModelSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var showBrandDialog by remember { mutableStateOf(false) }
    var showModelDialog by remember { mutableStateOf(false) }

    val availableModels = remember(selectedBrand) {
        VehicleCatalog.getModelsForBrand(selectedBrand)
    }

    Column(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Brand Field
            OutlinedTextField(
                value = selectedBrand.ifBlank { "Selecionar Marca" },
                onValueChange = {},
                readOnly = true,
                enabled = enabled,
                label = { Text("Marca", color = TayleSlateLight) },
                trailingIcon = {
                    IconButton(onClick = { if (enabled) showBrandDialog = true }) {
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = "Selecionar Marca", tint = TayleCyan)
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .clickable(enabled = enabled) { showBrandDialog = true }
                    .testTag("brand_selector_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TayleCyan,
                    unfocusedBorderColor = TayleNavy700,
                    focusedTextColor = TayleWhite,
                    unfocusedTextColor = TayleWhite
                )
            )

            // Model Field
            OutlinedTextField(
                value = selectedModel.ifBlank { "Selecionar Modelo" },
                onValueChange = {},
                readOnly = true,
                enabled = enabled && selectedBrand.isNotBlank(),
                label = { Text("Modelo", color = TayleSlateLight) },
                trailingIcon = {
                    IconButton(onClick = { if (enabled && selectedBrand.isNotBlank()) showModelDialog = true }) {
                        Icon(Icons.Filled.ArrowDropDown, contentDescription = "Selecionar Modelo", tint = TayleCyan)
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .clickable(enabled = enabled && selectedBrand.isNotBlank()) { showModelDialog = true }
                    .testTag("model_selector_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TayleCyan,
                    unfocusedBorderColor = TayleNavy700,
                    focusedTextColor = TayleWhite,
                    unfocusedTextColor = TayleWhite
                )
            )
        }
    }

    if (showBrandDialog) {
        Dialog(onDismissRequest = { showBrandDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Selecione a Marca",
                        style = MaterialTheme.typography.titleMedium,
                        color = TayleWhite,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        items(VehicleCatalog.brands) { brand ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (brand.name == selectedBrand) TayleCyan.copy(alpha = 0.15f) else TayleNavy800,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onBrandSelected(brand.name)
                                        if (brand.models.isNotEmpty()) {
                                            onModelSelected(brand.models.first())
                                        }
                                        showBrandDialog = false
                                    }
                            ) {
                                Text(
                                    text = brand.name,
                                    color = if (brand.name == selectedBrand) TayleCyan else TayleWhite,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showModelDialog && availableModels.isNotEmpty()) {
        Dialog(onDismissRequest = { showModelDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Modelos $selectedBrand",
                        style = MaterialTheme.typography.titleMedium,
                        color = TayleWhite,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        items(availableModels) { model ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (model == selectedModel) TayleCyan.copy(alpha = 0.15f) else TayleNavy800,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onModelSelected(model)
                                        showModelDialog = false
                                    }
                            ) {
                                Text(
                                    text = model,
                                    color = if (model == selectedModel) TayleCyan else TayleWhite,
                                    fontSize = 14.sp,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
