package com.example.ui.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun RoleBadge(
    role: UserRole,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (role) {
        UserRole.ADMINISTRADOR -> TayleAmber.copy(alpha = 0.18f) to TayleAmber
        UserRole.GERENTE -> TayleCyan.copy(alpha = 0.18f) to TayleCyan
        UserRole.SUPERVISOR -> TayleIndigo.copy(alpha = 0.18f) to TayleCyan
        UserRole.OPERADOR -> TayleNavy700 to TayleSlateLight
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bg,
        modifier = modifier
    ) {
        Text(
            text = role.label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun DepartmentBadge(
    department: Department,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = TayleNavy700,
        modifier = modifier
    ) {
        Text(
            text = department.label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            color = TayleSlateLight,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun OsStatusBadge(
    status: OsStatus,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (status) {
        OsStatus.PENDENTE -> TayleAmber.copy(alpha = 0.15f) to TayleAmber
        OsStatus.EM_ANDAMENTO, OsStatus.EM_EXECUCAO -> TayleCyan.copy(alpha = 0.15f) to TayleCyan
        OsStatus.ORCAMENTO -> TayleSlateLight.copy(alpha = 0.15f) to TayleSlateLight
        OsStatus.APROVADA -> TayleCyan.copy(alpha = 0.2f) to TayleCyan
        OsStatus.REVISAO, OsStatus.CONTROLE_QUALIDADE -> TayleIndigo.copy(alpha = 0.25f) to TayleCyan
        OsStatus.CONCLUIDA -> TayleGreen.copy(alpha = 0.15f) to TayleGreen
        OsStatus.ENTREGUE -> TayleSlateLight.copy(alpha = 0.2f) to TayleWhite
        OsStatus.CANCELADA -> TayleRedLight.copy(alpha = 0.15f) to TayleRedLight
        else -> TayleNavy700 to TayleSlateLight
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bg,
        modifier = modifier
    ) {
        Text(
            text = status.label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun VehicleStatusBadge(
    status: VehicleStatus,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (status) {
        VehicleStatus.AGUARDANDO_INSPECAO -> TayleAmber.copy(alpha = 0.15f) to TayleAmber
        VehicleStatus.EM_SERVICO -> TayleCyan.copy(alpha = 0.15f) to TayleCyan
        VehicleStatus.AGUARDANDO_PECAS -> TayleRedLight.copy(alpha = 0.15f) to TayleRedLight
        VehicleStatus.PRONTO -> TayleGreen.copy(alpha = 0.15f) to TayleGreen
        VehicleStatus.ENTREGUE -> TayleNavy700 to TayleSlateLight
        else -> TayleNavy700 to TayleSlateLight
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bg,
        modifier = modifier
    ) {
        Text(
            text = status.label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun PriorityBadge(
    priority: OsPriority,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (priority) {
        OsPriority.BAIXA -> TayleNavy700 to TayleSlateLight
        OsPriority.NORMAL -> TayleCyan.copy(alpha = 0.15f) to TayleCyan
        OsPriority.ALTA -> TayleAmber.copy(alpha = 0.18f) to TayleAmber
        OsPriority.URGENTE -> TayleRedLight.copy(alpha = 0.2f) to TayleRedLight
        else -> TayleNavy700 to TayleSlateLight
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bg,
        modifier = modifier
    ) {
        Text(
            text = priority.label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun MaterialOrderStatusBadge(
    status: MaterialOrderStatus,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (status) {
        MaterialOrderStatus.RASCUNHO -> TayleNavy700 to TayleSlateLight
        MaterialOrderStatus.SOLICITADO -> TayleAmber.copy(alpha = 0.15f) to TayleAmber
        MaterialOrderStatus.PENDENTE -> TayleAmber.copy(alpha = 0.2f) to TayleAmber
        MaterialOrderStatus.ENVIADO -> TayleCyan.copy(alpha = 0.15f) to TayleCyan
        MaterialOrderStatus.APROVADO -> TayleCyan.copy(alpha = 0.25f) to TayleCyan
        MaterialOrderStatus.ENTREGUE -> TayleGreen.copy(alpha = 0.15f) to TayleGreen
        MaterialOrderStatus.CANCELADO -> TayleRedLight.copy(alpha = 0.15f) to TayleRedLight
        else -> TayleNavy700 to TayleSlateLight
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bg,
        modifier = modifier
    ) {
        Text(
            text = status.label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}
