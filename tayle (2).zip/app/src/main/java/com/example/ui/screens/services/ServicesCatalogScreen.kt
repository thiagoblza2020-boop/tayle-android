package com.example.ui.screens.services

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Branch
import com.example.data.model.ServiceCatalogItem
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.*
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServicesCatalogScreen(
    services: List<ServiceCatalogItem>,
    branches: List<Branch>,
    currentUser: User?,
    selectedBranch: Branch?,
    onSaveService: (ServiceCatalogItem) -> Unit,
    onUpdateService: (ServiceCatalogItem) -> Unit,
    onToggleServiceStatus: (ServiceCatalogItem) -> Unit,
    onDeleteService: (String) -> Unit,
    onRequestServiceBooking: (ServiceCatalogItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Catálogo Digital, 1: Gestão de Serviços
    var selectedCategoryFilter by remember { mutableStateOf("Todas") }
    var searchQuery by remember { mutableStateOf("") }
    var showAddEditDialog by remember { mutableStateOf(false) }
    var serviceToEdit by remember { mutableStateOf<ServiceCatalogItem?>(null) }
    var serviceToDelete by remember { mutableStateOf<ServiceCatalogItem?>(null) }
    var selectedServiceForDetail by remember { mutableStateOf<ServiceCatalogItem?>(null) }

    val defaultCategories = listOf(
        "Todas",
        "Lavagem automotiva",
        "Higienização interna",
        "Polimento",
        "Enceramento",
        "Proteção de pintura",
        "Cristalização",
        "Outros serviços"
    )

    val dynamicCategories = remember(services) {
        val custom = services.map { it.category }.distinct()
        (defaultCategories + custom).distinct()
    }

    // Filter services based on search & category
    val filteredServices = remember(services, searchQuery, selectedCategoryFilter, selectedTab) {
        services.filter { srv ->
            val matchesCategory = selectedCategoryFilter == "Todas" || srv.category.equals(selectedCategoryFilter, ignoreCase = true)
            val matchesQuery = searchQuery.isBlank() ||
                    srv.name.contains(searchQuery, ignoreCase = true) ||
                    srv.code.contains(searchQuery, ignoreCase = true) ||
                    srv.description.contains(searchQuery, ignoreCase = true)

            // No Catálogo Digital mostramos apenas serviços ativos; na Gestão mostramos todos
            val matchesActive = if (selectedTab == 0) srv.isActive else true

            matchesCategory && matchesQuery && matchesActive
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TayleNavy950,
        floatingActionButton = {
            if (selectedTab == 1 || currentUser?.role == UserRole.ADMINISTRADOR || currentUser?.role == UserRole.GERENTE) {
                ExtendedFloatingActionButton(
                    onClick = {
                        serviceToEdit = null
                        showAddEditDialog = true
                    },
                    containerColor = TayleCyan,
                    contentColor = TayleNavy950,
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("Novo Serviço", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("fab_new_service")
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Serviços & Catálogo",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Text(
                        text = if (selectedBranch != null) "Tabela de Preços: ${selectedBranch.name}" else "Visão Matriz Consolidada",
                        fontSize = 12.sp,
                        color = TayleSlateLight
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleCyan.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, TayleCyan.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = "${services.count { it.isActive }} Ativos",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tab Bar: 0 - Catálogo Digital, 1 - Gestão e Cadastro
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = TayleNavy900,
                contentColor = TayleCyan,
                divider = { HorizontalDivider(color = TayleNavy700) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AutoStories, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Catálogo Digital", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.SettingsSuggest, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gestão de Preços", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Buscar serviço por nome, código ou benefício...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Buscar", tint = TayleSlateLight) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Limpar", tint = TayleSlateLight)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("service_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TayleCyan,
                    unfocusedBorderColor = TayleNavy700,
                    focusedTextColor = TayleWhite,
                    unfocusedTextColor = TayleWhite,
                    focusedContainerColor = TayleNavy900,
                    unfocusedContainerColor = TayleNavy900
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(dynamicCategories) { category ->
                    val isSelected = selectedCategoryFilter == category
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategoryFilter = category },
                        label = { Text(category, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TayleCyan,
                            selectedLabelColor = TayleNavy950,
                            containerColor = TayleNavy800,
                            labelColor = TayleWhite
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Content List
            if (filteredServices.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.DesignServices,
                            contentDescription = null,
                            tint = TayleSlateLight,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Nenhum serviço encontrado",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleWhite
                        )
                        Text(
                            text = "Cadastre um novo serviço com preço e categoria.",
                            fontSize = 12.sp,
                            color = TayleSlateLight
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 72.dp)
                ) {
                    items(filteredServices, key = { it.id }) { service ->
                        if (selectedTab == 0) {
                            // Professional Digital Catalog Card
                            DigitalCatalogCard(
                                service = service,
                                onContractClick = { onRequestServiceBooking(service) },
                                onCardClick = { selectedServiceForDetail = service }
                            )
                        } else {
                            // Management & Pricing Table Card
                            ServiceManagementCard(
                                service = service,
                                onEditClick = {
                                    serviceToEdit = service
                                    showAddEditDialog = true
                                },
                                onToggleStatus = { onToggleServiceStatus(service) },
                                onDeleteClick = { serviceToDelete = service }
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal de Cadastro / Edição de Serviço (Item 1)
    if (showAddEditDialog) {
        AddEditServiceDialog(
            service = serviceToEdit,
            branches = branches,
            defaultBranch = selectedBranch ?: branches.firstOrNull(),
            companyId = currentUser?.companyId ?: "comp_matriz",
            onDismiss = { showAddEditDialog = false },
            onSave = { savedService ->
                if (serviceToEdit != null) {
                    onUpdateService(savedService)
                    Toast.makeText(context, "Serviço atualizado com sucesso!", Toast.LENGTH_SHORT).show()
                } else {
                    onSaveService(savedService)
                    Toast.makeText(context, "Serviço cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                }
                showAddEditDialog = false
            }
        )
    }

    // Confirmação de Exclusão
    if (serviceToDelete != null) {
        AlertDialog(
            onDismissRequest = { serviceToDelete = null },
            containerColor = TayleNavy900,
            title = {
                Text("Desativar ou Excluir Serviço?", color = TayleWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Deseja remover o serviço ${serviceToDelete?.name} (${serviceToDelete?.code})? Você também pode apenas desativá-lo para que não apareça no catálogo digital.",
                    color = TayleSlateLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        serviceToDelete?.let { onDeleteService(it.id) }
                        serviceToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TayleRedLight, contentColor = TayleWhite)
                ) {
                    Text("Excluir Permanentemente")
                }
            },
            dismissButton = {
                TextButton(onClick = { serviceToDelete = null }) {
                    Text("Cancelar", color = TayleSlateLight)
                }
            }
        )
    }

    // Modal Detalhes do Serviço
    if (selectedServiceForDetail != null) {
        ServiceDetailModal(
            service = selectedServiceForDetail!!,
            onDismiss = { selectedServiceForDetail = null },
            onContract = {
                onRequestServiceBooking(selectedServiceForDetail!!)
                selectedServiceForDetail = null
            }
        )
    }
}

@Composable
fun DigitalCatalogCard(
    service: ServiceCatalogItem,
    onContractClick: () -> Unit,
    onCardClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = TayleNavy900,
        border = BorderStroke(1.dp, TayleNavy700),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("catalog_card_${service.code}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Category & Code Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = TayleCyan.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = service.category.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Text(
                    text = service.code,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TayleSlateLight
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Service Title & Banner Highlight
            Text(
                text = service.name,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TayleWhite
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Description
            Text(
                text = service.description,
                fontSize = 12.sp,
                color = TayleSlateLight,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            // Benefits Highlight (Marcadores destacados)
            if (service.benefits.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleNavy800,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "BENEFÍCIOS DESTAQUE:",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleAmber,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        service.benefits.lines().take(3).forEach { benefit ->
                            if (benefit.isNotBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = TayleGreen,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = benefit.removePrefix("•").trim(),
                                        fontSize = 11.sp,
                                        color = TayleWhite,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = TayleNavy700, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(8.dp))

            // Price & Contract Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Valor do Serviço:",
                        fontSize = 10.sp,
                        color = TayleSlateLight
                    )
                    Text(
                        text = "R$ ${"%,.2f".format(Locale.GERMANY, service.salePrice)}",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        color = TayleGreen
                    )
                }

                Button(
                    onClick = onContractClick,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TayleCyan,
                        contentColor = TayleNavy950
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("btn_contract_${service.code}")
                ) {
                    Icon(
                        imageVector = if (service.requiresVehicleInspection) Icons.Filled.CalendarMonth else Icons.Filled.AddShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (service.requiresVehicleInspection) "Solicitar Orçamento" else "Contratar Serviço",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun ServiceManagementCard(
    service: ServiceCatalogItem,
    onEditClick: () -> Unit,
    onToggleStatus: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = TayleNavy900,
        border = BorderStroke(1.dp, if (service.isActive) TayleNavy700 else TayleRedLight.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = service.code,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (service.isActive) TayleGreen.copy(alpha = 0.2f) else TayleRedLight.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = if (service.isActive) "ATIVO" else "INATIVO",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (service.isActive) TayleGreen else TayleRedLight,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = service.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TayleWhite
                )

                Text(
                    text = "${service.category} • Unidade: ${service.branchName.replace("Filial ", "")}",
                    fontSize = 11.sp,
                    color = TayleSlateLight
                )

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Venda: R$ ${"%,.2f".format(Locale.GERMANY, service.salePrice)} (Custo: R$ ${"%,.2f".format(Locale.GERMANY, service.costPrice)})",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TayleGreen
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onToggleStatus,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (service.isActive) Icons.Filled.ToggleOn else Icons.Filled.ToggleOff,
                        contentDescription = "Ativar/Desativar",
                        tint = if (service.isActive) TayleCyan else TayleSlateLight,
                        modifier = Modifier.size(24.dp)
                    )
                }

                IconButton(
                    onClick = onEditClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Edit,
                        contentDescription = "Editar",
                        tint = TayleWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "Excluir",
                        tint = TayleRedLight,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditServiceDialog(
    service: ServiceCatalogItem?,
    branches: List<Branch>,
    defaultBranch: Branch?,
    companyId: String,
    onDismiss: () -> Unit,
    onSave: (ServiceCatalogItem) -> Unit
) {
    var name by remember { mutableStateOf(service?.name ?: "") }
    var code by remember { mutableStateOf(service?.code ?: "SRV-${(100 + (Math.random() * 900).toInt())}") }
    var category by remember { mutableStateOf(service?.category ?: "Lavagem automotiva") }
    var description by remember { mutableStateOf(service?.description ?: "") }
    var benefits by remember { mutableStateOf(service?.benefits ?: "• Proteção duradoura\n• Acabamento de alto brilho\n• Garantia Tayle") }
    var salePriceText by remember { mutableStateOf(service?.salePrice?.let { "%.2f".format(Locale.US, it) } ?: "150.00") }
    var costPriceText by remember { mutableStateOf(service?.costPrice?.let { "%.2f".format(Locale.US, it) } ?: "40.00") }
    var isActive by remember { mutableStateOf(service?.isActive ?: true) }
    var requiresInspection by remember { mutableStateOf(service?.requiresVehicleInspection ?: false) }
    var selectedBranch by remember { mutableStateOf(branches.find { it.id == service?.branchId } ?: defaultBranch ?: branches.firstOrNull()) }

    val categories = listOf(
        "Lavagem automotiva",
        "Higienização interna",
        "Polimento",
        "Enceramento",
        "Proteção de pintura",
        "Cristalização",
        "Mecânica Rápida",
        "Outros serviços"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Text(
                text = if (service != null) "Editar Serviço" else "Cadastrar Novo Serviço",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TayleWhite
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nome do Serviço *") },
                        placeholder = { Text("Ex: Polimento Técnico Cristalizado") },
                        modifier = Modifier.fillMaxWidth().testTag("service_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = it.uppercase() },
                            label = { Text("Código / ID *") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )

                        OutlinedTextField(
                            value = salePriceText,
                            onValueChange = { salePriceText = it },
                            label = { Text("Preço Venda (R$) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }
                }

                item {
                    Text("Categoria do Serviço:", fontSize = 11.sp, color = TayleSlateLight)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TayleCyan,
                                    selectedLabelColor = TayleNavy950,
                                    containerColor = TayleNavy800,
                                    labelColor = TayleWhite
                                )
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Descrição Detalhada") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = benefits,
                        onValueChange = { benefits = it },
                        label = { Text("Benefícios (um por linha)") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    Text("Unidade Responsável:", fontSize = 11.sp, color = TayleSlateLight)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(branches) { branch ->
                            FilterChip(
                                selected = selectedBranch?.id == branch.id,
                                onClick = { selectedBranch = branch },
                                label = { Text(branch.name.replace("Filial ", ""), fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TayleCyan,
                                    selectedLabelColor = TayleNavy950,
                                    containerColor = TayleNavy800,
                                    labelColor = TayleWhite
                                )
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Exige Avaliação / Vistoria Prévia?", fontSize = 12.sp, color = TayleWhite)
                        Switch(
                            checked = requiresInspection,
                            onCheckedChange = { requiresInspection = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = TayleCyan)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Status: Ativo no Catálogo?", fontSize = 12.sp, color = TayleWhite)
                        Switch(
                            checked = isActive,
                            onCheckedChange = { isActive = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = TayleCyan)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && code.isNotBlank()) {
                        val finalService = ServiceCatalogItem(
                            id = service?.id ?: UUID.randomUUID().toString(),
                            companyId = companyId,
                            branchId = selectedBranch?.id ?: "branch_sp_matriz",
                            branchName = selectedBranch?.name ?: "Matriz São Paulo",
                            code = code.trim(),
                            name = name.trim(),
                            description = description.trim(),
                            benefits = benefits.trim(),
                            category = category,
                            salePrice = salePriceText.toDoubleOrNull() ?: 150.0,
                            costPrice = costPriceText.toDoubleOrNull() ?: 40.0,
                            isActive = isActive,
                            requiresVehicleInspection = requiresInspection,
                            createdAt = service?.createdAt ?: System.currentTimeMillis(),
                            updatedAt = System.currentTimeMillis()
                        )
                        onSave(finalService)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                enabled = name.isNotBlank() && code.isNotBlank()
            ) {
                Text("Salvar Serviço", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceDetailModal(
    service: ServiceCatalogItem,
    onDismiss: () -> Unit,
    onContract: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = TayleCyan.copy(alpha = 0.15f)
            ) {
                Text(
                    text = "${service.category.uppercase()} • ${service.code}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TayleCyan,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = service.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = service.description, fontSize = 13.sp, color = TayleSlateLight)

            Spacer(modifier = Modifier.height(14.dp))
            Text(text = "Vantagens e Benefícios:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleAmber)
            Spacer(modifier = Modifier.height(6.dp))

            service.benefits.lines().forEach { b ->
                if (b.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = TayleGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = b.removePrefix("•").trim(), fontSize = 12.sp, color = TayleWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Preço de Venda:", fontSize = 11.sp, color = TayleSlateLight)
                    Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, service.salePrice)}", fontSize = 20.sp, fontWeight = FontWeight.Black, color = TayleGreen)
                }

                Button(
                    onClick = onContract,
                    colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950)
                ) {
                    Text(if (service.requiresVehicleInspection) "Solicitar Orçamento" else "Contratar Serviço", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
