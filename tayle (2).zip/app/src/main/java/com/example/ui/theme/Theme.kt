package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = TayleCobalt,
    onPrimary = Color.White,
    primaryContainer = TayleNavy700,
    onPrimaryContainer = TayleCyan,
    secondary = TayleCyan,
    onSecondary = TayleNavy900,
    secondaryContainer = TayleNavy700,
    onSecondaryContainer = Color.White,
    tertiary = TayleEmerald,
    onTertiary = Color.White,
    background = TayleNavy900,
    onBackground = TayleTextPrimary,
    surface = TayleNavy800,
    onSurface = TayleTextPrimary,
    surfaceVariant = TayleCardDark,
    onSurfaceVariant = TayleTextSecondary,
    error = TayleRose,
    onError = Color.White,
    outline = TayleSlateBorder,
    outlineVariant = TayleNavy700
)

private val LightColorScheme = lightColorScheme(
    primary = TayleCobalt,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE6FF),
    onPrimaryContainer = Color(0xFF00194A),
    secondary = Color(0xFF00687A),
    onSecondary = Color.White,
    tertiary = TayleEmeraldDark,
    onTertiary = Color.White,
    background = TayleLightBg,
    onBackground = TayleLightTextPrimary,
    surface = TayleLightSurface,
    onSurface = TayleLightTextPrimary,
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = TayleLightTextSecondary,
    error = TayleRose,
    onError = Color.White,
    outline = TayleLightBorder,
    outlineVariant = Color(0xFFCBD5E1)
)

@Composable
fun TayleTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme: ColorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            window.navigationBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
