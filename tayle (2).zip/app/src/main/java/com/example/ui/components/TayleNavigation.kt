package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Company
import com.example.data.model.User
import com.example.ui.theme.*

@Composable
fun TayleBottomNavigation(
    currentRoute: String,
    currentUser: User?,
    onNavigate: (TayleNavDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val destinations = listOf(
        TayleNavDestination.DASHBOARD,
        TayleNavDestination.SERVICE_ORDERS,
        TayleNavDestination.MATERIALS_STOCK,
        TayleNavDestination.VEHICLES,
        TayleNavDestination.TAYLE_AI
    )

    NavigationBar(
        modifier = modifier.testTag("tayle_bottom_navigation"),
        containerColor = TayleNavy900,
        contentColor = TayleTextPrimary,
        tonalElevation = 8.dp
    ) {
        destinations.forEach { dest ->
            val selected = currentRoute == dest.route ||
                    (dest == TayleNavDestination.MATERIALS_STOCK && (currentRoute == "estoque" || currentRoute == "materials_stock"))

            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(dest) },
                icon = {
                    BadgedBox(
                        badge = {
                            if (dest.badge != null && dest == TayleNavDestination.MATERIALS_STOCK) {
                                Badge(
                                    containerColor = TayleAmber,
                                    contentColor = TayleNavy950
                                ) {
                                    Text("NOVO", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                            contentDescription = dest.title,
                            tint = if (selected) TayleCyan else if (dest == TayleNavDestination.MATERIALS_STOCK) TayleAmber else TayleSlateLight
                        )
                    }
                },
                label = {
                    Text(
                        text = if (dest == TayleNavDestination.MATERIALS_STOCK) "Estoque" else dest.title.take(9),
                        fontSize = 10.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        color = if (selected) TayleCyan else TayleSlateLight
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = TayleNavy700,
                    selectedIconColor = TayleCyan,
                    unselectedIconColor = TayleSlateLight
                )
            )
        }
    }
}

@Composable
fun TayleSidebarDrawerContent(
    currentRoute: String,
    currentUser: User?,
    currentCompany: Company?,
    onNavigate: (TayleNavDestination) -> Unit,
    onCompanySwitchClick: () -> Unit,
    onLogoutClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val userRoleLevel = currentUser?.role?.level ?: 1
    val destinations = TayleNavDestination.entries.filter { it.minRole.level <= userRoleLevel }

    ModalDrawerSheet(
        modifier = modifier.width(310.dp),
        drawerContainerColor = TayleNavy900,
        drawerContentColor = TayleTextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header: Brand & Platform Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(TayleCyan, TayleNavy500)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "T",
                        fontWeight = FontWeight.Black,
                        fontSize = 26.sp,
                        color = TayleNavy950
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "TAYLE",
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp,
                            color = TayleWhite,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = TayleCyan.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "AUTO",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TayleCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = "Marketing, Vendas & Gestão",
                        fontSize = 11.sp,
                        color = TayleSlateLight
                    )
                }
            }

            // Company & Tenant Context Box
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = TayleNavy800,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clickable { onCompanySwitchClick() }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(TayleNavy700),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Business,
                            contentDescription = "Empresa",
                            tint = TayleCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentCompany?.name ?: "Empresa Principal",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = currentCompany?.plan ?: "Plano Ativo",
                            fontSize = 11.sp,
                            color = TayleSlateLight
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.SwapHoriz,
                        contentDescription = "Trocar",
                        tint = TayleSlateLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            HorizontalDivider(
                color = TayleNavy700,
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Section Label
            Text(
                text = "MENU PRINCIPAL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TayleSlateLight,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )

            // Navigation Destinations List
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(destinations) { dest ->
                    val isSelected = currentRoute == dest.route ||
                            (dest == TayleNavDestination.MATERIALS_STOCK && (currentRoute == "estoque" || currentRoute == "materials_stock"))

                    val isStock = dest == TayleNavDestination.MATERIALS_STOCK

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = when {
                            isSelected -> TayleCyan.copy(alpha = 0.15f)
                            isStock -> TayleAmber.copy(alpha = 0.08f)
                            else -> Color.Transparent
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(dest) }
                            .testTag("nav_item_${dest.route}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                contentDescription = dest.title,
                                tint = when {
                                    isSelected -> TayleCyan
                                    isStock -> TayleAmber
                                    else -> TayleSlateLight
                                },
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Text(
                                text = dest.title,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected || isStock) FontWeight.Bold else FontWeight.Medium,
                                color = when {
                                    isSelected -> TayleCyan
                                    isStock -> TayleAmber
                                    else -> TayleWhite
                                },
                                modifier = Modifier.weight(1f)
                            )
                            if (dest.badge != null) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isStock) TayleAmber else TayleNavy700
                                ) {
                                    Text(
                                        text = dest.badge,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isStock) TayleNavy950 else TayleSlateLight,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(
                color = TayleNavy700,
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // User Profile Summary & Logout
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(TayleCyan.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentUser?.name?.take(1)?.uppercase() ?: "U",
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentUser?.name ?: "Usuário",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentUser?.role?.label ?: "Operador",
                        fontSize = 11.sp,
                        color = TayleSlateLight
                    )
                }
                IconButton(
                    onClick = onLogoutClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ExitToApp,
                        contentDescription = "Sair",
                        tint = TayleRedLight,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
