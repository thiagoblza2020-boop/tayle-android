package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.data.model.UserRole

enum class TayleNavDestination(
    val title: String,
    val route: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val minRole: UserRole = UserRole.OPERADOR,
    val badge: String? = null
) {
    DASHBOARD(
        title = "Dashboard",
        route = "dashboard",
        selectedIcon = Icons.Filled.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        minRole = UserRole.OPERADOR
    ),
    SERVICE_ORDERS(
        title = "Ordens de Serviço",
        route = "service_orders",
        selectedIcon = Icons.Filled.Assignment,
        unselectedIcon = Icons.Outlined.Assignment,
        minRole = UserRole.OPERADOR,
        badge = "Ativas"
    ),
    SERVICES_CATALOG(
        title = "Serviços & Catálogo",
        route = "services_catalog",
        selectedIcon = Icons.Filled.DesignServices,
        unselectedIcon = Icons.Outlined.DesignServices,
        minRole = UserRole.OPERADOR,
        badge = "Catálogo"
    ),
    VIRTUAL_STORE(
        title = "Loja Virtual",
        route = "virtual_store",
        selectedIcon = Icons.Filled.Storefront,
        unselectedIcon = Icons.Outlined.Storefront,
        minRole = UserRole.OPERADOR,
        badge = "Loja"
    ),
    MATERIALS_STOCK(
        title = "📦 Estoque",
        route = "estoque",
        selectedIcon = Icons.Filled.Inventory2,
        unselectedIcon = Icons.Outlined.Inventory2,
        minRole = UserRole.OPERADOR,
        badge = "Insumos"
    ),
    VEHICLES(
        title = "Pátio & Veículos",
        route = "vehicles",
        selectedIcon = Icons.Filled.DirectionsCar,
        unselectedIcon = Icons.Outlined.DirectionsCar,
        minRole = UserRole.OPERADOR
    ),
    TAYLE_AI(
        title = "TAYLE IA",
        route = "tayle_ai",
        selectedIcon = Icons.Filled.AutoAwesome,
        unselectedIcon = Icons.Outlined.AutoAwesome,
        minRole = UserRole.OPERADOR,
        badge = "IA"
    ),
    PROFILE(
        title = "Meu Perfil",
        route = "profile",
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person,
        minRole = UserRole.OPERADOR
    ),
    SETTINGS(
        title = "Configurações",
        route = "settings",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        minRole = UserRole.GERENTE
    );

    companion object {
        fun fromRoute(rawRoute: String): TayleNavDestination {
            val clean = rawRoute.trim().removePrefix("/").lowercase()
            return when (clean) {
                "vehicles", "patio", "clientes" -> VEHICLES
                "service_orders", "os", "orders" -> SERVICE_ORDERS
                "services_catalog", "servicos", "catalogo", "catalog" -> SERVICES_CATALOG
                "virtual_store", "loja", "loja_virtual", "store", "ecommerce" -> VIRTUAL_STORE
                "estoque", "materials_stock", "materials", "stock" -> MATERIALS_STOCK
                "tayle_ai", "ai", "marketing" -> TAYLE_AI
                "profile", "perfil" -> PROFILE
                "settings", "configuracoes" -> SETTINGS
                else -> DASHBOARD
            }
        }
    }
}
