package com.example.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Company
import com.example.data.model.UserRole
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    company: Company?,
    userRole: UserRole,
    onSwitchCompany: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(16.dp)
            .testTag("settings_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Configurações do Sistema",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TayleWhite
            )
            Text(
                text = "Parâmetros corporativos, plano e integrações",
                style = MaterialTheme.typography.bodySmall,
                color = TayleSlateLight
            )
        }

        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Plano da Empresa", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TayleWhite)
                        Surface(shape = RoundedCornerShape(6.dp), color = TayleCyan.copy(alpha = 0.2f)) {
                            Text("ATIVO", color = TayleCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = company?.plan ?: "Master R$ 99,90",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan
                    )
                    Text(
                        text = "Acesso completo a CRM, O.S., Pátio, Estoque de Materiais, IA Ilimitada e Múltiplas Filiais.",
                        fontSize = 12.sp,
                        color = TayleSlateLight
                    )

                    HorizontalDivider(color = TayleNavy800, modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Filiais Habilitadas", color = TayleSlateLight, fontSize = 12.sp)
                        Text("${company?.branchesCount ?: 1} filiais", color = TayleWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            Text(
                text = "OPÇÕES DA CONTA",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TayleSlateLight,
                letterSpacing = 1.sp
            )
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = TayleNavy900,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSwitchCompany() }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.SwapHoriz, contentDescription = null, tint = TayleCyan)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Alternar Filial ou Matriz", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TayleWhite)
                        Text("Carregar registros de outra unidade", fontSize = 11.sp, color = TayleSlateLight)
                    }
                    Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = TayleSlateLight)
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.CloudSync, contentDescription = null, tint = TayleGreen)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Sincronização em Nuvem", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TayleWhite)
                        Text("Banco de dados SQLite Room e isolamento multi-tenant", fontSize = 11.sp, color = TayleSlateLight)
                    }
                    Switch(checked = true, onCheckedChange = {})
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Security, contentDescription = null, tint = TayleAmber)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Nível de Permissão", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = TayleWhite)
                        Text("Perfil ativo: ${userRole.label}", fontSize = 11.sp, color = TayleSlateLight)
                    }
                }
            }
        }
    }
}
