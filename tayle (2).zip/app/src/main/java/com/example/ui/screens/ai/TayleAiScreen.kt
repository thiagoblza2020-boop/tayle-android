package com.example.ui.screens.ai

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun TayleAiScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val templates = remember {
        listOf(
            AiTemplate(
                title = "Mensagem WhatsApp O.S. Pronta",
                description = "Aviso amigável ao cliente com detalhes do veículo e retirada",
                category = "Pós-Vendas",
                defaultPrompt = "Gerar mensagem de WhatsApp avisando que o veículo Toyota Corolla placa BRA2E19 está pronto para retirada após revisão completa.",
                sampleResult = "Olá, Roberto! Tudo bem? Aqui é da TAYLE Motors.\n\nTemos uma ótima notícia: o seu Corolla (BRA2E19) já teve a revisão concluída com sucesso e passou por todo o nosso checklist de qualidade! 🚗✨\n\nEle já está higienizado e pronto para retirada em nossa unidade. Ficamos no aguardo da sua visita!"
            ),
            AiTemplate(
                title = "Proposta Comercial de Revisão Preventiva",
                description = "Texto comercial persuasivo para clientes com revisão atrasada",
                category = "Vendas",
                defaultPrompt = "Criar mensagem comercial convidando o cliente para troca de óleo e checagem de freios com condição especial.",
                sampleResult = "Olá! Notamos que faz 6 meses desde a sua última manutenção na TAYLE. Cuidar preventivamente do seu veículo evita surpresas na estrada e preserva o valor do seu carro.\n\nNeste mês, clientes VIP têm check-up eletrônico gratuito na troca de óleo e pastilhas. Podemos agendar para esta semana?"
            ),
            AiTemplate(
                title = "Campanha Instagram: Revisão de Férias",
                description = "Post promocional com gancho de segurança e viagem",
                category = "Marketing",
                defaultPrompt = "Criar legenda para post de redes sociais sobre revisão de segurança antes de viajar com a família.",
                sampleResult = "Vai pegar a estrada no final de semana? 🛣️\n\nA segurança da sua família não pode depender da sorte. Passe na TAYLE e faça o Check-up Completo em 30 minutos: freios, suspensão, fluidos, iluminação e pneus.\n\nDirija tranquilo. Agende pelo link da bio ou chame no WhatsApp!"
            ),
            AiTemplate(
                title = "Follow-up de Orçamento Aberto",
                description = "Retomada com cliente que recebeu orçamento mas não aprovou",
                category = "Vendas",
                defaultPrompt = "Elaborar follow-up respeitoso para orçamento de troca de amortecedores enviado ontem.",
                sampleResult = "Olá, tudo bem? Só passando para saber se você conseguiu avaliar o orçamento que enviamos ontem para a manutenção do seu veículo. Se tiver qualquer dúvida sobre as peças ou condições de pagamento parcelado, estamos à inteira disposição!"
            )
        )
    }

    var selectedTemplate by remember { mutableStateOf<AiTemplate?>(templates.first()) }
    var promptInput by remember { mutableStateOf(templates.first().defaultPrompt) }
    var generatedResponse by remember { mutableStateOf(templates.first().sampleResult) }
    var isGenerating by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(16.dp)
            .testTag("tayle_ai_screen")
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = null,
                tint = TayleCyan,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "TAYLE IA — Marketing & Vendas",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TayleWhite
                )
                Text(
                    text = "Gere estratégias, mensagens, anúncios e follow-ups comerciais",
                    style = MaterialTheme.typography.bodySmall,
                    color = TayleSlateLight
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Templates Scroll
        Text(
            text = "TEMPLATES PRONTOS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TayleSlateLight,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(templates) { item ->
                val isSelected = selectedTemplate == item
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) TayleCyan.copy(alpha = 0.2f) else TayleNavy900,
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, TayleCyan) else null,
                    modifier = Modifier.clickable {
                        selectedTemplate = item
                        promptInput = item.defaultPrompt
                        generatedResponse = item.sampleResult
                    }
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = item.category.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleCyan
                        )
                        Text(
                            text = item.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleWhite
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Input Prompt Field
        OutlinedTextField(
            value = promptInput,
            onValueChange = { promptInput = it },
            label = { Text("Instrução para a IA Comercial") },
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 90.dp),
            minLines = 2,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TayleCyan,
                unfocusedBorderColor = TayleNavy700,
                focusedTextColor = TayleWhite,
                unfocusedTextColor = TayleWhite
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                isGenerating = true
                generatedResponse = if (selectedTemplate != null && promptInput.contains(selectedTemplate!!.title, ignoreCase = true)) {
                    selectedTemplate!!.sampleResult
                } else {
                    "✨ Estratégia Comercial Gerada pela TAYLE IA:\n\n" +
                            "\"Prezado cliente, identificamos a oportunidade de potencializar a performance e longevidade do seu veículo com o plano preventivo TAYLE.\n\n" +
                            "Destaques:\n• Atendimento exclusivo e peças genuínas com garantia\n• Diagnóstico eletrônico com scanner de última geração\n• Condições especiais de pagamento em até 6x sem juros\n\nEntre em contato conosco e garanta seu horário!\""
                }
                isGenerating = false
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = TayleCyan,
                contentColor = TayleNavy950
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Gerar Conteúdo Comercial com IA", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Result Card
        Text(
            text = "RESULTADO GERADO",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TayleSlateLight,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = TayleNavy900,
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Texto Pronto para Uso", fontSize = 12.sp, color = TayleCyan, fontWeight = FontWeight.Bold)
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(generatedResponse))
                            Toast.makeText(context, "Texto copiado para a área de transferência!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Filled.ContentCopy, contentDescription = "Copiar", tint = TayleCyan, modifier = Modifier.size(18.dp))
                    }
                }

                HorizontalDivider(color = TayleNavy800, modifier = Modifier.padding(vertical = 8.dp))

                LazyColumn(modifier = Modifier.weight(1f)) {
                    item {
                        Text(
                            text = generatedResponse,
                            fontSize = 13.sp,
                            color = TayleWhite,
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }
    }
}
