package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompanySwitcherSheet(
    companies: List<Company>,
    currentCompany: Company?,
    onCompanySelected: (Company) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Alternar Empresa / Filial",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TayleWhite
            )
            Text(
                text = "Selecione a unidade comercial para carregar os dados:",
                style = MaterialTheme.typography.bodyMedium,
                color = TayleSlateLight,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(companies) { company ->
                    val isSelected = company.id == currentCompany?.id
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) TayleCyan.copy(alpha = 0.15f) else TayleNavy800,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, TayleCyan) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onCompanySelected(company)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) TayleCyan else TayleNavy700),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Business,
                                    contentDescription = null,
                                    tint = if (isSelected) TayleNavy950 else TayleSlateLight
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = company.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleWhite
                                )
                                Text(
                                    text = "${company.segment} • ${company.branchesCount} filiais",
                                    fontSize = 11.sp,
                                    color = TayleSlateLight
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Selecionada",
                                    tint = TayleCyan
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RolePermissionSheet(
    currentRole: UserRole,
    onRoleSelected: (UserRole) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(
                text = "Níveis de Acesso e Permissões",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TayleWhite
            )
            Text(
                text = "O sistema TAYLE aplica controle estrito baseado em papéis (RBAC). No modo de demonstração, alterne entre perfis:",
                style = MaterialTheme.typography.bodyMedium,
                color = TayleSlateLight,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(UserRole.entries) { role ->
                    val isSelected = role == currentRole
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) TayleCyan.copy(alpha = 0.15f) else TayleNavy800,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, TayleCyan) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                onRoleSelected(role)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RoleBadge(role = role)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Nível ${role.level} - ${role.label}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleWhite
                                )
                                Text(
                                    text = when (role) {
                                        UserRole.ADMINISTRADOR -> "Acesso irrestrito a configurações, metas, estoque e finanças"
                                        UserRole.GERENTE -> "Gestão de equipe, aprovação de ordens e suprimentos"
                                        UserRole.SUPERVISOR -> "Coordenação de pátio, O.S. e movimentação de materiais"
                                        UserRole.OPERADOR -> "Execução técnica, apontamento de checklist e consumo de peças"
                                    },
                                    fontSize = 11.sp,
                                    color = TayleSlateLight
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewServiceOrderSheet(
    companyId: String,
    catalogServices: List<ServiceCatalogItem> = emptyList(),
    onSave: (ServiceOrder) -> Unit,
    onDismiss: () -> Unit
) {
    var plate by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("Toyota") }
    var model by remember { mutableStateOf("Corolla XEi 2.0") }
    var yearText by remember { mutableStateOf("2024") }
    var color by remember { mutableStateOf("Preto") }
    var chassis by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf(OsPriority.NORMAL) }
    var technicianName by remember { mutableStateOf("Lucas Meireles") }
    var discountText by remember { mutableStateOf("0.00") }
    var notes by remember { mutableStateOf("") }

    // Selected Services List
    val selectedServices = remember {
        mutableStateListOf<ServiceOrderItem>().apply {
            if (catalogServices.isNotEmpty()) {
                val firstSrv = catalogServices.first()
                add(
                    ServiceOrderItem(
                        serviceId = firstSrv.id,
                        serviceName = firstSrv.name,
                        description = firstSrv.description,
                        quantity = 1,
                        unitPrice = firstSrv.salePrice
                    )
                )
            } else {
                add(
                    ServiceOrderItem(
                        serviceId = "srv_default",
                        serviceName = "Revisão e Diagnóstico Geral",
                        description = "Inspeção veicular e check-up",
                        quantity = 1,
                        unitPrice = 350.00
                    )
                )
            }
        }
    }

    val subtotal = selectedServices.sumOf { it.quantity * it.unitPrice }
    val discount = discountText.toDoubleOrNull() ?: 0.0
    val calculatedTotal = (subtotal - discount).coerceAtLeast(0.0)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Nova Ordem de Serviço (O.S.)",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TayleWhite
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = TayleCyan.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "AUTOMÁTICA",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Section 1: Identificação do Veículo
                item {
                    Text(
                        text = "1. IDENTIFICAÇÃO DO VEÍCULO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    BrandModelSelector(
                        selectedBrand = brand,
                        selectedModel = model,
                        onBrandSelected = { brand = it },
                        onModelSelected = { model = it }
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = plate,
                            onValueChange = { plate = it.uppercase().take(8) },
                            label = { Text("Placa *") },
                            placeholder = { Text("ABC1D23") },
                            modifier = Modifier.weight(1f).testTag("os_plate_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = yearText,
                            onValueChange = { yearText = it },
                            label = { Text("Ano") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = color,
                            onValueChange = { color = it },
                            label = { Text("Cor") },
                            modifier = Modifier.weight(0.9f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = chassis,
                        onValueChange = { chassis = it.uppercase() },
                        label = { Text("Chassi (opcional)") },
                        placeholder = { Text("Ex: 9BRBL...") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                // Section 2: Dados do Cliente
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "2. DADOS DO CLIENTE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Nome do Cliente *") },
                            modifier = Modifier.weight(1.2f).testTag("os_client_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = customerPhone,
                            onValueChange = { customerPhone = it },
                            label = { Text("WhatsApp") },
                            placeholder = { Text("(11) 99999-9999") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }
                }

                // Section 3: Serviços Solicitados
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "3. SERVIÇOS DA O.S. (INTEGRADO AO CADASTRO)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleCyan,
                            letterSpacing = 1.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))

                    // Available catalog chips to quickly add services
                    if (catalogServices.isNotEmpty()) {
                        Text(text = "Adicionar serviço cadastrado:", fontSize = 10.sp, color = TayleSlateLight)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(catalogServices) { srv ->
                                FilterChip(
                                    selected = false,
                                    onClick = {
                                        selectedServices.add(
                                            ServiceOrderItem(
                                                serviceId = srv.id,
                                                serviceName = srv.name,
                                                description = srv.description,
                                                quantity = 1,
                                                unitPrice = srv.salePrice
                                            )
                                        )
                                    },
                                    label = { Text("+ ${srv.name.take(18)}... (R$ ${"%,.0f".format(Locale.GERMANY, srv.salePrice)})", fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        containerColor = TayleNavy800,
                                        labelColor = TayleCyan
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // Selected services list with qty and unit price
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        selectedServices.forEachIndexed { index, item ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = TayleNavy800,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = item.serviceName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                                        Text(
                                            text = "${item.quantity}x R$ ${"%,.2f".format(Locale.GERMANY, item.unitPrice)} = R$ ${"%,.2f".format(Locale.GERMANY, item.total)}",
                                            fontSize = 11.sp,
                                            color = TayleGreen
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                if (item.quantity > 1) {
                                                    selectedServices[index] = item.copy(quantity = item.quantity - 1)
                                                } else {
                                                    selectedServices.removeAt(index)
                                                }
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Filled.Remove, contentDescription = null, tint = TayleWhite, modifier = Modifier.size(14.dp))
                                        }

                                        Text(
                                            text = "${item.quantity}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TayleWhite,
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        )

                                        IconButton(
                                            onClick = {
                                                selectedServices[index] = item.copy(quantity = item.quantity + 1)
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Filled.Add, contentDescription = null, tint = TayleWhite, modifier = Modifier.size(14.dp))
                                        }

                                        IconButton(
                                            onClick = { selectedServices.removeAt(index) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Filled.Close, contentDescription = "Remover", tint = TayleRedLight, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 4: Desconto & Totais
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = discountText,
                            onValueChange = { discountText = it },
                            label = { Text("Desconto Autorizado (R$)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TayleNavy800,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(8.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(text = "TOTAL O.S.:", fontSize = 10.sp, color = TayleSlateLight)
                                Text(
                                    text = "R$ ${"%,.2f".format(Locale.GERMANY, calculatedTotal)}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TayleGreen
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Observações / Diagnóstico Inicial") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    // Priority Selector
                    Text("Prioridade da O.S.", fontSize = 11.sp, color = TayleSlateLight)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OsPriority.entries.forEach { p ->
                            FilterChip(
                                selected = priority == p,
                                onClick = { priority = p },
                                label = { Text(p.label, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TayleCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = TayleCyan
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    if (customerName.isNotBlank() && plate.isNotBlank()) {
                        val autoOsNumber = (1000 + (Math.random() * 9000).toInt()).toString()
                        val newOs = ServiceOrder(
                            id = UUID.randomUUID().toString(),
                            companyId = companyId,
                            osNumber = autoOsNumber,
                            plate = plate.trim(),
                            vehiclePlate = plate.trim(),
                            brand = brand,
                            model = model,
                            vehicleModel = "$brand $model",
                            year = yearText.toIntOrNull() ?: 2024,
                            color = color.trim(),
                            chassis = chassis.trim(),
                            customerName = customerName.trim(),
                            clientName = customerName.trim(),
                            customerPhone = customerPhone.trim(),
                            clientPhone = customerPhone.trim(),
                            description = if (notes.isNotBlank()) notes else selectedServices.joinToString(", ") { it.serviceName },
                            servicesList = selectedServices.map { "${it.quantity}x ${it.serviceName}" },
                            itemsList = selectedServices.toList(),
                            technicianName = technicianName,
                            status = OsStatus.ABERTA,
                            priority = priority,
                            discount = discount,
                            totalAmount = calculatedTotal,
                            notes = notes.trim(),
                            checklist = listOf(
                                ChecklistItem("Checklist de Entrada e Pátio", true),
                                ChecklistItem("Vistoria de Funilaria & Pintura", false),
                                ChecklistItem("Nível de Combustível e Hodômetro", false),
                                ChecklistItem("Teste de Rodagem Final", false)
                            )
                        )
                        onSave(newOs)
                        onDismiss()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_new_os_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TayleCyan,
                    contentColor = TayleNavy950
                ),
                shape = RoundedCornerShape(10.dp),
                enabled = customerName.isNotBlank() && plate.isNotBlank() && selectedServices.isNotEmpty()
            ) {
                Text(
                    text = "Gerar O.S. Oficial (R$ ${"%,.2f".format(Locale.GERMANY, calculatedTotal)})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsSheet(
    notifications: List<TayleNotification>,
    onClearAll: () -> Unit,
    onDismiss: () -> Unit
) {
    val df = remember { SimpleDateFormat("HH:mm - dd/MM", Locale.getDefault()) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Central de Notificações",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TayleWhite
                )
                if (notifications.isNotEmpty()) {
                    TextButton(onClick = onClearAll) {
                        Text("Limpar", color = TayleCyan, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (notifications.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nenhuma notificação no momento", color = TayleSlateLight)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(notifications) { notif ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = TayleNavy800,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = notif.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = when (notif.type) {
                                            NotificationType.WARNING, NotificationType.ALERTA, NotificationType.ATENCAO -> TayleAmber
                                            NotificationType.ERROR -> TayleRedLight
                                            NotificationType.SUCCESS, NotificationType.SUCESSO -> TayleGreen
                                            NotificationType.INFO, NotificationType.INFORMATIVO, NotificationType.SISTEMA -> TayleCyan
                                            else -> TayleCyan
                                        }
                                    )
                                    Text(
                                        text = df.format(Date(notif.timestamp)),
                                        fontSize = 10.sp,
                                        color = TayleSlateLight
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = notif.description,
                                    fontSize = 12.sp,
                                    color = TayleWhite
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchSelectorSheet(
    branches: List<Branch>,
    selectedBranch: Branch?,
    currentUser: User?,
    company: Company? = null,
    users: List<User> = emptyList(),
    onSelectBranch: (Branch?) -> Unit,
    onAddNewBranchClick: () -> Unit,
    onSwitchUserPersona: ((User) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val isHeadquartersAdmin = currentUser?.isHeadquartersUser == true || currentUser?.role == UserRole.ADMINISTRADOR

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Unidades & Filiais",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Text(
                        text = "Gestão de Matriz e Filiais da Empresa",
                        style = MaterialTheme.typography.bodySmall,
                        color = TayleSlateLight
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = TayleCyan.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "${branches.size} Unidades",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        color = TayleCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Se for MATRIZ: Pode alternar entre Visão Consolidada e Filiais específicas
            if (isHeadquartersAdmin) {
                // Opção Visão Consolidada
                val isConsolidatedSelected = selectedBranch == null
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isConsolidatedSelected) TayleCyan.copy(alpha = 0.2f) else TayleNavy800,
                    border = if (isConsolidatedSelected) androidx.compose.foundation.BorderStroke(1.5.dp, TayleCyan) else null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            onSelectBranch(null)
                            onDismiss()
                        }
                        .testTag("branch_option_consolidated")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(if (isConsolidatedSelected) TayleCyan else TayleNavy700),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Public,
                                contentDescription = null,
                                tint = if (isConsolidatedSelected) TayleNavy950 else TayleCyan
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Visão Consolidada",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TayleWhite
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = TayleAmber.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "TODAS AS UNIDADES",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        color = TayleAmber,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = "Soma o faturamento, vendas e metas de todas as filiais",
                                fontSize = 11.sp,
                                color = TayleSlateLight
                            )
                        }
                        if (isConsolidatedSelected) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Ativo",
                                tint = TayleCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            } else {
                // Se for USUÁRIO DE FILIAL: Acesso restrito
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = TayleNavy800,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TayleAmber.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = "Acesso Restrito",
                            tint = TayleAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Acesso Restrito à Unidade",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TayleAmber
                            )
                            Text(
                                text = "Conforme a política da empresa, você visualiza apenas os dados financeiros e operacionais de sua própria filial (${currentUser?.branchName}).",
                                fontSize = 11.sp,
                                color = TayleSlateLight
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            Text(
                text = "LISTA DE UNIDADES CADASTRADAS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TayleSlateLight,
                modifier = Modifier.padding(vertical = 6.dp)
            )

            LazyColumn(
                modifier = Modifier.weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(branches) { branch ->
                    val isCurrentBranch = selectedBranch?.id == branch.id || (!isHeadquartersAdmin && currentUser?.branchId == branch.id)
                    val isBranchLocked = !isHeadquartersAdmin && currentUser?.branchId != branch.id

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isCurrentBranch) TayleCyan.copy(alpha = 0.15f) else if (isBranchLocked) TayleNavy800.copy(alpha = 0.6f) else TayleNavy800,
                        border = if (isCurrentBranch) androidx.compose.foundation.BorderStroke(1.dp, TayleCyan) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !isBranchLocked) {
                                onSelectBranch(branch)
                                onDismiss()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (branch.isHeadquarters) TayleAmber.copy(alpha = 0.2f) else TayleNavy700),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (branch.isHeadquarters) "🏢" else "🏪",
                                    fontSize = 18.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = branch.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isBranchLocked) TayleSlateLight else TayleWhite
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = TayleNavy700
                                    ) {
                                        Text(
                                            text = branch.code,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                            fontSize = 9.sp,
                                            color = TayleCyan
                                        )
                                    }
                                }

                                Text(
                                    text = "Resp: ${branch.managerName} • ${branch.phone}",
                                    fontSize = 10.sp,
                                    color = TayleSlateLight
                                )
                                Text(
                                    text = branch.address,
                                    fontSize = 9.sp,
                                    color = TayleSlateLight,
                                    maxLines = 1
                                )
                            }

                            if (isBranchLocked) {
                                Icon(
                                    imageVector = Icons.Filled.Lock,
                                    contentDescription = "Protegido",
                                    tint = TayleSlateLight,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else if (isCurrentBranch) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Selecionada",
                                    tint = TayleCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Botão cadastrar nova filial (Apenas Matriz)
            if (isHeadquartersAdmin) {
                Button(
                    onClick = {
                        onDismiss()
                        onAddNewBranchClick()
                    },
                    modifier = Modifier.fillMaxWidth().testTag("add_new_branch_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = TayleCyan),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AddBusiness,
                        contentDescription = null,
                        tint = TayleNavy950
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Cadastrar Nova Filial",
                        color = TayleNavy950,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Seletor de Perfil de Demonstração (Permite testar visualização da Matriz vs Filial)
            if (users.isNotEmpty() && onSwitchUserPersona != null) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = TayleNavy800,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.SwitchAccount,
                                contentDescription = null,
                                tint = TayleCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Auditoria de Acesso (Simular Usuário):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TayleWhite
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            users.take(3).forEach { user ->
                                val isSelected = user.id == currentUser?.id
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        onSwitchUserPersona(user)
                                        onDismiss()
                                    },
                                    label = {
                                        Text(
                                            text = if (user.isHeadquartersUser) "🏢 Matriz Admin" else "🏪 ${user.branchName.replace("Filial ", "")}",
                                            fontSize = 10.sp
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = TayleCyan,
                                        selectedLabelColor = TayleNavy950,
                                        containerColor = TayleNavy700,
                                        labelColor = TayleSlateLight
                                    )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun AddBranchDialog(
    currentBranchesCount: Int,
    planName: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var managerName by remember { mutableStateOf("") }
    var usersCount by remember { mutableStateOf("5") }

    val maxAllowed = when {
        planName.contains("Básico", ignoreCase = true) -> 1
        planName.contains("Médio", ignoreCase = true) -> 3
        else -> 10
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Column {
                Text(
                    text = "Cadastrar Nova Filial",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TayleWhite
                )
                Text(
                    text = "Limite do Plano $planName: $currentBranchesCount/$maxAllowed unidades",
                    fontSize = 11.sp,
                    color = if (currentBranchesCount >= maxAllowed) TayleRedLight else TayleSlateLight
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome da Unidade") },
                    placeholder = { Text("Ex: Filial Campinas") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    )
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = code,
                        onValueChange = { code = it },
                        label = { Text("Código") },
                        placeholder = { Text("CP-05") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite,
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700
                        )
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Telefone") },
                        placeholder = { Text("(19) 98877-6655") },
                        singleLine = true,
                        modifier = Modifier.weight(1.5f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite,
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700
                        )
                    )
                }

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Endereço Completo") },
                    placeholder = { Text("Av. Francisco Glicério, 1200 - Centro") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    )
                )

                OutlinedTextField(
                    value = managerName,
                    onValueChange = { managerName = it },
                    label = { Text("Responsável da Filial") },
                    placeholder = { Text("Nome do gerente responsável") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    )
                )

                OutlinedTextField(
                    value = usersCount,
                    onValueChange = { usersCount = it },
                    label = { Text("Usuários Autorizados") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val count = usersCount.toIntOrNull() ?: 5
                    if (name.isNotBlank() && code.isNotBlank()) {
                        onConfirm(name, code, address, phone, managerName, count)
                    }
                },
                enabled = name.isNotBlank() && code.isNotBlank() && currentBranchesCount < maxAllowed,
                colors = ButtonDefaults.buttonColors(containerColor = TayleCyan)
            ) {
                Text("Salvar Filial", color = TayleNavy950, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}
