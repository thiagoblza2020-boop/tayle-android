package com.example.ui.screens.ai

data class AiTemplate(
    val title: String,
    val description: String,
    val category: String,
    val defaultPrompt: String,
    val sampleResult: String
)
