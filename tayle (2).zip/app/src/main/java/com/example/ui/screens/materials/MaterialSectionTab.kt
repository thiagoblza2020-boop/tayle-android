package com.example.ui.screens.materials

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.graphics.vector.ImageVector

enum class MaterialSectionTab(
    val title: String,
    val icon: ImageVector
) {
    STOCK("Estoque", Icons.Filled.Inventory2),
    REPLENISHMENT("Reposição", Icons.Filled.Warning),
    ORDERS("Pedidos", Icons.Filled.ShoppingCart),
    WASTE("Perdas & Desperdício", Icons.Filled.ReportProblem)
}
