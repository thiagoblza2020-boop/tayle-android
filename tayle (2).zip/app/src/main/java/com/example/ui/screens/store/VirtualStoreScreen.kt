package com.example.ui.screens.store

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

data class CartItem(
    val id: String,
    val name: String,
    val code: String,
    val price: Double,
    val isService: Boolean,
    val requiresInspection: Boolean = false,
    val category: String,
    var quantity: Int = 1
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VirtualStoreScreen(
    products: List<CommercialProduct>,
    services: List<ServiceCatalogItem>,
    orders: List<VirtualStoreOrder>,
    branches: List<Branch>,
    currentUser: User?,
    selectedBranch: Branch?,
    onSaveProduct: (CommercialProduct) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onSubmitStoreOrder: (VirtualStoreOrder, (Boolean, String) -> Unit) -> Unit,
    onUpdateOrderStatus: (VirtualStoreOrder, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Vitrine da Loja, 1: Histórico de Pedidos, 2: Gestão de Produtos
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterCategory by remember { mutableStateOf("Todos") }
    var selectedTypeFilter by remember { mutableStateOf<String>("Todos") } // Todos, Produtos, Serviços

    // Cart State
    val cartItems = remember { mutableStateListOf<CartItem>() }
    var showCartSheet by remember { mutableStateOf(false) }

    // Dialogs
    var showAddProductDialog by remember { mutableStateOf(false) }
    var productToEdit by remember { mutableStateOf<CommercialProduct?>(null) }
    var selectedProductForDetail by remember { mutableStateOf<CommercialProduct?>(null) }
    var selectedOrderForDetail by remember { mutableStateOf<VirtualStoreOrder?>(null) }

    // Filter categories
    val storeCategories = listOf("Todos", "Produtos", "Serviços", "Estética Automotiva", "Limpeza", "Proteção Cerâmica", "Acessórios")

    // Filtered Products for the showcase
    val filteredProducts = remember(products, searchQuery, selectedFilterCategory, selectedTypeFilter) {
        if (selectedTypeFilter == "Serviços") emptyList()
        else products.filter { prod ->
            val matchesSearch = searchQuery.isBlank() ||
                    prod.name.contains(searchQuery, ignoreCase = true) ||
                    prod.sku.contains(searchQuery, ignoreCase = true) ||
                    prod.description.contains(searchQuery, ignoreCase = true)

            val matchesCat = selectedFilterCategory == "Todos" ||
                    selectedFilterCategory == "Produtos" ||
                    prod.category.contains(selectedFilterCategory, ignoreCase = true)

            prod.isActive && matchesSearch && matchesCat
        }
    }

    // Filtered Services for the showcase
    val filteredServices = remember(services, searchQuery, selectedFilterCategory, selectedTypeFilter) {
        if (selectedTypeFilter == "Produtos") emptyList()
        else services.filter { srv ->
            val matchesSearch = searchQuery.isBlank() ||
                    srv.name.contains(searchQuery, ignoreCase = true) ||
                    srv.code.contains(searchQuery, ignoreCase = true) ||
                    srv.description.contains(searchQuery, ignoreCase = true)

            val matchesCat = selectedFilterCategory == "Todos" ||
                    selectedFilterCategory == "Serviços" ||
                    srv.category.contains(selectedFilterCategory, ignoreCase = true)

            srv.isActive && matchesSearch && matchesCat
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TayleNavy950,
        floatingActionButton = {
            if (selectedTab == 0 && cartItems.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { showCartSheet = true },
                    containerColor = TayleCyan,
                    contentColor = TayleNavy950,
                    icon = {
                        BadgedBox(
                            badge = {
                                Badge(containerColor = TayleAmber, contentColor = TayleNavy950) {
                                    Text("${cartItems.sumOf { it.quantity }}", fontWeight = FontWeight.Bold)
                                }
                            }
                        ) {
                            Icon(Icons.Filled.ShoppingCart, contentDescription = "Carrinho")
                        }
                    },
                    text = {
                        val cartTotal = cartItems.sumOf { it.price * it.quantity }
                        Text(
                            text = "Ver Carrinho • R$ ${"%,.2f".format(Locale.GERMANY, cartTotal)}",
                            fontWeight = FontWeight.Bold
                        )
                    },
                    modifier = Modifier.testTag("fab_open_cart")
                )
            } else if (selectedTab == 2) {
                ExtendedFloatingActionButton(
                    onClick = {
                        productToEdit = null
                        showAddProductDialog = true
                    },
                    containerColor = TayleCyan,
                    contentColor = TayleNavy950,
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    text = { Text("Novo Produto", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("fab_new_product")
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Loja Virtual TAYLE",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Text(
                        text = if (selectedBranch != null) "Unidade: ${selectedBranch.name}" else "Vitrine Matriz Consolidada",
                        fontSize = 12.sp,
                        color = TayleSlateLight
                    )
                }

                // Cart Icon Header button
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = TayleNavy900,
                    border = BorderStroke(1.dp, TayleNavy700),
                    modifier = Modifier.clickable { showCartSheet = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartItems.isNotEmpty()) {
                                    Badge(containerColor = TayleAmber, contentColor = TayleNavy950) {
                                        Text("${cartItems.sumOf { it.quantity }}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Filled.ShoppingCart, contentDescription = "Carrinho", tint = TayleCyan, modifier = Modifier.size(20.dp))
                        }
                        if (cartItems.isNotEmpty()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            val total = cartItems.sumOf { it.price * it.quantity }
                            Text(
                                text = "R$ ${"%,.0f".format(Locale.GERMANY, total)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TayleWhite
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Navigation Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = TayleNavy900,
                contentColor = TayleCyan,
                divider = { HorizontalDivider(color = TayleNavy700) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Storefront, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Vitrine", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Pedidos (${orders.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Inventory, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Cad. Produtos", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (selectedTab) {
                0 -> {
                    // TAB 0: VITRINE DE PRODUTOS & SERVIÇOS
                    // Search & Filters
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Pesquisar produtos ou serviços automotivos...") },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = TayleSlateLight) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Filled.Close, contentDescription = null, tint = TayleSlateLight)
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("store_search_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite,
                            focusedContainerColor = TayleNavy900,
                            unfocusedContainerColor = TayleNavy900
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Type Filter (Todos, Produtos, Serviços)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Todos", "Produtos", "Serviços").forEach { type ->
                            FilterChip(
                                selected = selectedTypeFilter == type,
                                onClick = { selectedTypeFilter = type },
                                label = { Text(type, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TayleCyan,
                                    selectedLabelColor = TayleNavy950,
                                    containerColor = TayleNavy800,
                                    labelColor = TayleWhite
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Combined Showcase List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 72.dp)
                    ) {
                        // Section: Serviços Automotivos
                        if (filteredServices.isNotEmpty()) {
                            item {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Build, contentDescription = null, tint = TayleCyan, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "SERVIÇOS AUTOMOTIVOS ESPECIALIZADOS",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TayleCyan,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }

                            items(filteredServices, key = { "srv_${it.id}" }) { srv ->
                                StoreServiceCard(
                                    service = srv,
                                    onAddToCart = {
                                        val existing = cartItems.find { it.id == srv.id && it.isService }
                                        if (existing != null) {
                                            existing.quantity++
                                        } else {
                                            cartItems.add(
                                                CartItem(
                                                    id = srv.id,
                                                    name = srv.name,
                                                    code = srv.code,
                                                    price = srv.salePrice,
                                                    isService = true,
                                                    requiresInspection = srv.requiresVehicleInspection,
                                                    category = srv.category
                                                )
                                            )
                                        }
                                        Toast.makeText(context, "${srv.name} adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }

                        // Section: Produtos para Venda
                        if (filteredProducts.isNotEmpty()) {
                            item {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.ShoppingBag, contentDescription = null, tint = TayleAmber, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "PRODUTOS & COSMÉTICOS AUTOMOTIVOS",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TayleAmber,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }

                            items(filteredProducts, key = { "prod_${it.id}" }) { prod ->
                                StoreProductCard(
                                    product = prod,
                                    onCardClick = { selectedProductForDetail = prod },
                                    onAddToCart = {
                                        val existing = cartItems.find { it.id == prod.id && !it.isService }
                                        if (existing != null) {
                                            existing.quantity++
                                        } else {
                                            cartItems.add(
                                                CartItem(
                                                    id = prod.id,
                                                    name = prod.name,
                                                    code = prod.sku,
                                                    price = prod.activePrice,
                                                    isService = false,
                                                    category = prod.category
                                                )
                                            )
                                        }
                                        Toast.makeText(context, "${prod.name} adicionado ao carrinho!", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }

                        if (filteredProducts.isEmpty() && filteredServices.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(40.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Filled.SearchOff, contentDescription = null, tint = TayleSlateLight, modifier = Modifier.size(48.dp))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("Nenhum item encontrado", color = TayleWhite, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // TAB 1: HISTÓRICO DE PEDIDOS DA LOJA
                    if (orders.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.ReceiptLong, contentDescription = null, tint = TayleSlateLight, modifier = Modifier.size(56.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Nenhum pedido registrado ainda", color = TayleWhite, fontWeight = FontWeight.Bold)
                                Text("Os pedidos gerados na loja virtual aparecerão aqui.", fontSize = 12.sp, color = TayleSlateLight)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 72.dp)
                        ) {
                            items(orders, key = { it.id }) { order ->
                                StoreOrderCard(
                                    order = order,
                                    onCardClick = { selectedOrderForDetail = order },
                                    onUpdateStatus = { newStatus -> onUpdateOrderStatus(order, newStatus) }
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // TAB 2: CADASTRO E GESTÃO DE PRODUTOS PARA VENDA (Item 3)
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 72.dp)
                    ) {
                        items(products, key = { it.id }) { product ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = TayleNavy900,
                                border = BorderStroke(1.dp, TayleNavy700),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(product.sku, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = if (product.stockCurrent > 0) TayleGreen.copy(alpha = 0.2f) else TayleRedLight.copy(alpha = 0.2f)
                                            ) {
                                                Text(
                                                    text = if (product.stockCurrent > 0) "Em Estoque: ${product.stockCurrent}" else "Indisponível",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (product.stockCurrent > 0) TayleGreen else TayleRedLight,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(product.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                                        Text("${product.category} • Preço: R$ ${"%,.2f".format(Locale.GERMANY, product.activePrice)}", fontSize = 12.sp, color = TayleGreen, fontWeight = FontWeight.SemiBold)
                                    }

                                    Row {
                                        IconButton(onClick = {
                                            productToEdit = product
                                            showAddProductDialog = true
                                        }) {
                                            Icon(Icons.Filled.Edit, contentDescription = "Editar", tint = TayleWhite, modifier = Modifier.size(18.dp))
                                        }
                                        IconButton(onClick = { onDeleteProduct(product.id) }) {
                                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Excluir", tint = TayleRedLight, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal do Carrinho de Compras e Checkout (Item 5)
    if (showCartSheet) {
        ShoppingCartModal(
            cartItems = cartItems,
            branches = branches,
            selectedBranch = selectedBranch,
            companyId = currentUser?.companyId ?: "comp_matriz",
            onDismiss = { showCartSheet = false },
            onUpdateQuantity = { item, delta ->
                val newQ = item.quantity + delta
                if (newQ <= 0) {
                    cartItems.remove(item)
                } else {
                    item.quantity = newQ
                }
            },
            onRemoveItem = { cartItems.remove(it) },
            onCheckout = { finalOrder ->
                onSubmitStoreOrder(finalOrder) { success, msg ->
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    if (success) {
                        cartItems.clear()
                        showCartSheet = false
                    }
                }
            }
        )
    }

    // Modal de Cadastro/Edição de Produto para Venda (Item 3)
    if (showAddProductDialog) {
        AddEditProductDialog(
            product = productToEdit,
            branches = branches,
            defaultBranch = selectedBranch ?: branches.firstOrNull(),
            companyId = currentUser?.companyId ?: "comp_matriz",
            onDismiss = { showAddProductDialog = false },
            onSave = { p ->
                onSaveProduct(p)
                showAddProductDialog = false
                Toast.makeText(context, "Produto salvo com sucesso!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Modal de Detalhe de Pedido da Loja
    if (selectedOrderForDetail != null) {
        StoreOrderDetailModal(
            order = selectedOrderForDetail!!,
            onDismiss = { selectedOrderForDetail = null },
            onUpdateStatus = { newSt ->
                onUpdateOrderStatus(selectedOrderForDetail!!, newSt)
                selectedOrderForDetail = selectedOrderForDetail!!.copy(status = newSt)
            }
        )
    }
}

@Composable
fun StoreServiceCard(
    service: ServiceCatalogItem,
    onAddToCart: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = TayleNavy900,
        border = BorderStroke(1.dp, TayleNavy700),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = TayleCyan.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "SERVIÇO • ${service.category}",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Text(text = service.code, fontSize = 10.sp, color = TayleSlateLight)
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = service.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
            Text(text = service.description, fontSize = 11.sp, color = TayleSlateLight, maxLines = 2, overflow = TextOverflow.Ellipsis)

            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Preço TAYLE:", fontSize = 9.sp, color = TayleSlateLight)
                    Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, service.salePrice)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = TayleGreen)
                }

                Button(
                    onClick = onAddToCart,
                    colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Filled.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (service.requiresVehicleInspection) "Orçar / Agendar" else "Adicionar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun StoreProductCard(
    product: CommercialProduct,
    onCardClick: () -> Unit,
    onAddToCart: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = TayleNavy900,
        border = BorderStroke(1.dp, TayleNavy700),
        modifier = Modifier.fillMaxWidth().clickable { onCardClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon or thumbnail placeholder
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(TayleAmber.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Inventory2, contentDescription = null, tint = TayleAmber, modifier = Modifier.size(28.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = TayleNavy800
                ) {
                    Text(
                        text = "${product.category} • ${product.sku}",
                        fontSize = 9.sp,
                        color = TayleSlateLight,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = product.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TayleWhite, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, product.activePrice)}", fontSize = 15.sp, fontWeight = FontWeight.Black, color = TayleGreen)
            }

            IconButton(
                onClick = onAddToCart,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(TayleCyan)
            ) {
                Icon(Icons.Filled.AddShoppingCart, contentDescription = "Comprar", tint = TayleNavy950, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun StoreOrderCard(
    order: VirtualStoreOrder,
    onCardClick: () -> Unit,
    onUpdateStatus: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = TayleNavy900,
        border = BorderStroke(1.dp, TayleNavy700),
        modifier = Modifier.fillMaxWidth().clickable { onCardClick() }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Pedido #${order.orderNumber}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = when (order.status) {
                        "Confirmado" -> TayleGreen.copy(alpha = 0.2f)
                        "Concluído" -> TayleGreen.copy(alpha = 0.2f)
                        "Em Andamento" -> TayleCyan.copy(alpha = 0.2f)
                        "Cancelado" -> TayleRedLight.copy(alpha = 0.2f)
                        else -> TayleAmber.copy(alpha = 0.2f)
                    }
                ) {
                    Text(
                        text = order.status,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (order.status) {
                            "Confirmado", "Concluído" -> TayleGreen
                            "Em Andamento" -> TayleCyan
                            "Cancelado" -> TayleRedLight
                            else -> TayleAmber
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = "Cliente: ${order.customerName} (${order.customerPhone})", fontSize = 12.sp, color = TayleWhite)
            if (order.customerVehiclePlate.isNotBlank()) {
                Text(text = "Veículo: ${order.customerVehiclePlate} ${order.customerVehicleModel}", fontSize = 11.sp, color = TayleSlateLight)
            }
            Text(text = "Itens: ${order.itemsSummary}", fontSize = 11.sp, color = TayleSlateLight, maxLines = 1, overflow = TextOverflow.Ellipsis)

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Pagamento: ${order.paymentMethod} (${order.paymentStatus})", fontSize = 10.sp, color = TayleSlateLight)
                Text(text = "Total: R$ ${"%,.2f".format(Locale.GERMANY, order.total)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TayleGreen)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingCartModal(
    cartItems: List<CartItem>,
    branches: List<Branch>,
    selectedBranch: Branch?,
    companyId: String,
    onDismiss: () -> Unit,
    onUpdateQuantity: (CartItem, Int) -> Unit,
    onRemoveItem: (CartItem) -> Unit,
    onCheckout: (VirtualStoreOrder) -> Unit
) {
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var customerPlate by remember { mutableStateOf("") }
    var customerVehicleModel by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf("PIX") }
    var orderNotes by remember { mutableStateOf("") }

    val hasServices = remember(cartItems) { cartItems.any { it.isService } }
    val hasInspections = remember(cartItems) { cartItems.any { it.requiresInspection } }
    val subtotal = remember(cartItems) { cartItems.sumOf { it.price * it.quantity } }
    val discount = 0.0
    val total = subtotal - discount

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Carrinho de Compras", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                Text(text = "${cartItems.sumOf { it.quantity }} itens", fontSize = 12.sp, color = TayleCyan)
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (cartItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Seu carrinho está vazio", color = TayleSlateLight)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(cartItems) { item ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TayleNavy800,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = item.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                                    Text(
                                        text = "${if (item.isService) "Serviço" else "Produto"} • R$ ${"%,.2f".format(Locale.GERMANY, item.price)}",
                                        fontSize = 10.sp,
                                        color = TayleSlateLight
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { onUpdateQuantity(item, -1) }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Filled.Remove, contentDescription = null, tint = TayleWhite, modifier = Modifier.size(14.dp))
                                    }
                                    Text(text = "${item.quantity}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleCyan, modifier = Modifier.padding(horizontal = 6.dp))
                                    IconButton(onClick = { onUpdateQuantity(item, 1) }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Filled.Add, contentDescription = null, tint = TayleWhite, modifier = Modifier.size(14.dp))
                                    }
                                    IconButton(onClick = { onRemoveItem(item) }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Filled.DeleteOutline, contentDescription = null, tint = TayleRedLight, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Customer Identification
                Text(text = "IDENTIFICAÇÃO DO CLIENTE:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleCyan, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(4.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Nome Completo *") },
                        modifier = Modifier.weight(1.2f).testTag("cart_customer_name"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("WhatsApp *") },
                        modifier = Modifier.weight(1f).testTag("cart_customer_phone"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                if (hasServices) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(
                            value = customerPlate,
                            onValueChange = { customerPlate = it.uppercase() },
                            label = { Text("Placa do Veículo *") },
                            modifier = Modifier.weight(1f).testTag("cart_customer_plate"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = customerVehicleModel,
                            onValueChange = { customerVehicleModel = it },
                            label = { Text("Modelo do Carro") },
                            placeholder = { Text("Ex: Corolla 2023") },
                            modifier = Modifier.weight(1.2f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Payment Method
                Text(text = "FORMA DE PAGAMENTO:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleCyan, letterSpacing = 1.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(listOf("PIX", "Cartão de Crédito", "Boleto", "No Balcão")) { method ->
                        FilterChip(
                            selected = selectedPaymentMethod == method,
                            onClick = { selectedPaymentMethod = method },
                            label = { Text(method, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TayleCyan,
                                selectedLabelColor = TayleNavy950,
                                containerColor = TayleNavy800,
                                labelColor = TayleWhite
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Price Summary
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleNavy800,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Subtotal:", fontSize = 11.sp, color = TayleSlateLight)
                            Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, subtotal)}", fontSize = 11.sp, color = TayleWhite)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "TOTAL DO PEDIDO:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                            Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, total)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = TayleGreen)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val orderNum = "PED-${1000 + (Math.random() * 9000).toInt()}"
                        val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                        val summary = cartItems.joinToString(", ") { "${it.quantity}x ${it.name}" }
                        val itemsList = cartItems.map {
                            VirtualStoreOrderItem(
                                itemId = it.id,
                                itemName = it.name,
                                isService = it.isService,
                                quantity = it.quantity,
                                unitPrice = it.price
                            )
                        }

                        val order = VirtualStoreOrder(
                            id = UUID.randomUUID().toString(),
                            companyId = companyId,
                            branchId = selectedBranch?.id ?: "branch_sp_matriz",
                            branchName = selectedBranch?.name ?: "Matriz São Paulo",
                            orderNumber = orderNum,
                            customerName = customerName.trim(),
                            customerPhone = customerPhone.trim(),
                            customerVehiclePlate = customerPlate.trim(),
                            customerVehicleModel = customerVehicleModel.trim(),
                            itemsSummary = summary,
                            itemsList = itemsList,
                            subtotal = subtotal,
                            discount = discount,
                            total = total,
                            status = if (hasInspections) "Aguardando Avaliação" else "Confirmado",
                            isQuoteRequest = hasInspections,
                            paymentMethod = selectedPaymentMethod,
                            paymentStatus = if (selectedPaymentMethod == "PIX") "Aguardando PIX" else "A Faturar",
                            dateFormatted = today
                        )
                        onCheckout(order)
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("btn_confirm_store_order"),
                    colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                    shape = RoundedCornerShape(10.dp),
                    enabled = customerName.isNotBlank() && customerPhone.isNotBlank() && (!hasServices || customerPlate.isNotBlank())
                ) {
                    Text(
                        text = if (hasInspections) "Solicitar Orçamento / Agendar" else "Finalizar e Confirmar Pedido",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditProductDialog(
    product: CommercialProduct?,
    branches: List<Branch>,
    defaultBranch: Branch?,
    companyId: String,
    onDismiss: () -> Unit,
    onSave: (CommercialProduct) -> Unit
) {
    var name by remember { mutableStateOf(product?.name ?: "") }
    var sku by remember { mutableStateOf(product?.sku ?: "PRD-${100 + (Math.random() * 900).toInt()}") }
    var category by remember { mutableStateOf(product?.category ?: "Estética Automotiva") }
    var description by remember { mutableStateOf(product?.description ?: "") }
    var salePriceText by remember { mutableStateOf(product?.salePrice?.let { "%.2f".format(Locale.US, it) } ?: "89.90") }
    var costPriceText by remember { mutableStateOf(product?.costPrice?.let { "%.2f".format(Locale.US, it) } ?: "45.00") }
    var stockCurrentText by remember { mutableStateOf(product?.stockCurrent?.toString() ?: "15") }
    var isActive by remember { mutableStateOf(product?.isActive ?: true) }
    var selectedBranch by remember { mutableStateOf(branches.find { it.id == product?.branchId } ?: defaultBranch ?: branches.firstOrNull()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Text(
                text = if (product != null) "Editar Produto da Loja" else "Cadastrar Produto para Venda",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TayleWhite
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nome do Produto *") },
                        placeholder = { Text("Ex: Cera Blend Carnaúba & Sílica 500ml") },
                        modifier = Modifier.fillMaxWidth().testTag("product_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = sku,
                            onValueChange = { sku = it.uppercase() },
                            label = { Text("Código / SKU *") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("Categoria") },
                            modifier = Modifier.weight(1.2f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = salePriceText,
                            onValueChange = { salePriceText = it },
                            label = { Text("Preço Venda (R$) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                        OutlinedTextField(
                            value = costPriceText,
                            onValueChange = { costPriceText = it },
                            label = { Text("Preço Custo (R$)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = TayleCyan,
                                unfocusedBorderColor = TayleNavy700,
                                focusedTextColor = TayleWhite,
                                unfocusedTextColor = TayleWhite
                            )
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = stockCurrentText,
                        onValueChange = { stockCurrentText = it },
                        label = { Text("Quantidade em Estoque") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Descrição do Produto") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Disponível na Loja Virtual?", fontSize = 12.sp, color = TayleWhite)
                        Switch(
                            checked = isActive,
                            onCheckedChange = { isActive = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = TayleCyan)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && sku.isNotBlank()) {
                        val p = CommercialProduct(
                            id = product?.id ?: UUID.randomUUID().toString(),
                            companyId = companyId,
                            branchId = selectedBranch?.id ?: "branch_sp_matriz",
                            branchName = selectedBranch?.name ?: "Matriz São Paulo",
                            name = name.trim(),
                            sku = sku.trim(),
                            code = sku.trim(),
                            category = category.trim(),
                            salePrice = salePriceText.toDoubleOrNull() ?: 89.90,
                            costPrice = costPriceText.toDoubleOrNull() ?: 45.00,
                            stockCurrent = stockCurrentText.toIntOrNull() ?: 10,
                            stockMin = 3,
                            stockIdeal = 15,
                            stockMax = 50,
                            department = CommercialDepartment.POS_VENDAS,
                            description = description.trim(),
                            isActive = isActive,
                            isAvailableForVirtualStore = true
                        )
                        onSave(p)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                enabled = name.isNotBlank() && sku.isNotBlank()
            ) {
                Text("Salvar Produto", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreOrderDetailModal(
    order: VirtualStoreOrder,
    onDismiss: () -> Unit,
    onUpdateStatus: (String) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Text(text = "Detalhes do Pedido #${order.orderNumber}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
            Text(text = "Data: ${order.dateFormatted} • Unidade: ${order.branchName}", fontSize = 11.sp, color = TayleSlateLight)

            Spacer(modifier = Modifier.height(12.dp))

            Surface(shape = RoundedCornerShape(8.dp), color = TayleNavy800, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = "CLIENTE:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                    Text(text = order.customerName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                    Text(text = "WhatsApp: ${order.customerPhone}", fontSize = 12.sp, color = TayleCyan)
                    if (order.customerVehiclePlate.isNotBlank()) {
                        Text(text = "Veículo: ${order.customerVehiclePlate} (${order.customerVehicleModel})", fontSize = 12.sp, color = TayleWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Surface(shape = RoundedCornerShape(8.dp), color = TayleNavy800, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(text = "ITENS DO PEDIDO:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                    Spacer(modifier = Modifier.height(4.dp))
                    if (order.itemsList.isNotEmpty()) {
                        order.itemsList.forEach { itm ->
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "${itm.quantity}x ${itm.itemName}", fontSize = 12.sp, color = TayleWhite)
                                Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, itm.total)}", fontSize = 12.sp, color = TayleGreen, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Text(text = order.itemsSummary, fontSize = 12.sp, color = TayleWhite)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = TayleNavy700)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "TOTAL:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                        Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, order.total)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = TayleGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(text = "Alterar Status:", fontSize = 11.sp, color = TayleSlateLight)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Confirmado", "Em Andamento", "Concluído", "Cancelado").forEach { st ->
                    FilterChip(
                        selected = order.status == st,
                        onClick = { onUpdateStatus(st) },
                        label = { Text(st, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TayleCyan,
                            selectedLabelColor = TayleNavy950,
                            containerColor = TayleNavy800,
                            labelColor = TayleWhite
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
