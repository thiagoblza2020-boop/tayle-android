package com.example.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.theme.*

@Composable
fun LoginScreen(
    onLogin: (email: String, role: UserRole) -> Unit,
    onNavigateToRegister: () -> Unit,
    modifier: Modifier = Modifier
) {
    var email by remember { mutableStateOf("admin@tayle.com") }
    var password by remember { mutableStateOf("••••••••") }
    var selectedRole by remember { mutableStateOf(UserRole.ADMINISTRADOR) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(24.dp)
            .testTag("login_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // TAYLE Logo
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(TayleCyan, TayleNavy500)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "T",
                    fontWeight = FontWeight.Black,
                    fontSize = 38.sp,
                    color = TayleNavy950
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "TAYLE",
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                color = TayleWhite,
                letterSpacing = 2.sp
            )

            Text(
                text = "Marketing, Vendas & Gestão Integrada",
                fontSize = 13.sp,
                color = TayleSlateLight
            )

            Spacer(modifier = Modifier.height(30.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Acesso ao Sistema",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("E-mail corporativo") },
                        leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null, tint = TayleCyan) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_email_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Senha") },
                        visualTransformation = PasswordVisualTransformation(),
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = TayleCyan) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_password_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700,
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Perfil de Acesso:", fontSize = 11.sp, color = TayleSlateLight)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        UserRole.entries.forEach { r ->
                            FilterChip(
                                selected = selectedRole == r,
                                onClick = { selectedRole = r },
                                label = { Text(r.label, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TayleCyan.copy(alpha = 0.2f),
                                    selectedLabelColor = TayleCyan
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            if (email.isNotBlank()) {
                                onLogin(email, selectedRole)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TayleCyan,
                            contentColor = TayleNavy950
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("login_submit_button")
                    ) {
                        Text("Entrar na Plataforma", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(onClick = onNavigateToRegister) {
                Text("Cadastrar Nova Empresa / Concessionária", color = TayleCyan, fontSize = 13.sp)
            }
        }
    }
}
