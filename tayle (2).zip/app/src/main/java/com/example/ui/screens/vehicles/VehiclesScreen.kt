package com.example.ui.screens.vehicles

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Branch
import com.example.data.model.UserRole
import com.example.data.model.Vehicle
import com.example.data.model.VehicleStatus
import com.example.ui.components.BrandModelSelector
import com.example.ui.components.VehicleStatusBadge
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun VehiclesScreen(
    vehicles: List<Vehicle>,
    userRole: UserRole,
    onAddVehicle: (Vehicle) -> Unit,
    onUpdateVehicleStatus: (Vehicle, VehicleStatus) -> Unit,
    selectedBranch: Branch? = null,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf<VehicleStatus?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredVehicles = remember(vehicles, searchQuery, selectedStatusFilter) {
        vehicles.filter { v ->
            val matchesSearch = v.plate.contains(searchQuery, ignoreCase = true) ||
                    v.model.contains(searchQuery, ignoreCase = true) ||
                    v.brand.contains(searchQuery, ignoreCase = true) ||
                    v.customerName.contains(searchQuery, ignoreCase = true)
            val matchesStatus = selectedStatusFilter == null || v.status == selectedStatusFilter
            matchesSearch && matchesStatus
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(16.dp)
            .testTag("vehicles_screen")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Pátio & Veículos",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = TayleWhite
                )
                Text(
                    text = "Controle de entrada, inspeção e boxes",
                    style = MaterialTheme.typography.bodySmall,
                    color = TayleSlateLight
                )
                Text(
                    text = if (selectedBranch != null) "📍 ${selectedBranch.name}" else "🌐 Visão Consolidada (Todas as Unidades)",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedBranch != null) TayleCyan else TayleAmber
                )
            }

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TayleCyan,
                    contentColor = TayleNavy950
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("add_vehicle_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Entrada Pátio", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buscar por placa, cliente ou modelo...", color = TayleSlateLight, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = TayleCyan) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("vehicles_search_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = TayleCyan,
                unfocusedBorderColor = TayleNavy800,
                focusedTextColor = TayleWhite,
                unfocusedTextColor = TayleWhite
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Status Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = selectedStatusFilter == null,
                onClick = { selectedStatusFilter = null },
                label = { Text("Todos (${vehicles.size})", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = TayleCyan.copy(alpha = 0.2f),
                    selectedLabelColor = TayleCyan
                )
            )
            VehicleStatus.entries.take(3).forEach { st ->
                val count = vehicles.count { it.status == st }
                FilterChip(
                    selected = selectedStatusFilter == st,
                    onClick = { selectedStatusFilter = if (selectedStatusFilter == st) null else st },
                    label = { Text("${st.label} ($count)", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TayleCyan.copy(alpha = 0.2f),
                        selectedLabelColor = TayleCyan
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredVehicles.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("Nenhum veículo encontrado no pátio", color = TayleSlateLight)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredVehicles) { veh ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = TayleNavy900,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.DirectionsCar, contentDescription = null, tint = TayleCyan)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "${veh.brand} ${veh.model}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = TayleWhite
                                        )
                                        Text(
                                            text = "Placa: ${veh.plate} • Ano: ${veh.year} • Cor: ${veh.color}",
                                            fontSize = 12.sp,
                                            color = TayleSlateLight
                                        )
                                    }
                                }
                                VehicleStatusBadge(status = veh.status)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("📍 ${veh.branchName}", fontSize = 11.sp, color = TayleAmber, fontWeight = FontWeight.SemiBold)
                                Text("Local: ${veh.location}", fontSize = 11.sp, color = TayleCyan)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Cliente: ${veh.customerName}", fontSize = 12.sp, color = TayleWhite)
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Combustível: ${veh.fuelLevel}", fontSize = 11.sp, color = TayleSlateLight)
                                Text("Km: ${veh.mileage} km", fontSize = 11.sp, color = TayleSlateLight)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action to change status
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                if (veh.status != VehicleStatus.ENTREGUE) {
                                    val nextStatus = when (veh.status) {
                                        VehicleStatus.AGUARDANDO_INSPECAO -> VehicleStatus.EM_SERVICO
                                        VehicleStatus.EM_SERVICO -> VehicleStatus.PRONTO
                                        VehicleStatus.PRONTO -> VehicleStatus.ENTREGUE
                                        else -> VehicleStatus.EM_SERVICO
                                    }
                                    val label = when (veh.status) {
                                        VehicleStatus.AGUARDANDO_INSPECAO -> "Colocar no Box"
                                        VehicleStatus.EM_SERVICO -> "Marcar Pronto"
                                        VehicleStatus.PRONTO -> "Liberar Saída"
                                        else -> "Retomar Serviço"
                                    }

                                    Button(
                                        onClick = { onUpdateVehicleStatus(veh, nextStatus) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = TayleNavy700,
                                            contentColor = TayleCyan
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var brand by remember { mutableStateOf("Toyota") }
        var model by remember { mutableStateOf("Corolla XEi 2.0") }
        var plate by remember { mutableStateOf("") }
        var yearText by remember { mutableStateOf("2023") }
        var color by remember { mutableStateOf("Prata") }
        var customerName by remember { mutableStateOf("") }
        var customerPhone by remember { mutableStateOf("") }
        var location by remember { mutableStateOf("Pátio Entrada - Box 01") }

        Dialog(onDismissRequest = { showAddDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Entrada de Veículo no Pátio",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            BrandModelSelector(
                                selectedBrand = brand,
                                selectedModel = model,
                                onBrandSelected = { brand = it },
                                onModelSelected = { model = it }
                            )
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = plate,
                                    onValueChange = { plate = it.uppercase().take(8) },
                                    label = { Text("Placa") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                                OutlinedTextField(
                                    value = yearText,
                                    onValueChange = { yearText = it },
                                    label = { Text("Ano") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                            }
                        }

                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = color,
                                    onValueChange = { color = it },
                                    label = { Text("Cor") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                                OutlinedTextField(
                                    value = location,
                                    onValueChange = { location = it },
                                    label = { Text("Box / Vaga") },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = TayleCyan,
                                        unfocusedBorderColor = TayleNavy700,
                                        focusedTextColor = TayleWhite,
                                        unfocusedTextColor = TayleWhite
                                    )
                                )
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = customerName,
                                onValueChange = { customerName = it },
                                label = { Text("Cliente / Proprietário") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TayleCyan,
                                    unfocusedBorderColor = TayleNavy700,
                                    focusedTextColor = TayleWhite,
                                    unfocusedTextColor = TayleWhite
                                )
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = customerPhone,
                                onValueChange = { customerPhone = it },
                                label = { Text("WhatsApp do Cliente") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = TayleCyan,
                                    unfocusedBorderColor = TayleNavy700,
                                    focusedTextColor = TayleWhite,
                                    unfocusedTextColor = TayleWhite
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (plate.isNotBlank() && customerName.isNotBlank()) {
                                val newVeh = Vehicle(
                                    id = UUID.randomUUID().toString(),
                                    companyId = "comp_matriz",
                                    plate = plate,
                                    brand = brand,
                                    model = model,
                                    year = yearText.toIntOrNull() ?: 2023,
                                    color = color,
                                    customerName = customerName,
                                    customerPhone = customerPhone,
                                    status = VehicleStatus.AGUARDANDO_INSPECAO,
                                    location = location
                                )
                                onAddVehicle(newVeh)
                                showAddDialog = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Registrar Entrada no Pátio", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
