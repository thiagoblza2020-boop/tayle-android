package com.example.ui.screens.dashboard

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.OsStatusBadge
import com.example.ui.theme.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    currentUser: User?,
    currentCompany: Company?,
    vehicles: List<Vehicle>,
    orders: List<ServiceOrder>,
    employees: List<Employee>,
    goal: Goal?,
    materials: List<Material> = emptyList(),
    materialOrders: List<MaterialOrder> = emptyList(),
    materialWastes: List<MaterialWaste> = emptyList(),
    commercialProducts: List<CommercialProduct> = emptyList(),
    commercialSales: List<CommercialSale> = emptyList(),
    salesOpportunities: List<SalesOpportunity> = emptyList(),
    lostSales: List<LostSale> = emptyList(),
    dailyAgendaTasks: List<DailyAgendaTask> = emptyList(),
    selectedBranch: Branch? = null,
    branches: List<Branch> = emptyList(),
    allCompanySales: List<CommercialSale> = emptyList(),
    onSelectBranch: ((Branch?) -> Unit)? = null,
    onOpenBranchModal: (() -> Unit)? = null,
    onAddNewBranchClick: (() -> Unit)? = null,
    onNavigateToVehicles: () -> Unit,
    onNavigateToOrders: () -> Unit,
    onNewOrderClick: () -> Unit,
    onNavigateToStock: () -> Unit,
    onNavigateToAi: () -> Unit,
    onNavigateToCatalog: (() -> Unit)? = null,
    onNavigateToVirtualStore: (() -> Unit)? = null,
    onUpdateOrderStatus: (ServiceOrder, OsStatus) -> Unit,
    onRegisterCommercialSale: (CommercialSale, CommercialProduct?) -> Unit,
    onSaveSalesOpportunity: (SalesOpportunity) -> Unit,
    onUpdateOpportunityStage: (SalesOpportunity, FunnelStage) -> Unit,
    onToggleDailyTask: (DailyAgendaTask) -> Unit,
    onSaveDailyTask: (DailyAgendaTask) -> Unit,
    onRecoverLostSale: (LostSale) -> Unit,
    onSaveCommercialProduct: (CommercialProduct) -> Unit,
    onStockMovement: (CommercialProduct, Boolean, Int, String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currencyFormat = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }
    val todayFormatted = remember { SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date()) }
    val currentMonthFormatted = remember { SimpleDateFormat("MM/yyyy", Locale("pt", "BR")).format(Date()) }

    // Department Filter State: null = Todos / Geral, or POS_VENDAS, NOVOS, SEMINOVOS
    var selectedDepartment by remember { mutableStateOf<CommercialDepartment?>(null) }

    // Modals
    var showNewSaleDialog by remember { mutableStateOf(false) }
    var showNewOpportunityDialog by remember { mutableStateOf(false) }
    var showAiCommercialHelperDialog by remember { mutableStateOf(false) }
    var showNewTaskDialog by remember { mutableStateOf(false) }
    var showStockMovementDialog by remember { mutableStateOf<CommercialProduct?>(null) }
    var showRecoveryDialog by remember { mutableStateOf<LostSale?>(null) }

    // Filter sales and products based on selected department
    val filteredSales = remember(commercialSales, selectedDepartment) {
        if (selectedDepartment == null) commercialSales else commercialSales.filter { it.department == selectedDepartment }
    }

    val filteredProducts = remember(commercialProducts, selectedDepartment) {
        if (selectedDepartment == null) commercialProducts else commercialProducts.filter { it.department == selectedDepartment }
    }

    val filteredOpportunities = remember(salesOpportunities, selectedDepartment) {
        if (selectedDepartment == null) salesOpportunities else salesOpportunities.filter { it.department == selectedDepartment }
    }

    // 1. DASHBOARD PRINCIPAL INDICATORS (Reais)
    // Diárias: timestamp nas últimas 24 horas ou dateFormatted == todayFormatted
    val dailySales = remember(filteredSales) {
        filteredSales.filter { it.dateFormatted == todayFormatted || System.currentTimeMillis() - it.timestamp < 24 * 3600 * 1000 }
    }
    val dailyRevenue = remember(dailySales) { dailySales.sumOf { it.revenue } }
    val dailyCount = remember(dailySales) { dailySales.sumOf { it.quantity } }

    // Mensais: mês atual ou todas as vendas registradas do ciclo
    val monthlySales = remember(filteredSales) {
        filteredSales.filter { it.monthPeriod.contains("2026") || it.monthPeriod.contains("09") }
    }
    val monthlyRevenue = remember(monthlySales) { monthlySales.sumOf { it.revenue } }
    val monthlyCount = remember(monthlySales) { monthlySales.sumOf { it.quantity } }

    // Faturamento Geral & Custo Total & Lucro
    val totalRevenue = remember(filteredSales) { filteredSales.sumOf { it.revenue } }
    val totalCost = remember(filteredSales) { filteredSales.sumOf { it.totalCost } }
    val grossProfit = remember(totalRevenue, totalCost) { totalRevenue - totalCost }
    val profitMarginPercent = remember(totalRevenue, grossProfit) {
        if (totalRevenue > 0) (grossProfit / totalRevenue) * 100.0 else 0.0
    }

    val ticketMedio = remember(totalRevenue, filteredSales) {
        val totalCount = filteredSales.sumOf { it.quantity }
        if (totalCount > 0) totalRevenue / totalCount else 0.0
    }

    // 4. ESTOQUE COMERCIAL INTELIGENTE
    val totalStockItems = remember(filteredProducts) { filteredProducts.sumOf { it.stockCurrent } }
    val stockInvestedCost = remember(filteredProducts) { filteredProducts.sumOf { it.stockCurrent * it.costPrice } }
    val stockPotentialRevenue = remember(filteredProducts) { filteredProducts.sumOf { it.stockCurrent * it.activePrice } }
    val stockProjectedProfit = remember(stockPotentialRevenue, stockInvestedCost) { stockPotentialRevenue - stockInvestedCost }

    val criticalStockCount = remember(filteredProducts) {
        filteredProducts.count { it.stockHealth == StockHealth.ESGOTADO || it.stockHealth == StockHealth.LIMITE }
    }
    val warningStockCount = remember(filteredProducts) {
        filteredProducts.count { it.stockHealth == StockHealth.MEDIO }
    }
    val healthyStockCount = remember(filteredProducts) {
        filteredProducts.count { it.stockHealth == StockHealth.NORMAL }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(TayleNavy950)
            .padding(horizontal = 14.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 80.dp)
    ) {
        // Welcome Header & Quick Action Buttons
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(TayleNavy900, TayleNavy800)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Painel Comercial TAYLE",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TayleWhite
                                )
                                Text(
                                    text = "${currentCompany?.name ?: "TAYLE Matriz"} • ${currentUser?.name ?: "Gestor"}",
                                    fontSize = 12.sp,
                                    color = TayleSlateLight
                                )
                            }

                            // Tayle IA Quick Launcher Button
                            OutlinedButton(
                                onClick = { showAiCommercialHelperDialog = true },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = TayleCyan),
                                border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(TayleCyan, TayleNavy500))),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp), tint = TayleCyan)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("TAYLE IA", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Quick Action Direct Shortcuts (Item 10)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { showNewSaleDialog = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TayleGreen,
                                    contentColor = TayleNavy950
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_nova_venda"),
                                contentPadding = PaddingValues(vertical = 10.dp)
                            ) {
                                Icon(Icons.Filled.AttachMoney, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Nova Venda", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            Button(
                                onClick = { showNewOpportunityDialog = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TayleCyan,
                                    contentColor = TayleNavy950
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("btn_nova_oportunidade"),
                                contentPadding = PaddingValues(vertical = 10.dp)
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Novo Lead/Funil", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Acesso Rápido às Novas Funcionalidades (O.S., Catálogo Digital e Loja Virtual)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = TayleNavy800,
                                border = BorderStroke(1.dp, TayleCyan.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onNavigateToOrders() }
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Filled.Assignment, contentDescription = null, tint = TayleCyan, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Ordens O.S.", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = TayleNavy800,
                                border = BorderStroke(1.dp, TayleAmber.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onNavigateToCatalog?.invoke() }
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Filled.DesignServices, contentDescription = null, tint = TayleAmber, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Catálogo", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = TayleNavy800,
                                border = BorderStroke(1.dp, TayleGreen.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onNavigateToVirtualStore?.invoke() }
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Filled.Storefront, contentDescription = null, tint = TayleGreen, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Loja Virtual", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                                }
                            }
                        }
                    }
                }
            }
        }

        // ESTRUTURA DE UNIDADES & ACESSO (Matriz / Filiais)
        item {
            val isHeadquarters = currentUser?.isHeadquartersUser == true || currentUser?.role == UserRole.ADMINISTRADOR
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "ESTRUTURA DE UNIDADES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleCyan,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (isHeadquarters) TayleCyan.copy(alpha = 0.15f) else TayleAmber.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = if (isHeadquarters) "MATRIZ • GESTÃO TOTAL" else "FILIAL • ACESSO ISOLADO",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isHeadquarters) TayleCyan else TayleAmber,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (isHeadquarters && onAddNewBranchClick != null) {
                        TextButton(
                            onClick = onAddNewBranchClick,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Filled.AddBusiness, contentDescription = null, tint = TayleCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+ Nova Filial", fontSize = 11.sp, color = TayleCyan, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (isHeadquarters) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Consolidado
                        FilterChip(
                            selected = selectedBranch == null,
                            onClick = { onSelectBranch?.invoke(null) },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("🌐", fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Visão Consolidada", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TayleCyan,
                                selectedLabelColor = TayleNavy950,
                                containerColor = TayleNavy900,
                                labelColor = TayleWhite
                            )
                        )

                        // Branches
                        branches.forEach { branch ->
                            val isSelected = selectedBranch?.id == branch.id
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSelectBranch?.invoke(branch) },
                                label = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (branch.isHeadquarters) "🏢" else "🏪", fontSize = 13.sp)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(branch.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = if (branch.isHeadquarters) TayleCyan else TayleGreen,
                                    selectedLabelColor = TayleNavy950,
                                    containerColor = TayleNavy900,
                                    labelColor = TayleWhite
                                )
                            )
                        }
                    }
                } else {
                    // Filial user notice
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = TayleNavy900,
                        border = androidx.compose.foundation.BorderStroke(1.dp, TayleNavy800),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = TayleGreen.copy(alpha = 0.15f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("🏪", fontSize = 18.sp)
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = currentUser?.branchName ?: "Sua Unidade",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = TayleWhite
                                )
                                Text(
                                    text = "Acesso exclusivo aos dados desta unidade. Métricas e custos de outras filiais protegidos.",
                                    fontSize = 10.sp,
                                    color = TayleSlateLight
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = TayleNavy800
                            ) {
                                Text(
                                    text = "🔒 Unidade",
                                    fontSize = 10.sp,
                                    color = TayleGreen,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. DIVISÃO COMERCIAL POR DEPARTAMENTOS (Pós-Vendas, Novos, Seminovos)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "DEPARTAMENTOS COMERCIAIS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TayleSlateLight,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedDepartment == null,
                        onClick = { selectedDepartment = null },
                        label = { Text("🏢 Geral (Todos)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TayleCyan,
                            selectedLabelColor = TayleNavy950,
                            containerColor = TayleNavy900,
                            labelColor = TayleWhite
                        )
                    )

                    CommercialDepartment.entries.forEach { dept ->
                        val isSelected = selectedDepartment == dept
                        val deptColor = when (dept) {
                            CommercialDepartment.POS_VENDAS -> TayleCyan
                            CommercialDepartment.NOVOS -> TayleGreen
                            CommercialDepartment.SEMINOVOS -> TayleAmber
                        }

                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedDepartment = if (isSelected) null else dept },
                            label = {
                                Text(
                                    text = "${dept.iconEmoji} ${dept.label}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = deptColor,
                                selectedLabelColor = TayleNavy950,
                                containerColor = TayleNavy900,
                                labelColor = TayleWhite
                            )
                        )
                    }
                }
            }
        }

        // 1. DASHBOARD PRINCIPAL - 4 INDICADORES PRINCIPAIS NO TOPO
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = if (selectedDepartment == null) "INDICADORES GERAIS" else "INDICADORES • ${selectedDepartment?.label?.uppercase()}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TayleCyan,
                    letterSpacing = 1.sp
                )

                // Grid of 4 main cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 🎯 TICKET MÉDIO
                    KpiCard(
                        title = "TICKET MÉDIO",
                        value = currencyFormat.format(ticketMedio),
                        subtitle = "${filteredSales.size} vendas registradas",
                        icon = Icons.Filled.Adjust,
                        accentColor = TayleCyan,
                        modifier = Modifier.weight(1f)
                    )

                    // 💰 VENDAS DIÁRIAS
                    KpiCard(
                        title = "VENDAS DIÁRIAS",
                        value = currencyFormat.format(dailyRevenue),
                        subtitle = "$dailyCount vendas hoje",
                        icon = Icons.Filled.Today,
                        accentColor = TayleGreen,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 📅 VENDAS MENSAIS
                    KpiCard(
                        title = "VENDAS MENSAIS",
                        value = currencyFormat.format(monthlyRevenue),
                        subtitle = "$monthlyCount vendas no mês",
                        icon = Icons.Filled.DateRange,
                        accentColor = TayleAmber,
                        modifier = Modifier.weight(1f)
                    )

                    // 💵 FATURAMENTO TOTAL
                    KpiCard(
                        title = "FATURAMENTO",
                        value = currencyFormat.format(totalRevenue),
                        subtitle = "Total acumulado",
                        icon = Icons.Filled.Payments,
                        accentColor = TayleIndigo,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 2. CUSTO E LUCRO (NÃO misturar custo com lucro)
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ANÁLISE DE CUSTO E LUCRO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleSlateLight,
                            letterSpacing = 1.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (profitMarginPercent >= 30) TayleGreen.copy(alpha = 0.2f) else TayleAmber.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = "Margem: ${"%.1f".format(Locale.US, profitMarginPercent)}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (profitMarginPercent >= 30) TayleGreen else TayleAmber,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // 3 separated pillars: CUSTO TOTAL, LUCRO BRUTO, MARGEM DE LUCRO
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // 💸 CUSTO TOTAL
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = TayleNavy800,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("💸", fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("CUSTO TOTAL", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleRedLight)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currencyFormat.format(totalCost),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text("Investimento", fontSize = 9.sp, color = TayleSlateLight)
                            }
                        }

                        // 📈 LUCRO BRUTO
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = TayleNavy800,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("📈", fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("LUCRO BRUTO", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleGreen)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currencyFormat.format(grossProfit),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleGreen,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text("Faturamento - Custo", fontSize = 9.sp, color = TayleSlateLight)
                            }
                        }

                        // 📊 MARGEM DE LUCRO (%)
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = TayleNavy800,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("📊", fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("MARGEM (%)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${"%.1f".format(Locale.US, profitMarginPercent)}%",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleCyan,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text("Retorno Líquido", fontSize = 9.sp, color = TayleSlateLight)
                            }
                        }
                    }

                    // Visual balance bar
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Distribuição Financeira", fontSize = 10.sp, color = TayleSlateLight)
                            Text(
                                "Lucro: ${currencyFormat.format(grossProfit)} • Custo: ${currencyFormat.format(totalCost)}",
                                fontSize = 10.sp,
                                color = TayleWhite
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(TayleNavy700)
                        ) {
                            val profitFraction = if (totalRevenue > 0) (grossProfit / totalRevenue).coerceIn(0.0, 1.0).toFloat() else 0.5f
                            Box(
                                modifier = Modifier
                                    .weight(profitFraction.coerceAtLeast(0.05f))
                                    .fillMaxHeight()
                                    .background(TayleGreen)
                            )
                            Box(
                                modifier = Modifier
                                    .weight((1f - profitFraction).coerceAtLeast(0.05f))
                                    .fillMaxHeight()
                                    .background(TayleRedLight)
                            )
                        }
                    }
                }
            }
        }

        // 5. FUNIL DE VENDAS (PIPELINE VISUAL DE 5 ETAPAS)
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "FUNIL DE VENDAS (PIPELINE)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TayleSlateLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "${filteredOpportunities.size} oportunidades ativas",
                                fontSize = 12.sp,
                                color = TayleCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        IconButton(
                            onClick = { showNewOpportunityDialog = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Filled.AddCircle, contentDescription = "Adicionar Lead", tint = TayleCyan)
                        }
                    }

                    // 5 Pipeline Stage Columns / Indicators
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FunnelStage.entries.forEach { stage ->
                            val oppsInStage = filteredOpportunities.filter { it.stage == stage }
                            val stageValue = oppsInStage.sumOf { it.potentialValue }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = TayleNavy800,
                                modifier = Modifier.width(130.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${stage.step}. ${stage.title}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TayleWhite
                                        )
                                        Surface(
                                            shape = CircleShape,
                                            color = TayleNavy700,
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "${oppsInStage.size}",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = TayleCyan
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = currencyFormat.format(stageValue),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TayleGreen
                                    )
                                }
                            }
                        }
                    }

                    // Highlighted Opportunities List (🔥 Quentes, 🟡 Negociando, 🔴 Paradas)
                    Text(
                        text = "OPORTUNIDADES EM DESTAQUE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleSlateLight
                    )

                    filteredOpportunities.take(4).forEach { opp ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = TayleNavy800,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${opp.temperature.emoji} ${opp.title}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = TayleWhite
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${opp.clientName} • ${opp.department.label} (${opp.sellerName})",
                                        fontSize = 11.sp,
                                        color = TayleSlateLight
                                    )
                                    Text(
                                        text = "Etapa: ${opp.stage.title} • Valor: ${currencyFormat.format(opp.potentialValue)}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TayleGreen
                                    )
                                }

                                // Quick Advance Stage Button
                                if (opp.stage != FunnelStage.FECHAMENTO) {
                                    val nextStage = FunnelStage.entries.firstOrNull { it.step == opp.stage.step + 1 }
                                    if (nextStage != null) {
                                        OutlinedButton(
                                            onClick = { onUpdateOpportunityStage(opp, nextStage) },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TayleCyan),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text("Avançar", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            Icon(Icons.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(12.dp))
                                        }
                                    }
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = TayleGreen.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "Fechado",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TayleGreen,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. ESTOQUE COMERCIAL INTELIGENTE
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "ESTOQUE COMERCIAL INTELIGENTE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TayleSlateLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "$totalStockItems itens disponíveis",
                                fontSize = 12.sp,
                                color = TayleWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        TextButton(onClick = onNavigateToStock) {
                            Text("Ver Insumos", color = TayleCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Metrics: Custo Investido vs Faturamento Potencial vs Lucro Projetado
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TayleNavy800,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("INVESTIDO (CUSTO)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TayleRedLight)
                                Text(currencyFormat.format(stockInvestedCost), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TayleNavy800,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("POTENCIAL VENDA", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                                Text(currencyFormat.format(stockPotentialRevenue), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TayleNavy800,
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("LUCRO PROJETADO", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = TayleGreen)
                                Text(currencyFormat.format(stockProjectedProfit), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleGreen)
                            }
                        }
                    }

                    // Status Indicators (🔴 Limite/Reposição, 🟡 Atenção, 🟢 Ideal)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = CircleShape, color = TayleRedLight, modifier = Modifier.size(8.dp)) {}
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Crítico / Reposição ($criticalStockCount)", fontSize = 10.sp, color = TayleRedLight, fontWeight = FontWeight.SemiBold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = CircleShape, color = TayleAmber, modifier = Modifier.size(8.dp)) {}
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Atenção ($warningStockCount)", fontSize = 10.sp, color = TayleAmber, fontWeight = FontWeight.SemiBold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(shape = CircleShape, color = TayleGreen, modifier = Modifier.size(8.dp)) {}
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ideal ($healthyStockCount)", fontSize = 10.sp, color = TayleGreen, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // Key Commercial Products Preview
                    filteredProducts.take(3).forEach { prod ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TayleNavy800,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(prod.stockHealth.symbol, fontSize = 12.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = prod.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = TayleWhite
                                        )
                                    }
                                    Text(
                                        text = "Qtd: ${prod.stockCurrent} un • Custo: ${currencyFormat.format(prod.costPrice)} • Venda: ${currencyFormat.format(prod.activePrice)}",
                                        fontSize = 10.sp,
                                        color = TayleSlateLight
                                    )
                                    Text(
                                        text = "Lucro unitário: ${currencyFormat.format(prod.profit)} (${"%.1f".format(Locale.US, prod.profitMarginPercent)}%)",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TayleGreen
                                    )
                                }

                                IconButton(
                                    onClick = { showStockMovementDialog = prod },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Filled.SwapVert, contentDescription = "Movimentar", tint = TayleCyan)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 7. AGENDA DIÁRIA DO VENDEDOR (🌅 Início, ☀️ Durante, 🌆 Final)
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "AGENDA DIÁRIA DE VENDAS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TayleSlateLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Rotina produtiva do vendedor",
                                fontSize = 12.sp,
                                color = TayleWhite,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        IconButton(
                            onClick = { showNewTaskDialog = true },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Filled.AddTask, contentDescription = "Nova Tarefa", tint = TayleCyan)
                        }
                    }

                    // 3 Periods: Início, Durante, Final
                    AgendaDayPeriod.entries.forEach { period ->
                        val tasksInPeriod = dailyAgendaTasks.filter { it.period == period }
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(period.emoji, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = period.title.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleCyan
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "(${tasksInPeriod.count { it.isCompleted }}/${tasksInPeriod.size})",
                                    fontSize = 10.sp,
                                    color = TayleSlateLight
                                )
                            }

                            if (tasksInPeriod.isEmpty()) {
                                Text(
                                    text = "Nenhuma tarefa agendada para este bloco.",
                                    fontSize = 11.sp,
                                    color = TayleSlateLight
                                )
                            } else {
                                tasksInPeriod.forEach { task ->
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = TayleNavy800,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Checkbox(
                                                    checked = task.isCompleted,
                                                    onCheckedChange = { onToggleDailyTask(task) },
                                                    colors = CheckboxDefaults.colors(
                                                        checkedColor = TayleGreen,
                                                        checkmarkColor = TayleNavy950
                                                    )
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Column {
                                                    Text(
                                                        text = task.title,
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = if (task.isCompleted) TayleSlateLight else TayleWhite
                                                    )
                                                    Text(
                                                        text = "${task.clientName} • ${task.targetAction}",
                                                        fontSize = 10.sp,
                                                        color = TayleSlateLight
                                                    )
                                                }
                                            }

                                            // Direct WhatsApp / Contact button
                                            if (task.clientPhone.isNotBlank()) {
                                                IconButton(
                                                    onClick = {
                                                        try {
                                                            val clean = task.clientPhone.replace("[^0-9]".toRegex(), "")
                                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=55$clean&text=Ol%C3%A1%20${Uri.encode(task.clientName)},%20sou%20o%20${Uri.encode(currentUser?.name ?: "consultor")}%20da%20TAYLE."))
                                                            context.startActivity(intent)
                                                        } catch (e: Exception) {
                                                            // Ignore if no browser
                                                        }
                                                    },
                                                    modifier = Modifier.size(30.dp)
                                                ) {
                                                    Icon(Icons.Filled.Chat, contentDescription = "WhatsApp", tint = TayleGreen, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 6. RANKING DE VENDAS E PRODUTIVIDADE
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "RANKING DE VENDEDORES & COMISSÃO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleSlateLight,
                            letterSpacing = 1.sp
                        )
                        Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = TayleAmber)
                    }

                    // Group sales by seller
                    val sellerStats = remember(filteredSales) {
                        filteredSales.groupBy { it.sellerName }
                            .map { (seller, sales) ->
                                val count = sales.sumOf { it.quantity }
                                val rev = sales.sumOf { it.revenue }
                                val tkt = if (count > 0) rev / count else 0.0
                                val commission = rev * 0.03 // 3% comissão
                                SellerPerformance(seller, count, rev, tkt, commission)
                            }
                            .sortedByDescending { it.revenue }
                    }

                    if (sellerStats.isEmpty()) {
                        Text("Nenhum dado de vendas disponível para ranking.", fontSize = 11.sp, color = TayleSlateLight)
                    } else {
                        sellerStats.take(4).forEachIndexed { idx, stat ->
                            val medal = when (idx) {
                                0 -> "🥇"
                                1 -> "🥈"
                                2 -> "🥉"
                                else -> "👤"
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = TayleNavy800,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(medal, fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(stat.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TayleWhite)
                                            Text("${stat.salesCount} vendas • Ticket: ${currencyFormat.format(stat.ticketMedio)}", fontSize = 10.sp, color = TayleSlateLight)
                                        }
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(currencyFormat.format(stat.revenue), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TayleGreen)
                                        Text("Comissão: ${currencyFormat.format(stat.commission)}", fontSize = 10.sp, color = TayleCyan)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 7.2. RANKING DE FILIAIS E DESEMPENHO DE UNIDADES
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "RANKING DE UNIDADES & FILIAIS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleSlateLight,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = TayleAmber.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "🏆 NACIONAL",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TayleAmber,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Classificação por faturamento, volume e ticket médio",
                                fontSize = 10.sp,
                                color = TayleSlateLight
                            )
                        }
                        Icon(Icons.Filled.Leaderboard, contentDescription = null, tint = TayleAmber)
                    }

                    val salesForRanking = if (allCompanySales.isNotEmpty()) allCompanySales else commercialSales
                    val branchRankingList = remember(salesForRanking, branches) {
                        if (branches.isEmpty()) {
                            emptyList()
                        } else {
                            branches.map { b ->
                                val bSales = salesForRanking.filter { s ->
                                    s.branchId == b.id || s.branchName.contains(b.name, ignoreCase = true) || s.branch.contains(b.name, ignoreCase = true)
                                }
                                val count = bSales.sumOf { it.quantity }
                                val rev = bSales.sumOf { it.revenue }
                                val tkt = if (count > 0) rev / count else 0.0
                                BranchPerformance(
                                    branch = b,
                                    salesCount = count,
                                    revenue = rev,
                                    ticketMedio = tkt
                                )
                            }.sortedByDescending { it.revenue }
                        }
                    }

                    if (branchRankingList.isEmpty()) {
                        Text("Nenhuma unidade com movimentação registrada ainda.", fontSize = 11.sp, color = TayleSlateLight)
                    } else {
                        branchRankingList.forEachIndexed { idx, itemRank ->
                            val medal = when (idx) {
                                0 -> "🥇"
                                1 -> "🥈"
                                2 -> "🥉"
                                else -> "${idx + 1}º"
                            }
                            val isCurrentUserBranch = currentUser?.branchId == itemRank.branch.id || (currentUser?.isHeadquartersUser == true && itemRank.branch.isHeadquarters)

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isCurrentUserBranch) TayleNavy800 else TayleNavy950.copy(alpha = 0.6f),
                                border = if (isCurrentUserBranch) androidx.compose.foundation.BorderStroke(1.dp, TayleCyan.copy(alpha = 0.5f)) else null,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(medal, fontSize = 16.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Column {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = "${if (itemRank.branch.isHeadquarters) "🏢" else "🏪"} ${itemRank.branch.name}",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = TayleWhite
                                                    )
                                                    if (isCurrentUserBranch) {
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = TayleCyan.copy(alpha = 0.2f)
                                                        ) {
                                                            Text(
                                                                text = "Sua Unidade",
                                                                fontSize = 9.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = TayleCyan,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                                Text(
                                                    text = "Cód: ${itemRank.branch.code} • Resp: ${itemRank.branch.managerName}",
                                                    fontSize = 10.sp,
                                                    color = TayleSlateLight
                                                )
                                            }
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = currencyFormat.format(itemRank.revenue),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = TayleGreen
                                            )
                                            Text(
                                                text = "${itemRank.salesCount} vendas",
                                                fontSize = 11.sp,
                                                color = TayleSlateLight
                                            )
                                        }
                                    }

                                    // Metric summary bar
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(TayleNavy900, RoundedCornerShape(6.dp))
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "🎯 Ticket Médio da Unidade:",
                                            fontSize = 11.sp,
                                            color = TayleSlateLight
                                        )
                                        Text(
                                            text = currencyFormat.format(itemRank.ticketMedio),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TayleCyan
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Text(
                        text = "ℹ️ O ranking de filiais é compartilhado entre todas as unidades para incentivar o atingimento de metas e performance comercial.",
                        fontSize = 10.sp,
                        color = TayleSlateLight,
                        lineHeight = 14.sp
                    )
                }
            }
        }

        // 8. VENDAS PERDIDAS E RECUPERAÇÃO
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TayleNavy900,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "VENDAS PERDIDAS E RECUPERAÇÃO",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = TayleSlateLight,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "${lostSales.count { !it.isRecovered }} clientes com potencial de resgate",
                                fontSize = 12.sp,
                                color = TayleRedLight,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    lostSales.take(3).forEach { lost ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = TayleNavy800,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = lost.clientName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = TayleWhite
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = TayleRedLight.copy(alpha = 0.2f)
                                        ) {
                                            Text(
                                                text = "Motivo: ${lost.reason.label}",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TayleRedLight,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${lost.productOrService} • Valor: ${currencyFormat.format(lost.value)}",
                                        fontSize = 10.sp,
                                        color = TayleSlateLight
                                    )
                                    if (lost.isRecovered) {
                                        Text("✅ Recuperado com sucesso!", fontSize = 10.sp, color = TayleGreen, fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (!lost.isRecovered) {
                                    Button(
                                        onClick = { showRecoveryDialog = lost },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = TayleAmber,
                                            contentColor = TayleNavy950
                                        ),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Recuperar", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // DIALOG: REGISTRAR NOVA VENDA COMERCIAL (Item 10)
    if (showNewSaleDialog) {
        NewCommercialSaleDialog(
            companyId = currentCompany?.id ?: "comp_matriz",
            sellerName = currentUser?.name ?: "Vendedor Master",
            products = commercialProducts,
            onDismiss = { showNewSaleDialog = false },
            onConfirm = { sale, product ->
                onRegisterCommercialSale(sale, product)
                showNewSaleDialog = false
            }
        )
    }

    // DIALOG: NOVA OPORTUNIDADE NO FUNIL (Item 10)
    if (showNewOpportunityDialog) {
        NewOpportunityDialog(
            companyId = currentCompany?.id ?: "comp_matriz",
            sellerName = currentUser?.name ?: "Consultor Comercial",
            onDismiss = { showNewOpportunityDialog = false },
            onConfirm = { opp ->
                onSaveSalesOpportunity(opp)
                showNewOpportunityDialog = false
            }
        )
    }

    // DIALOG: TAYLE IA ASSISTENTE COMERCIAL (Item 9)
    if (showAiCommercialHelperDialog) {
        TayleAiCommercialDialog(
            onDismiss = { showAiCommercialHelperDialog = false }
        )
    }

    // DIALOG: NOVA TAREFA NA AGENDA
    if (showNewTaskDialog) {
        NewAgendaTaskDialog(
            companyId = currentCompany?.id ?: "comp_matriz",
            sellerName = currentUser?.name ?: "Vendedor",
            onDismiss = { showNewTaskDialog = false },
            onConfirm = { task ->
                onSaveDailyTask(task)
                showNewTaskDialog = false
            }
        )
    }

    // DIALOG: MOVIMENTAÇÃO DE ESTOQUE (+ Entrada / - Saída)
    showStockMovementDialog?.let { product ->
        StockMovementDialog(
            product = product,
            userName = currentUser?.name ?: "Gestor",
            onDismiss = { showStockMovementDialog = null },
            onConfirm = { isEntry, qty, reason ->
                onStockMovement(product, isEntry, qty, reason, currentUser?.name ?: "Gestor", todayFormatted)
                showStockMovementDialog = null
            }
        )
    }

    // DIALOG: RECUPERAÇÃO DE VENDA PERDIDA
    showRecoveryDialog?.let { lost ->
        RecoverySaleDialog(
            lostSale = lost,
            onDismiss = { showRecoveryDialog = null },
            onConfirm = {
                onRecoverLostSale(lost)
                showRecoveryDialog = null
            }
        )
    }
}

// Helper data class for ranking
data class SellerPerformance(
    val name: String,
    val salesCount: Int,
    val revenue: Double,
    val ticketMedio: Double,
    val commission: Double
)

@Composable
fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = TayleNavy900,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = TayleSlateLight,
                    letterSpacing = 0.5.sp
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
                }
            }

            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = TayleWhite,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = TayleSlateLight,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// -----------------------------------------------------------------------------------------
// DIALOGS
// -----------------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewCommercialSaleDialog(
    companyId: String,
    sellerName: String,
    products: List<CommercialProduct>,
    onDismiss: () -> Unit,
    onConfirm: (CommercialSale, CommercialProduct?) -> Unit
) {
    var clientName by remember { mutableStateOf("") }
    var selectedDepartment by remember { mutableStateOf(CommercialDepartment.NOVOS) }
    var selectedProduct by remember { mutableStateOf<CommercialProduct?>(products.firstOrNull()) }
    var customProductName by remember { mutableStateOf("") }
    var quantityText by remember { mutableStateOf("1") }
    var salePriceText by remember { mutableStateOf(selectedProduct?.activePrice?.toString() ?: "1500.00") }
    var costPriceText by remember { mutableStateOf(selectedProduct?.costPrice?.toString() ?: "900.00") }

    val qty = quantityText.toIntOrNull() ?: 1
    val salePrice = salePriceText.toDoubleOrNull() ?: 0.0
    val costPrice = costPriceText.toDoubleOrNull() ?: 0.0

    val revenue = salePrice * qty
    val totalCost = costPrice * qty
    val profit = revenue - totalCost
    val margin = if (revenue > 0) (profit / revenue) * 100.0 else 0.0

    val currencyFormat = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }
    val todayFormatted = remember { SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR")).format(Date()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PointOfSale, contentDescription = null, tint = TayleGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Registrar Venda Comercial", color = TayleWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it },
                    label = { Text("Nome do Cliente", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Select Department
                Text("Departamento:", fontSize = 11.sp, color = TayleSlateLight, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CommercialDepartment.entries.forEach { dept ->
                        val isSelected = selectedDepartment == dept
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedDepartment = dept },
                            label = { Text(dept.label, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TayleCyan,
                                selectedLabelColor = TayleNavy950,
                                containerColor = TayleNavy800,
                                labelColor = TayleWhite
                            )
                        )
                    }
                }

                // Select Product or Custom
                OutlinedTextField(
                    value = customProductName.ifBlank { selectedProduct?.name ?: "" },
                    onValueChange = { customProductName = it },
                    label = { Text("Produto / Serviço", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("Qtd", color = TayleSlateLight) },
                        modifier = Modifier.weight(0.8f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite,
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700
                        )
                    )

                    OutlinedTextField(
                        value = salePriceText,
                        onValueChange = { salePriceText = it },
                        label = { Text("Preço Venda (R$)", color = TayleSlateLight) },
                        modifier = Modifier.weight(1.2f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite,
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700
                        )
                    )

                    OutlinedTextField(
                        value = costPriceText,
                        onValueChange = { costPriceText = it },
                        label = { Text("Custo (R$)", color = TayleSlateLight) },
                        modifier = Modifier.weight(1.2f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TayleWhite,
                            unfocusedTextColor = TayleWhite,
                            focusedBorderColor = TayleCyan,
                            unfocusedBorderColor = TayleNavy700
                        )
                    )
                }

                // Instant Calculation Box (Custo, Lucro, Margem)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleNavy800,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Faturamento:", fontSize = 11.sp, color = TayleSlateLight)
                            Text(currencyFormat.format(revenue), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Custo Total:", fontSize = 11.sp, color = TayleRedLight)
                            Text(currencyFormat.format(totalCost), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TayleRedLight)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Lucro Bruto:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleGreen)
                            Text(currencyFormat.format(profit), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleGreen)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Margem de Lucro:", fontSize = 11.sp, color = TayleCyan)
                            Text("${"%.1f".format(Locale.US, margin)}%", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (clientName.isNotBlank() && salePrice > 0) {
                        val finalProductName = customProductName.ifBlank { selectedProduct?.name ?: "Produto Comercial" }
                        val sale = CommercialSale(
                            id = UUID.randomUUID().toString(),
                            companyId = companyId,
                            dateFormatted = todayFormatted,
                            monthPeriod = SimpleDateFormat("MM/yyyy", Locale.getDefault()).format(Date()),
                            clientName = clientName.trim(),
                            sellerName = sellerName,
                            department = selectedDepartment,
                            productName = finalProductName,
                            quantity = qty,
                            salePrice = salePrice,
                            costPrice = costPrice
                        )
                        onConfirm(sale, selectedProduct)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TayleGreen, contentColor = TayleNavy950)
            ) {
                Text("Confirmar Venda", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}

@Composable
fun NewOpportunityDialog(
    companyId: String,
    sellerName: String,
    onDismiss: () -> Unit,
    onConfirm: (SalesOpportunity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var clientName by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }
    var valueText by remember { mutableStateOf("") }
    var selectedStage by remember { mutableStateOf(FunnelStage.LEAD) }
    var selectedTemp by remember { mutableStateOf(OpportunityTemperature.QUENTE) }
    var selectedDept by remember { mutableStateOf(CommercialDepartment.NOVOS) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Text("Nova Oportunidade no Funil", color = TayleWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Título da Oportunidade (Ex: Corolla 2024)", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it },
                    label = { Text("Nome do Cliente", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = clientPhone,
                    onValueChange = { clientPhone = it },
                    label = { Text("WhatsApp do Cliente", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = valueText,
                    onValueChange = { valueText = it },
                    label = { Text("Valor Estimado (R$)", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Temperature
                Text("Temperatura da Oportunidade:", fontSize = 11.sp, color = TayleSlateLight, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OpportunityTemperature.entries.forEach { temp ->
                        val isSelected = selectedTemp == temp
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedTemp = temp },
                            label = { Text("${temp.emoji} ${temp.label.take(8)}", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TayleAmber,
                                selectedLabelColor = TayleNavy950,
                                containerColor = TayleNavy800,
                                labelColor = TayleWhite
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && clientName.isNotBlank()) {
                        val opp = SalesOpportunity(
                            id = UUID.randomUUID().toString(),
                            companyId = companyId,
                            clientName = clientName.trim(),
                            clientPhone = clientPhone.trim(),
                            title = title.trim(),
                            potentialValue = valueText.toDoubleOrNull() ?: 0.0,
                            stage = selectedStage,
                            temperature = selectedTemp,
                            department = selectedDept,
                            sellerName = sellerName
                        )
                        onConfirm(opp)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950)
            ) {
                Text("Salvar Oportunidade", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}

@Composable
fun TayleAiCommercialDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedTool by remember { mutableStateOf(0) }
    var promptInput by remember { mutableStateOf("Vitrificação Cerâmica Premium para cliente que achou caro") }
    var generatedResult by remember {
        mutableStateOf(
            "Olá! Entendo perfeitamente sua preocupação com o investimento. Vale destacar que a Vitrificação Cerâmica protege a pintura por até 3 anos, evitando repinturas que custam 4x mais e valorizando em até 15% a revenda do seu veículo. Além disso, parcelamos em até 10x sem juros. Posso reservar o seu horário para amanhã?"
        )
    }

    val tools = listOf(
        "💡 Argumentos de Vendas",
        "🔄 Recuperar Proposta",
        "⚡ Pitch Rápido",
        "📲 Follow-up WhatsApp"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = TayleCyan)
                Spacer(modifier = Modifier.width(8.dp))
                Text("TAYLE IA Comercial", color = TayleWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Tool selection tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tools.forEachIndexed { index, tool ->
                        FilterChip(
                            selected = selectedTool == index,
                            onClick = {
                                selectedTool = index
                                when (index) {
                                    0 -> {
                                        promptInput = "Vitrificação Cerâmica para cliente focado em durabilidade"
                                        generatedResult = "Com a Vitrificação 9H, você cria uma camada de proteção nano-tecnológica contra raios UV, fezes de pássaros e micro-riscos. O brilho fica permanente como se o carro tivesse acabado de sair da concessionária."
                                    }
                                    1 -> {
                                        promptInput = "Cliente sumiu após envio de proposta de R$ 3.500"
                                        generatedResult = "Oi, tudo bem? Sei que a rotina é corrida! Consegui com meu diretor uma condição especial exclusiva válida até esta sexta-feira: aplicação de cristalização dos vidros de cortesia mantendo o mesmo valor. Vamos fechar?"
                                    }
                                    2 -> {
                                        promptInput = "Pacote de Higienização de Ozônio e Ar Condicionado"
                                        generatedResult = "Elimine 99.9% dos ácaros, fungos e odores em apenas 40 minutos com o poder do Ozônio. Saúde para sua família e ar puro no seu trajeto diário."
                                    }
                                    3 -> {
                                        promptInput = "Follow-up 24h após visita no showroom"
                                        generatedResult = "Olá! Foi um prazer recebê-lo ontem na TAYLE. Como prometido, separei a cotação detalhada e a simulação de parcelamento. Tem algum ponto que gostaria de ajustar?"
                                    }
                                }
                            },
                            label = { Text(tool, fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TayleCyan,
                                selectedLabelColor = TayleNavy950,
                                containerColor = TayleNavy800,
                                labelColor = TayleWhite
                            )
                        )
                    }
                }

                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    label = { Text("Objetivo comercial ou produto", color = TayleSlateLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Generated Output Box
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleNavy800,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("SUGESTÃO TAYLE IA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TayleCyan)
                            IconButton(
                                onClick = {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, generatedResult)
                                        type = "text/plain"
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Compartilhar texto"))
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Filled.Share, contentDescription = "Compartilhar", tint = TayleSlateLight, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text(
                            text = generatedResult,
                            fontSize = 12.sp,
                            color = TayleWhite
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950)
            ) {
                Text("Concluir", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun NewAgendaTaskDialog(
    companyId: String,
    sellerName: String,
    onDismiss: () -> Unit,
    onConfirm: (DailyAgendaTask) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var clientName by remember { mutableStateOf("") }
    var clientPhone by remember { mutableStateOf("") }
    var targetAction by remember { mutableStateOf("Ligar para confirmar proposta") }
    var selectedPeriod by remember { mutableStateOf(AgendaDayPeriod.INICIO_DO_DIA) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Text("Nova Tarefa do Vendedor", color = TayleWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Título da Tarefa", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it },
                    label = { Text("Cliente", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = clientPhone,
                    onValueChange = { clientPhone = it },
                    label = { Text("Telefone / WhatsApp", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Period Choice
                Text("Bloco do Dia:", fontSize = 11.sp, color = TayleSlateLight, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AgendaDayPeriod.entries.forEach { p ->
                        FilterChip(
                            selected = selectedPeriod == p,
                            onClick = { selectedPeriod = p },
                            label = { Text("${p.emoji} ${p.title.take(6)}", fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TayleCyan,
                                selectedLabelColor = TayleNavy950,
                                containerColor = TayleNavy800,
                                labelColor = TayleWhite
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val task = DailyAgendaTask(
                            id = UUID.randomUUID().toString(),
                            companyId = companyId,
                            sellerName = sellerName,
                            period = selectedPeriod,
                            title = title.trim(),
                            clientName = clientName.trim(),
                            clientPhone = clientPhone.trim(),
                            targetAction = targetAction
                        )
                        onConfirm(task)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950)
            ) {
                Text("Agendar Tarefa", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}

@Composable
fun StockMovementDialog(
    product: CommercialProduct,
    userName: String,
    onDismiss: () -> Unit,
    onConfirm: (Boolean, Int, String) -> Unit
) {
    var isEntry by remember { mutableStateOf(true) }
    var quantityText by remember { mutableStateOf("5") }
    var reason by remember { mutableStateOf("Reposição de estoque comercial") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Text("Movimentação de Estoque: ${product.name}", color = TayleWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Estoque atual: ${product.stockCurrent} un", fontSize = 12.sp, color = TayleCyan, fontWeight = FontWeight.Bold)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { isEntry = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isEntry) TayleGreen else TayleNavy800,
                            contentColor = if (isEntry) TayleNavy950 else TayleWhite
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("➕ Entrada", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { isEntry = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isEntry) TayleRedLight else TayleNavy800,
                            contentColor = if (!isEntry) TayleNavy950 else TayleWhite
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("➖ Saída", fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { quantityText = it },
                    label = { Text("Quantidade", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Motivo / Observação", color = TayleSlateLight) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityText.toIntOrNull() ?: 1
                    onConfirm(isEntry, qty, reason)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isEntry) TayleGreen else TayleRedLight,
                    contentColor = TayleNavy950
                )
            ) {
                Text(if (isEntry) "Confirmar Entrada" else "Confirmar Saída", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}

@Composable
fun RecoverySaleDialog(
    lostSale: LostSale,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val context = LocalContext.current
    var recoveryMessage by remember {
        mutableStateOf(
            "Olá ${lostSale.clientName}! Analisei sua solicitação para ${lostSale.productOrService} e consegui uma condição inédita: 10% de desconto ou bônus especial caso feche esta semana. Podemos conversar?"
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        title = {
            Text("Recuperar Venda: ${lostSale.clientName}", color = TayleWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Motivo registrado: ${lostSale.reason.label}", fontSize = 11.sp, color = TayleRedLight, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = recoveryMessage,
                    onValueChange = { recoveryMessage = it },
                    label = { Text("Mensagem de Reativação no WhatsApp", color = TayleSlateLight) },
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TayleWhite,
                        unfocusedTextColor = TayleWhite,
                        focusedBorderColor = TayleCyan,
                        unfocusedBorderColor = TayleNavy700
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (lostSale.clientPhone.isNotBlank()) {
                        val clean = lostSale.clientPhone.replace("[^0-9]".toRegex(), "")
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=55$clean&text=${Uri.encode(recoveryMessage)}"))
                        context.startActivity(intent)
                    }
                    onConfirm()
                },
                colors = ButtonDefaults.buttonColors(containerColor = TayleGreen, contentColor = TayleNavy950)
            ) {
                Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Enviar WhatsApp & Marcar Recuperado", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar", color = TayleSlateLight)
            }
        }
    )
}

data class BranchPerformance(
    val branch: Branch,
    val salesCount: Int,
    val revenue: Double,
    val ticketMedio: Double
)
