package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TayleNavy900 = Color(0xFF0B132B)
val TayleNavy800 = Color(0xFF111D4A)
val TayleNavy700 = Color(0xFF1C2541)
val TayleSlateBorder = Color(0xFF273549)
val TayleSlateMuted = Color(0xFF6D7993)
val TayleSlateLight = Color(0xFF9DA8B8)
val TayleCobalt = Color(0xFF0052FF)
val TayleCobaltLight = Color(0xFF387BFF)
val TayleCyan = Color(0xFF00D4FF)
val TayleEmerald = Color(0xFF10B981)
val TayleEmeraldDark = Color(0xFF059669)
val TayleAmber = Color(0xFFF59E0B)
val TayleRose = Color(0xFFEF4444)
val TaylePurple = Color(0xFF8B5CF6)
val TayleCardDark = Color(0xFF141F36)
val TayleCardHeader = Color(0xFF1A2644)
val TayleTextPrimary = Color(0xFFF8FAFC)
val TayleTextSecondary = Color(0xFF94A3B8)
val TayleTextTertiary = Color(0xFF64748B)

val TayleWhite = Color(0xFFFFFFFF)
val TayleNavy950 = Color(0xFF070C1E)
val TayleNavy500 = Color(0xFF203A6A)
val TayleIndigo = Color(0xFF6366F1)
val TayleGreen = Color(0xFF10B981)
val TayleRedLight = Color(0xFFF87171)

// CORES CONSISTENTES POR DEPARTAMENTO (Item 10)
val DeptPosVendasColor = Color(0xFF0284C7) // 🔵 Pós-Vendas
val DeptNovosColor = Color(0xFF10B981)     // 🟢 Novos
val DeptSeminovosColor = Color(0xFFF59E0B) // 🟠 Seminovos

val TayleLightBg = Color(0xFFF8FAFC)
val TayleLightSurface = Color(0xFFFFFFFF)
val TayleLightBorder = Color(0xFFE2E8F0)
val TayleLightTextPrimary = Color(0xFF0F172A)
val TayleLightTextSecondary = Color(0xFF475569)
