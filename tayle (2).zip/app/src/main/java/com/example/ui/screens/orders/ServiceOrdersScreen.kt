package com.example.ui.screens.orders

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Branch
import com.example.data.model.OsPriority
import com.example.data.model.OsStatus
import com.example.data.model.ServiceCatalogItem
import com.example.data.model.ServiceOrder
import com.example.data.model.ServiceOrderItem
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceOrdersScreen(
    orders: List<ServiceOrder>,
    catalogServices: List<ServiceCatalogItem>,
    currentUser: User?,
    selectedBranch: Branch?,
    onUpdateOrderStatus: (ServiceOrder, OsStatus) -> Unit,
    onDeleteOrder: (String) -> Unit,
    onNewOrderClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf<OsStatus?>(null) }
    var selectedOrderForDetail by remember { mutableStateOf<ServiceOrder?>(null) }
    var selectedOrderForShare by remember { mutableStateOf<ServiceOrder?>(null) }
    var orderToDelete by remember { mutableStateOf<ServiceOrder?>(null) }

    // Metrics
    val totalOrdersCount = orders.size
    val openOrdersCount = orders.count { it.status == OsStatus.ABERTA || it.status == OsStatus.PENDENTE }
    val inProgressCount = orders.count { it.status == OsStatus.EM_EXECUCAO || it.status == OsStatus.EM_ANDAMENTO }
    val waitingCount = orders.count { it.status == OsStatus.AGUARDANDO }
    val completedCount = orders.count { it.status == OsStatus.CONCLUIDA || it.status == OsStatus.ENTREGUE }
    val totalRevenue = orders.filter { it.status != OsStatus.CANCELADA }.sumOf { it.totalAmount }

    // Filtered orders
    val filteredOrders = remember(orders, searchQuery, selectedStatusFilter) {
        orders.filter { order ->
            val matchesQuery = searchQuery.isBlank() ||
                    order.displayPlate.contains(searchQuery, ignoreCase = true) ||
                    order.osNumber.contains(searchQuery, ignoreCase = true) ||
                    order.displayModel.contains(searchQuery, ignoreCase = true) ||
                    order.displayClientName.contains(searchQuery, ignoreCase = true)

            val matchesStatus = selectedStatusFilter == null || order.status == selectedStatusFilter

            matchesQuery && matchesStatus
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = TayleNavy950,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNewOrderClick,
                containerColor = TayleCyan,
                contentColor = TayleNavy950,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Nova O.S.", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_new_service_order")
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header with title and branch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Ordens de Serviço",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    Text(
                        text = if (selectedBranch != null) "Filial: ${selectedBranch.name} (${selectedBranch.code})" else "Visão Consolidada de Unidades",
                        fontSize = 12.sp,
                        color = TayleSlateLight
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleCyan.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, TayleCyan.copy(alpha = 0.4f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DirectionsCar,
                            contentDescription = null,
                            tint = TayleCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${orders.size} O.S.",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Metric summary cards (Horizontal scroll)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    MetricChip(
                        title = "Faturamento O.S.",
                        value = "R$ ${"%,.2f".format(Locale.GERMANY, totalRevenue)}",
                        icon = Icons.Filled.Payments,
                        color = TayleGreen
                    )
                }
                item {
                    MetricChip(
                        title = "Abertas",
                        value = "$openOrdersCount",
                        icon = Icons.Filled.HourglassEmpty,
                        color = TayleAmber
                    )
                }
                item {
                    MetricChip(
                        title = "Em Execução",
                        value = "$inProgressCount",
                        icon = Icons.Filled.Engineering,
                        color = TayleCyan
                    )
                }
                item {
                    MetricChip(
                        title = "Aguardando",
                        value = "$waitingCount",
                        icon = Icons.Filled.Schedule,
                        color = Color(0xFFF97316)
                    )
                }
                item {
                    MetricChip(
                        title = "Concluídas",
                        value = "$completedCount",
                        icon = Icons.Filled.CheckCircle,
                        color = TayleGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar (Plate, OS Number, Model, Client)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Buscar por placa, nº O.S., modelo ou cliente...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Buscar",
                        tint = TayleSlateLight
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Limpar", tint = TayleSlateLight)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("os_search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = TayleCyan,
                    unfocusedBorderColor = TayleNavy700,
                    focusedTextColor = TayleWhite,
                    unfocusedTextColor = TayleWhite,
                    focusedContainerColor = TayleNavy900,
                    unfocusedContainerColor = TayleNavy900
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Status Filter Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedStatusFilter == null,
                        onClick = { selectedStatusFilter = null },
                        label = { Text("Todas (${orders.size})", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = TayleCyan,
                            selectedLabelColor = TayleNavy950,
                            containerColor = TayleNavy800,
                            labelColor = TayleWhite
                        )
                    )
                }
                val relevantStatuses = listOf(
                    OsStatus.ABERTA,
                    OsStatus.EM_EXECUCAO,
                    OsStatus.AGUARDANDO,
                    OsStatus.CONCLUIDA,
                    OsStatus.CANCELADA
                )
                items(relevantStatuses) { status ->
                    val count = orders.count { it.status == status }
                    FilterChip(
                        selected = selectedStatusFilter == status,
                        onClick = { selectedStatusFilter = status },
                        label = { Text("${status.label} ($count)", fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(status.hexColor),
                            selectedLabelColor = TayleWhite,
                            containerColor = TayleNavy800,
                            labelColor = TayleWhite
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Orders List
            if (filteredOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.AssignmentLate,
                            contentDescription = null,
                            tint = TayleSlateLight,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Nenhuma Ordem de Serviço encontrada",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleWhite
                        )
                        Text(
                            text = if (searchQuery.isNotBlank()) "Tente outros termos de busca" else "Clique no botão abaixo para gerar uma nova O.S.",
                            fontSize = 12.sp,
                            color = TayleSlateLight
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 72.dp)
                ) {
                    items(filteredOrders, key = { it.id }) { order ->
                        ServiceOrderCard(
                            order = order,
                            onCardClick = { selectedOrderForDetail = order },
                            onShareClick = { shareServiceOrder(context, order) },
                            onStatusChange = { newStatus -> onUpdateOrderStatus(order, newStatus) },
                            onDeleteClick = { orderToDelete = order }
                        )
                    }
                }
            }
        }
    }

    // Modal de Detalhes da O.S.
    if (selectedOrderForDetail != null) {
        ServiceOrderDetailSheet(
            order = selectedOrderForDetail!!,
            onDismiss = { selectedOrderForDetail = null },
            onShare = {
                shareServiceOrder(context, selectedOrderForDetail!!)
            },
            onUpdateStatus = { newStatus ->
                onUpdateOrderStatus(selectedOrderForDetail!!, newStatus)
                selectedOrderForDetail = selectedOrderForDetail!!.copy(status = newStatus)
            }
        )
    }

    // Confirmação de Exclusão
    if (orderToDelete != null) {
        AlertDialog(
            onDismissRequest = { orderToDelete = null },
            containerColor = TayleNavy900,
            title = {
                Text("Excluir Ordem de Serviço?", color = TayleWhite, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Deseja realmente excluir a O.S. #${orderToDelete?.osNumber} (${orderToDelete?.displayPlate} - ${orderToDelete?.displayModel})? Esta ação não pode ser desfeita.",
                    color = TayleSlateLight,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        orderToDelete?.let { onDeleteOrder(it.id) }
                        orderToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TayleRedLight, contentColor = TayleWhite)
                ) {
                    Text("Excluir O.S.")
                }
            },
            dismissButton = {
                TextButton(onClick = { orderToDelete = null }) {
                    Text("Cancelar", color = TayleSlateLight)
                }
            }
        )
    }
}

@Composable
fun MetricChip(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = TayleNavy900,
        border = BorderStroke(1.dp, TayleNavy700)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(text = title, fontSize = 10.sp, color = TayleSlateLight)
                Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
            }
        }
    }
}

@Composable
fun ServiceOrderCard(
    order: ServiceOrder,
    onCardClick: () -> Unit,
    onShareClick: () -> Unit,
    onStatusChange: (OsStatus) -> Unit,
    onDeleteClick: () -> Unit
) {
    var showStatusMenu by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = TayleNavy900,
        border = BorderStroke(1.dp, TayleNavy700),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("os_card_${order.osNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Row: OS number + Mercosul Plate + Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = TayleNavy800
                    ) {
                        Text(
                            text = "O.S. #${order.osNumber}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Mercosul Plate Badge
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFF003399))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF003399))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = order.displayPlate.ifBlank { "S/ PLACA" },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black
                            )
                        }
                    }
                }

                // Interactive Status Badge
                Box {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(order.status.hexColor).copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, Color(order.status.hexColor)),
                        modifier = Modifier.clickable { showStatusMenu = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(Color(order.status.hexColor))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = order.status.label,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(order.status.hexColor)
                            )
                            Icon(
                                imageVector = Icons.Filled.ArrowDropDown,
                                contentDescription = null,
                                tint = Color(order.status.hexColor),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showStatusMenu,
                        onDismissRequest = { showStatusMenu = false },
                        modifier = Modifier.background(TayleNavy800)
                    ) {
                        listOf(
                            OsStatus.ABERTA,
                            OsStatus.EM_EXECUCAO,
                            OsStatus.AGUARDANDO,
                            OsStatus.CONCLUIDA,
                            OsStatus.CANCELADA
                        ).forEach { st ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = st.label,
                                        fontSize = 12.sp,
                                        fontWeight = if (order.status == st) FontWeight.Bold else FontWeight.Normal,
                                        color = Color(st.hexColor)
                                    )
                                },
                                onClick = {
                                    onStatusChange(st)
                                    showStatusMenu = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Vehicle Model and Year/Color
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.DirectionsCar,
                    contentDescription = null,
                    tint = TayleSlateLight,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = order.displayModel.ifBlank { "Veículo não especificado" },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TayleWhite
                )
                if (order.year > 0 || order.color.isNotBlank()) {
                    Text(
                        text = " • ${if (order.year > 0) order.year else ""} ${order.color}".trim(),
                        fontSize = 12.sp,
                        color = TayleSlateLight
                    )
                }
            }

            // Customer Name & Phone
            if (order.displayClientName.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = null,
                        tint = TayleSlateLight,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = order.displayClientName,
                        fontSize = 12.sp,
                        color = TayleSlateLight
                    )
                    if (order.displayClientPhone.isNotBlank()) {
                        Text(
                            text = " (${order.displayClientPhone})",
                            fontSize = 11.sp,
                            color = TayleCyan
                        )
                    }
                }
            }

            // Services list or description preview
            Spacer(modifier = Modifier.height(8.dp))
            if (order.itemsList.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = TayleNavy950,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        order.itemsList.take(3).forEach { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "• ${item.serviceName} (x${item.quantity})",
                                    fontSize = 11.sp,
                                    color = TayleWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "R$ ${"%,.2f".format(Locale.GERMANY, item.total)}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TayleSlateLight
                                )
                            }
                        }
                        if (order.itemsList.size > 3) {
                            Text(
                                text = "+ mais ${order.itemsList.size - 3} serviço(s)",
                                fontSize = 10.sp,
                                color = TayleCyan
                            )
                        }
                    }
                }
            } else if (order.servicesList.isNotEmpty()) {
                Text(
                    text = "Serviços: ${order.servicesList.joinToString(", ")}",
                    fontSize = 11.sp,
                    color = TayleSlateLight,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            } else if (order.description.isNotBlank()) {
                Text(
                    text = order.description,
                    fontSize = 11.sp,
                    color = TayleSlateLight,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = TayleNavy700, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(8.dp))

            // Bottom Row: Branch & Total Amount & Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Unidade: ${order.branchName.replace("Filial ", "")}",
                        fontSize = 10.sp,
                        color = TayleSlateLight
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Total: ",
                            fontSize = 11.sp,
                            color = TayleSlateLight
                        )
                        Text(
                            text = "R$ ${"%,.2f".format(Locale.GERMANY, order.totalAmount)}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TayleGreen
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onShareClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Share,
                            contentDescription = "Compartilhar",
                            tint = TayleCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onCardClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Visibility,
                            contentDescription = "Detalhes",
                            tint = TayleWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Excluir",
                            tint = TayleRedLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceOrderDetailSheet(
    order: ServiceOrder,
    onDismiss: () -> Unit,
    onShare: () -> Unit,
    onUpdateStatus: (OsStatus) -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = TayleNavy900,
        contentColor = TayleWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Ordem de Serviço #${order.osNumber}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleWhite
                    )
                    val dateFormatted = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(order.createdAt))
                    Text(text = "Aberta em: $dateFormatted", fontSize = 11.sp, color = TayleSlateLight)
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(order.status.hexColor).copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, Color(order.status.hexColor))
                ) {
                    Text(
                        text = order.status.label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(order.status.hexColor),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Vehicle Information Card
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = TayleNavy800,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "DADOS DO VEÍCULO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Placa", fontSize = 10.sp, color = TayleSlateLight)
                            Text(text = order.displayPlate.ifBlank { "Não informada" }, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                        }
                        Column {
                            Text(text = "Modelo", fontSize = 10.sp, color = TayleSlateLight)
                            Text(text = order.displayModel, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                        }
                        Column {
                            Text(text = "Ano / Cor", fontSize = 10.sp, color = TayleSlateLight)
                            Text(text = "${if (order.year > 0) order.year else "-"} / ${order.color.ifBlank { "-" }}", fontSize = 13.sp, color = TayleWhite)
                        }
                    }
                    if (order.chassis.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Chassi: ${order.chassis}", fontSize = 11.sp, color = TayleSlateLight)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Client Card
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = TayleNavy800,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "CLIENTE & RESPONSÁVEL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Cliente", fontSize = 10.sp, color = TayleSlateLight)
                            Text(text = order.displayClientName.ifBlank { "Cliente Balcão" }, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                        }
                        Column {
                            Text(text = "Contato / WhatsApp", fontSize = 10.sp, color = TayleSlateLight)
                            Text(text = order.displayClientPhone.ifBlank { "-" }, fontSize = 13.sp, color = TayleCyan)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Unidade: ${order.branchName} • Técnico: ${order.displayTechnician}", fontSize = 11.sp, color = TayleSlateLight)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Services & Values Card
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = TayleNavy800,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "SERVIÇOS SOLICITADOS & VALORES",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TayleCyan,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (order.itemsList.isNotEmpty()) {
                        order.itemsList.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = item.serviceName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TayleWhite)
                                    if (item.description.isNotBlank()) {
                                        Text(text = item.description, fontSize = 10.sp, color = TayleSlateLight)
                                    }
                                }
                                Text(
                                    text = "${item.quantity}x R$ ${"%,.2f".format(Locale.GERMANY, item.unitPrice)}",
                                    fontSize = 11.sp,
                                    color = TayleSlateLight
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "R$ ${"%,.2f".format(Locale.GERMANY, item.total)}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TayleWhite
                                )
                            }
                        }
                    } else if (order.servicesList.isNotEmpty()) {
                        order.servicesList.forEach { srv ->
                            Text(text = "• $srv", fontSize = 12.sp, color = TayleWhite)
                        }
                    } else {
                        Text(text = order.description.ifBlank { "Revisão e serviços gerais" }, fontSize = 12.sp, color = TayleWhite)
                    }

                    if (order.discount > 0) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Desconto Autorizado:", fontSize = 11.sp, color = TayleRedLight)
                            Text(text = "- R$ ${"%,.2f".format(Locale.GERMANY, order.discount)}", fontSize = 11.sp, color = TayleRedLight, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider(color = TayleNavy700, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "VALOR TOTAL DA O.S.:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TayleWhite)
                        Text(text = "R$ ${"%,.2f".format(Locale.GERMANY, order.totalAmount)}", fontSize = 16.sp, fontWeight = FontWeight.Black, color = TayleGreen)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons: Share / Print & Change Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onShare,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TayleCyan),
                    border = BorderStroke(1.dp, TayleCyan)
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Compartilhar O.S.")
                }

                Button(
                    onClick = {
                        val nextStatus = when (order.status) {
                            OsStatus.ABERTA -> OsStatus.EM_EXECUCAO
                            OsStatus.PENDENTE -> OsStatus.EM_EXECUCAO
                            OsStatus.EM_EXECUCAO -> OsStatus.CONCLUIDA
                            OsStatus.EM_ANDAMENTO -> OsStatus.CONCLUIDA
                            OsStatus.AGUARDANDO -> OsStatus.EM_EXECUCAO
                            OsStatus.CONCLUIDA -> OsStatus.ENTREGUE
                            else -> OsStatus.CONCLUIDA
                        }
                        onUpdateStatus(nextStatus)
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = TayleCyan, contentColor = TayleNavy950)
                ) {
                    Text("Avançar Status", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

// Helper to share/print the Service Order text via Android Intent
fun shareServiceOrder(context: Context, order: ServiceOrder) {
    val dateFormatted = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(order.createdAt))

    val sb = StringBuilder()
    sb.appendLine("========================================")
    sb.appendLine("        TAYLE — ORDEM DE SERVIÇO        ")
    sb.appendLine("========================================")
    sb.appendLine("NÚMERO DA O.S.: #${order.osNumber}")
    sb.appendLine("DATA DE ABERTURA: $dateFormatted")
    sb.appendLine("UNIDADE: ${order.branchName}")
    sb.appendLine("STATUS: ${order.status.label.uppercase()}")
    sb.appendLine("----------------------------------------")
    sb.appendLine("IDENTIFICAÇÃO DO VEÍCULO:")
    sb.appendLine("• Placa: ${order.displayPlate}")
    sb.appendLine("• Veículo: ${order.displayModel}")
    if (order.year > 0 || order.color.isNotBlank()) {
        sb.appendLine("• Ano/Cor: ${if (order.year > 0) order.year else "-"} / ${order.color.ifBlank { "-" }}")
    }
    if (order.chassis.isNotBlank()) {
        sb.appendLine("• Chassi: ${order.chassis}")
    }
    sb.appendLine("----------------------------------------")
    sb.appendLine("DADOS DO CLIENTE:")
    sb.appendLine("• Nome: ${order.displayClientName.ifBlank { "Cliente Balcão" }}")
    if (order.displayClientPhone.isNotBlank()) {
        sb.appendLine("• Contato: ${order.displayClientPhone}")
    }
    sb.appendLine("----------------------------------------")
    sb.appendLine("SERVIÇOS PRESTADOS:")
    if (order.itemsList.isNotEmpty()) {
        order.itemsList.forEach { item ->
            sb.appendLine("• ${item.serviceName} (x${item.quantity}) — R$ ${"%,.2f".format(Locale.GERMANY, item.total)}")
        }
    } else if (order.servicesList.isNotEmpty()) {
        order.servicesList.forEach { srv ->
            sb.appendLine("• $srv")
        }
    } else {
        sb.appendLine("• ${order.description.ifBlank { "Revisão e serviços mecânicos" }}")
    }
    if (order.discount > 0) {
        sb.appendLine("• Desconto Autorizado: - R$ ${"%,.2f".format(Locale.GERMANY, order.discount)}")
    }
    sb.appendLine("----------------------------------------")
    sb.appendLine("VALOR TOTAL: R$ ${"%,.2f".format(Locale.GERMANY, order.totalAmount)}")
    sb.appendLine("TÉCNICO RESPONSÁVEL: ${order.displayTechnician}")
    if (order.notes.isNotBlank()) {
        sb.appendLine("OBSERVAÇÕES: ${order.notes}")
    }
    sb.appendLine("========================================")
    sb.appendLine("TAYLE — Inteligência & Gestão Automotiva")

    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, sb.toString())
        putExtra(Intent.EXTRA_TITLE, "Ordem de Serviço #${order.osNumber} - ${order.displayPlate}")
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Compartilhar / Imprimir O.S. #${order.osNumber}")
    context.startActivity(shareIntent)
}
