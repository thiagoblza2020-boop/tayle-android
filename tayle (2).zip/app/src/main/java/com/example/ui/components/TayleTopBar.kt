package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Branch
import com.example.data.model.Company
import com.example.data.model.User
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TayleTopBar(
    currentUser: User?,
    currentCompany: Company?,
    selectedBranch: Branch? = null,
    unreadNotificationsCount: Int = 0,
    onCompanyClick: () -> Unit,
    onBranchClick: (() -> Unit)? = null,
    onRoleBadgeClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onProfileClick: () -> Unit,
    onMenuToggle: (() -> Unit)? = null
) {
    TopAppBar(
        title = {
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        if (onBranchClick != null) onBranchClick() else onCompanyClick()
                    }
                    .padding(vertical = 4.dp, horizontal = 4.dp)
                    .testTag("top_bar_company_branch_selector")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = currentCompany?.name ?: "TAYLE Concessionária",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TayleWhite
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val branchLabel = when {
                        selectedBranch == null -> "🌐 Visão Consolidada"
                        selectedBranch.isHeadquarters -> "🏢 ${selectedBranch.name}"
                        else -> "🏪 ${selectedBranch.name}"
                    }
                    Text(
                        text = "$branchLabel • ${currentCompany?.plan ?: "Plano Master"}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (selectedBranch == null) TayleCyan else TayleAmber,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        navigationIcon = {
            if (onMenuToggle != null) {
                IconButton(
                    onClick = onMenuToggle,
                    modifier = Modifier.testTag("top_bar_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Menu,
                        contentDescription = "Abrir Menu",
                        tint = TayleCyan
                    )
                }
            }
        },
        actions = {
            // Role Badge (Clickable to inspect or switch role)
            if (currentUser != null) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = when (currentUser.role) {
                        com.example.data.model.UserRole.ADMINISTRADOR -> TayleAmber.copy(alpha = 0.2f)
                        com.example.data.model.UserRole.GERENTE -> TayleCyan.copy(alpha = 0.2f)
                        com.example.data.model.UserRole.SUPERVISOR -> TayleIndigo.copy(alpha = 0.2f)
                        com.example.data.model.UserRole.OPERADOR -> TayleNavy700
                    },
                    modifier = Modifier
                        .clickable { onRoleBadgeClick() }
                        .padding(horizontal = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = "Função",
                            tint = when (currentUser.role) {
                                com.example.data.model.UserRole.ADMINISTRADOR -> TayleAmber
                                com.example.data.model.UserRole.GERENTE -> TayleCyan
                                com.example.data.model.UserRole.SUPERVISOR -> TayleCyan
                                com.example.data.model.UserRole.OPERADOR -> TayleSlateLight
                            },
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = currentUser.role.label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (currentUser.role) {
                                com.example.data.model.UserRole.ADMINISTRADOR -> TayleAmber
                                com.example.data.model.UserRole.GERENTE -> TayleCyan
                                com.example.data.model.UserRole.SUPERVISOR -> TayleCyan
                                com.example.data.model.UserRole.OPERADOR -> TayleWhite
                            }
                        )
                    }
                }
            }

            // Notifications
            IconButton(
                onClick = onNotificationsClick,
                modifier = Modifier.testTag("top_bar_notifications_button")
            ) {
                BadgedBox(
                    badge = {
                        if (unreadNotificationsCount > 0) {
                            Badge(
                                containerColor = TayleRedLight,
                                contentColor = TayleWhite
                            ) {
                                Text(
                                    text = if (unreadNotificationsCount > 9) "9+" else unreadNotificationsCount.toString(),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.Notifications,
                        contentDescription = "Notificações",
                        tint = TayleSlateLight
                    )
                }
            }

            // Profile
            IconButton(
                onClick = onProfileClick,
                modifier = Modifier.testTag("top_bar_profile_button")
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(TayleCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = "Perfil",
                        tint = TayleCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = TayleNavy900,
            titleContentColor = TayleWhite,
            navigationIconContentColor = TayleCyan,
            actionIconContentColor = TayleSlateLight
        )
    )
}
